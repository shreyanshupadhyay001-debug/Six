/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LandmarkCase, AcademicArticle, DebateDay, DebateSpeech } from "../types";

export type CitationStyle = "Bluebook" | "Chicago" | "APA" | "MLA";

export interface CitationParams {
  style: CitationStyle;
  pinpointPage?: string;
  customUrl?: string;
  addAnnotation?: string;
}

/**
 * Utility to parse an author's name into "Last, First" format
 */
export function formatAuthorName(name: string, format: "last-first" | "initials"): string {
  const clean = name.replace(/^(Prof\.|Dr\.|Shri|Smt\.|Mr\.|Mrs\.)\s+/, "").trim();
  const parts = clean.split(/\s+/);
  if (parts.length <= 1) return clean;

  const lastName = parts[parts.length - 1];
  const firstAndMiddle = parts.slice(0, parts.length - 1);

  if (format === "last-first") {
    return `${lastName}, ${firstAndMiddle.join(" ")}`;
  } else {
    const initials = firstAndMiddle.map(p => `${p.charAt(0).toUpperCase()}.`).join(" ");
    return `${lastName}, ${initials}`;
  }
}

/**
 * Clean up dates (e.g. "5 September 1949 — Monday")
 */
export function parseDebateDate(dateStr: string): { dayMonth: string; year: string; fullDate: string } {
  // Extract date part before any dash
  const cleanDate = dateStr.split("—")[0].trim();
  const parts = cleanDate.split(/\s+/); // "5", "September", "1949"
  const year = parts.length >= 3 ? parts[2] : "1949";
  const dayMonth = parts.slice(0, 2).join(" ");
  return {
    dayMonth,
    year,
    fullDate: cleanDate
  };
}

/**
 * Create custom formatted citation for landmark cases
 */
export function generateCaseCitation(item: LandmarkCase, params: CitationParams): string {
  const { style, pinpointPage, customUrl, addAnnotation } = params;
  const pinpointText = pinpointPage ? `, at p. ${pinpointPage}` : "";
  const urlSuffix = customUrl ? ` (${customUrl})` : "";
  const annotationSuffix = addAnnotation ? ` [${addAnnotation}]` : "";

  switch (style) {
    case "Bluebook":
      return `${item.name}, ${item.citation}${pinpointText} (${item.year})${urlSuffix}${annotationSuffix}.`;

    case "Chicago":
      return `${item.name}, ${item.citation}${pinpointText} (${item.metadata.court}, ${item.year})${urlSuffix}${annotationSuffix}.`;

    case "APA":
      // APA: Name of Case, Citation (Court Year)
      return `${item.name}, ${item.citation}${pinpointPage ? `, p. ${pinpointPage}` : ""} (${item.metadata.court}, ${item.year})${urlSuffix}${annotationSuffix}.`;

    case "MLA":
      // MLA: Name of Case. Citation. Court, Year.
      return `${item.name}. ${item.citation}${pinpointPage ? `, p. ${pinpointPage}` : ""}. ${item.metadata.court}, ${item.year}${urlSuffix}${annotationSuffix}.`;

    default:
      return `${item.name}, ${item.citation} (${item.year}).`;
  }
}

/**
 * Create custom formatted citation for academic articles
 */
export function generateArticleCitation(item: AcademicArticle, params: CitationParams): string {
  const { style, pinpointPage, customUrl, addAnnotation } = params;
  const pinpointText = pinpointPage ? `, pinpoint page: ${pinpointPage}` : "";
  const urlSuffix = customUrl ? `, available at: ${customUrl}` : "";
  const annotationSuffix = addAnnotation ? ` (${addAnnotation})` : "";

  switch (style) {
    case "Bluebook": {
      // Bluebook format: Author, Title, Vol Journal Pages (Year)
      return `${item.author}, ${item.title}, ${item.journal}, ${item.pages || ""}${pinpointText} (${item.year})${urlSuffix}${annotationSuffix}.`;
    }

    case "Chicago": {
      // Chicago author last, first. "Title." Journal Vol (Year): Pages.
      const formattedAuthor = formatAuthorName(item.author, "last-first");
      const pageInfo = item.pages ? `, ${item.pages}` : "";
      return `${formattedAuthor}. "${item.title}." ${item.journal}${pageInfo}${pinpointText} (${item.year})${urlSuffix}${annotationSuffix}.`;
    }

    case "APA": {
      // APA format: Author, A. A. (Year). Title. Journal, Vol, Pages.
      const formattedAuthor = formatAuthorName(item.author, "initials");
      const pageInfo = item.pages ? `, ${item.pages}` : "";
      return `${formattedAuthor} (${item.year}). ${item.title}. *${item.journal}*${pageInfo}${pinpointPage ? `, p. ${pinpointPage}` : ""}${urlSuffix}${annotationSuffix}.`;
    }

    case "MLA": {
      // MLA format: Author. "Title." Journal, Vol, Pages, Year.
      const formattedAuthor = formatAuthorName(item.author, "last-first");
      const pageInfo = item.pages ? `, ${item.pages}` : "";
      return `${formattedAuthor}. "${item.title}." *${item.journal}*${pageInfo}${pinpointPage ? `, p. ${pinpointPage}` : ""}, ${item.year}${urlSuffix}${annotationSuffix}.`;
    }

    default:
      return `${item.author}, ${item.title} (${item.year}).`;
  }
}

/**
 * Create custom formatted citation for Constituent Assembly debates & speeches
 */
export function generateDebateCitation(
  day: DebateDay,
  speech: DebateSpeech | null,
  params: CitationParams
): string {
  const { style, pinpointPage, customUrl, addAnnotation } = params;
  const info = parseDebateDate(day.date);
  
  const pinpointText = pinpointPage ? `, at p. ${pinpointPage}` : (speech?.page ? `, at p. ${speech.page.replace(/Vol\.\s+IX,\s+p\.\s+/, "")}` : "");
  const urlSuffix = customUrl ? ` (accessed via: ${customUrl})` : "";
  const annotationSuffix = addAnnotation ? ` [${addAnnotation}]` : "";

  const speakerName = speech ? speech.speaker : null;
  const speakerDesc = speakerName ? `${speakerName} speech, ` : "discussion, ";

  switch (style) {
    case "Bluebook": {
      // Bluebook: CONSTITUENT ASSEMBLY DEBATES, Vol. IX, Speaker, Date
      return `CONSTITUENT ASSEMBLY DEBATES, Vol. IX, ${speakerDesc}${info.fullDate}${pinpointText} (reprint Lok Sabha Secretariat, New Delhi, 2014)${urlSuffix}${annotationSuffix}.`;
    }

    case "Chicago": {
      // Chicago: Constituent Assembly of India. Debates. Vol. IX. Date. Speaker...
      const speechLabel = speakerName ? `Speech by ${speakerName}. ` : "";
      return `Constituent Assembly of India. Debates: Official Report. ${speechLabel}Vol. IX, ${info.fullDate}${pinpointPage ? `, p. ${pinpointPage}` : ""}. New Delhi: Lok Sabha Secretariat, 2014 reprint${urlSuffix}${annotationSuffix}.`;
    }

    case "APA": {
      // APA: Constituent Assembly of India. (1949, Date). Constituent Assembly Debates...
      const speakerDetails = speakerName ? ` (Contributions of ${speakerName})` : "";
      return `Constituent Assembly of India. (${info.year}, ${info.dayMonth}). *Constituent Assembly Debates* (Vol. IX, pp. 1003–1099)${speakerDetails}${pinpointPage ? `, p. ${pinpointPage}` : ""}. Lok Sabha Secretariat${urlSuffix}${annotationSuffix}.`;
    }

    case "MLA": {
      // MLA: Constituent Assembly of India. Debates. Speaker... Vol. IX, Lok Sabha Secretariat, Date.
      const speechLabel = speakerName ? `Speech by ${speakerName}. ` : "";
      return `Constituent Assembly of India. Debates: Official Report. ${speechLabel}Vol. IX, Lok Sabha Secretariat, ${info.fullDate}${pinpointPage ? `, p. ${pinpointPage}` : ""}${urlSuffix}${annotationSuffix}.`;
    }

    default:
      return `Constituent Assembly of India, Vol. IX Debates, 1949.`;
  }
}

/**
 * Helper to generate BibTeX code block for direct download/export
 */
export function generateBibTeX(
  type: "case" | "article" | "debate",
  item: LandmarkCase | AcademicArticle | DebateDay,
  speech?: DebateSpeech | null
): string {
  const citeKey = item.id ? item.id.replace(/-/g, "_") : "citation_record";

  if (type === "case") {
    const c = item as unknown as LandmarkCase;
    return `@jurisdiction{${citeKey},\n  title = {${c.name}},\n  reporter = {${c.citation.split("·")[0].trim()}},\n  court = {${c.metadata.court}},\n  year = {${c.year}},\n  note = {Sixth Schedule Jurisprudence - ${c.metadata.state}}\n}`;
  } else if (type === "article") {
    const a = item as unknown as AcademicArticle;
    return `@article{${citeKey},\n  author = {${a.author}},\n  title = {${a.title}},\n  journal = {${a.journal}},\n  year = {${a.year}},\n  pages = {${a.pages || ""}},\n  note = {Sixth Schedule Academic Database}\n}`;
  } else {
    const d = item as unknown as DebateDay;
    const speakerPart = speech ? `\n  author = {${speech.speaker}},\n  title = {Constituent Assembly Speech on ${d.date.split("—")[0].trim()}},` : `\n  title = {Constituent Assembly Debates, Vol. IX, ${d.date.split("—")[0].trim()}},`;
    return `@proceedings{${citeKey},${speakerPart}\n  organization = {Constituent Assembly of India},\n  publisher = {Lok Sabha Secretariat},\n  year = {1949},\n  address = {New Delhi}\n}`;
  }
}
