/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CaseMetadata {
  court: string;
  year: number;
  bench?: string;
  state: string;
  judges?: number;
  region?: string;
}

export interface LandmarkCase {
  id: string;
  name: string;
  citation: string;
  year: number;
  tags: string[];
  issue: string;
  holding: string;
  excerpt?: string;
  metadata: CaseMetadata;
}

export interface DebateSpeech {
  speaker: string;
  role: string;
  page: string;
  text: string;
  outcome?: string;
  tags?: string[];
}

export interface DebateDay {
  id: string;
  date: string;
  meta: string;
  summary: string;
  speeches: DebateSpeech[];
}

export interface Amendment {
  id: string;
  para: string;
  mover: string;
  substance: string;
  result: "adopted" | "negatived" | "withdrawn" | "compromise" | "scope_adopted";
}

export interface SpeakerProfile {
  id: string;
  name: string;
  role: string;
  meta: string;
  avatarInitials: string;
  color: string;
  bio: string;
  contributions: string[];
  mainQuote: string;
}

export interface TimelineMilestone {
  id: string;
  year: string;
  title: string;
  desc: string;
  era: "drafting" | "early" | "expansion" | "modern";
  tags: string[];
}

export interface AcademicArticle {
  id: string;
  title: string;
  author: string;
  journal: string;
  year: number;
  pages?: string;
  abstract: string;
  tags: string[];
}

export interface NewsUpdate {
  id: string;
  date: string;
  type: "legislative" | "judicial" | "political" | "administrative";
  title: string;
  body: string[];
  source: string;
  tags: string[];
  pinned?: boolean;
}

export interface GlossaryEntry {
  term: string;
  definition: string;
  context?: string;
}
