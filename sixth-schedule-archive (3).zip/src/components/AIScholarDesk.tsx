/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Send, Trash2, HelpCircle, FileText, Scale, BookOpen, Clock, RefreshCw } from "lucide-react";

interface Message {
  role: "user" | "model";
  content: string;
}

const SCHOLAR_TEMPLATES = [
  {
    title: "Ambedkar's Comparison",
    prompt: "Compare Dr. Ambedkar's analogy of Autonomous District Councils to US tribal sovereignty and Swiss cantonal autonomy in the 1949 debates.",
    icon: Scale,
    tag: "Debates"
  },
  {
    title: "ADC Executive Powers",
    prompt: "Explain the conflict between a State's legislative supremacy and an Autonomous District Council's executive/administrative autonomy.",
    icon: BookOpen,
    tag: "Autonomy"
  },
  {
    title: "Sangma v. State Ruling",
    prompt: "What is the significance of the Sangma judicial precedent in clarifying the boundary of paragraph 3 customary laws?",
    icon: FileText,
    tag: "Jurisprudence"
  },
  {
    title: "Sixth Schedule Origin",
    prompt: "How did the Bardoloi Sub-Committee (1947) shape the original draft of the Sixth Schedule and the inner line policy?",
    icon: Clock,
    tag: "History"
  }
];

export function AIScholarDesk() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      content: "Welcome to the **AI Scholar Research Desk**. I am configured as a policy and constitutional counselor initialized on the core archives of the Sixth Schedule.\n\nYou can select one of the classic research prompts below or type your custom constitutional inquiry about tribal autonomy, customary laws, or landmark judicial reviews."
    }
  ]);
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    setError(null);
    const userMsg: Message = { role: "user", content: textToSend };
    // Optimistic state updates
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setQuery("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/gemini/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: textToSend,
          // Exclude the initial welcome message from the API history
          history: updatedMessages.slice(1, -1)
        }),
      });

      const data = await response.json();
      
      if (data.error) {
        setError(data.response || data.error);
        setMessages(prev => [
          ...prev, 
          { 
            role: "model", 
            content: `⚠️ **Unable to analyze query:** ${data.response || "No API key config."}` 
          }
        ]);
      } else {
        setMessages(prev => [...prev, { role: "model", content: data.response }]);
      }
    } catch (err: any) {
      console.error(err);
      setError("Failed to communicate with the scholarly repository backend.");
      setMessages(prev => [
        ...prev, 
        { 
          role: "model", 
          content: "⚠️ **System Error:** The custom server could not be reached. Verify if the development server is active." 
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([
      {
        role: "model",
        content: "Draft transcripts cleared. Research Desk is reinitialized. Pose a new inquiry below."
      }
    ]);
    setError(null);
  };

  return (
    <div className="page-full max-w-5xl">
      
      {/* Editorial Header */}
      <div className="text-center mb-10">
        <span className="text-[10px] font-mono tracking-widest uppercase text-amber-700 dark:text-amber-500 font-bold flex items-center justify-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Interactive Scholarly Intelligence</span>
        </span>
        <h1 className="font-serif text-4xl font-extrabold tracking-tight text-stone-900 dark:text-zinc-50 mt-1 leading-tight">
          AI Constitution Scholar
        </h1>
        <p className="text-sm font-serif italic text-stone-500 dark:text-zinc-400 mt-2 max-w-xl mx-auto">
          An interactive legal counselor proxying Gemini 3.5 Flash to search, interpret, and cross-reference Autonomous District Council archives.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Question Templates & Indicators */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-stone-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 p-5 rounded-lg">
            <h3 className="font-serif text-xs font-mono tracking-wider uppercase text-[#631919] dark:text-[#C5A059] font-bold mb-4 flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              <span>Syllabus Templates</span>
            </h3>
            
            <div className="space-y-3">
              {SCHOLAR_TEMPLATES.map((tmpl) => {
                const Icon = tmpl.icon;
                return (
                  <button
                    key={tmpl.title}
                    onClick={() => handleSend(tmpl.prompt)}
                    disabled={isLoading}
                    className="w-full text-left p-3.5 bg-stone-50 hover:bg-stone-150/75 dark:bg-zinc-950 dark:hover:bg-zinc-800/80 border border-stone-200 dark:border-zinc-800/80 rounded transition-all cursor-pointer select-none group flex flex-col gap-1.5 text-xs text-stone-700 dark:text-zinc-300 disabled:opacity-50"
                  >
                    <div className="flex justify-between items-center w-full">
                      <span className="font-serif font-bold text-stone-900 dark:text-zinc-100 group-hover:text-[#631919] dark:group-hover:text-[#C5A059]">
                        {tmpl.title}
                      </span>
                      <span className="text-[8px] font-mono tracking-widest uppercase bg-stone-200/60 dark:bg-zinc-800 text-stone-500 rounded px-1.5 py-0.5">
                        {tmpl.tag}
                      </span>
                    </div>
                    <p className="text-[10px] font-serif leading-relaxed line-clamp-2 text-stone-500 dark:text-zinc-400">
                      {tmpl.prompt}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Model information badge */}
          <div className="bg-[#631919]/5 dark:bg-[#C5A059]/10 border border-[#C5A059]/30 text-stone-600 dark:text-zinc-400 p-5 rounded-lg text-xs leading-relaxed font-serif space-y-3">
            <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-widest text-[#631919] dark:text-[#C5A059] font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Full-Stack Safe Sandbox</span>
            </div>
            <p>
              Your research desk connects exclusively to our verified Node server proxy to execute secure requests using server-side variables. No browser key leak is possible.
            </p>
            <div className="pt-2 border-t border-[#C5A059]/20 font-mono text-[8px] uppercase tracking-widest flex justify-between items-center">
              <span>Model: Gemini 3.5 Flash</span>
              <span>Online • Encrypted</span>
            </div>
          </div>
        </div>

        {/* Right Side: Main Chat Interface */}
        <div className="lg:col-span-8 bg-stone-50 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg flex flex-col h-[580px] overflow-hidden">
          
          {/* Chat Tool header */}
          <div className="px-6 py-4 border-b border-stone-200 dark:border-zinc-800 flex justify-between items-center bg-stone-100 dark:bg-zinc-900">
            <div className="flex items-center gap-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
              <span className="font-serif text-sm font-bold text-stone-900 dark:text-zinc-100">Live Analytical Stream</span>
            </div>
            
            <button
              onClick={clearChat}
              className="p-1.5 hover:bg-stone-200 dark:hover:bg-zinc-800 rounded text-stone-500 dark:text-zinc-400 hover:text-[#631919] dark:hover:text-rose-400 border border-transparent hover:border-stone-250 dark:hover:border-zinc-700 transition-all cursor-pointer"
              title="Reset Transcript"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          {/* Chat Scrollbox */}
          <div className="flex-1 p-6 overflow-y-auto space-y-5 scroll-smooth scrollbar">
            <AnimatePresence initial={false}>
              {messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div className={`max-w-[85%] rounded-lg px-4.5 py-3.5 text-xs sm:text-xs leading-relaxed font-serif ${
                    msg.role === "user"
                      ? "bg-[#631919] text-white rounded-br-none font-sans"
                      : "bg-[#F5F2ED] dark:bg-zinc-950 text-stone-850 dark:text-zinc-100 border border-stone-200 dark:border-zinc-800/80 rounded-bl-none shadow-sm whitespace-pre-wrap select-text"
                  }`}>
                    {msg.role === "model" ? (
                      <div className="prose dark:prose-invert prose-xs max-w-none text-stone-800 dark:text-zinc-200">
                        {msg.content}
                      </div>
                    ) : (
                      <span>{msg.content}</span>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="bg-[#F5F2ED] dark:bg-zinc-950 border border-stone-200 dark:border-zinc-800/80 rounded-lg rounded-bl-none px-4.5 py-3 text-xs flex items-center gap-3 text-amber-800 dark:text-amber-500">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span className="font-mono tracking-wider uppercase text-[9px] font-bold">Gemini Scholar synthesizing brief...</span>
                </div>
              </motion.div>
            )}

            {error && (
              <div className="p-3 bg-red-100/60 dark:bg-red-950/20 text-rose-800 dark:text-rose-400 border border-red-200 dark:border-red-900/40 text-[10px] font-mono tracking-wide rounded">
                API Error: {error}
              </div>
            )}
          </div>

          {/* Chat Form Footer */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(query);
            }}
            className="p-4 bg-stone-100 dark:bg-zinc-900/60 border-t border-stone-200 dark:border-zinc-800"
          >
            <div className="flex gap-2.5 relative items-center">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Query our constitutional database (e.g., Explain 'Paragraph 3' custom limits)"
                className="flex-1 text-xs px-4 py-3 bg-white dark:bg-zinc-950 border border-stone-250 dark:border-zinc-800 focus:outline-none focus:border-[#631919] dark:focus:border-[#C5A059] rounded text-stone-900 dark:text-white placeholder:text-stone-400 dark:placeholder:text-zinc-500 font-serif"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !query.trim()}
                className="px-5 py-3 bg-[#631919] hover:bg-[#8B1A1A] dark:bg-[#C5A059] dark:hover:bg-amber-600 border border-transparent text-white dark:text-stone-950 rounded font-mono text-[10px] tracking-widest uppercase font-bold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>

        </div>

      </div>

    </div>
  );
}
