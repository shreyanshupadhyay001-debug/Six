/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Copy, Check, Download, Landmark, FileText, Book, Sparkles, Sliders, Quote } from "lucide-react";
import { landmarkCases } from "../data/cases";
import { academicArticles } from "../data/articles";
import { debateDays } from "../data/debates";
import { 
  CitationStyle, 
  generateCaseCitation, 
  generateArticleCitation, 
  generateDebateCitation, 
  generateBibTeX,
  formatAuthorName
} from "../utils/citationHelper";

export function CitationDesk({
  initialType = "case",
  initialItemId = "",
  initialSpeechIndex = -1,
  compact = false
}: {
  initialType?: "case" | "article" | "debate";
  initialItemId?: string;
  initialSpeechIndex?: number;
  compact?: boolean;
}) {
  const [itemType, setItemType] = useState<"case" | "article" | "debate">(initialType);
  const [selectedStyle, setSelectedStyle] = useState<CitationStyle>("Bluebook");
  
  // Selection states
  const [selectedCaseId, setSelectedCaseId] = useState(landmarkCases[0]?.id || "");
  const [selectedArticleId, setSelectedArticleId] = useState(academicArticles[0]?.id || "");
  const [selectedDebateId, setSelectedDebateId] = useState(debateDays[0]?.id || "");
  const [speechIndex, setSpeechIndex] = useState<number>(-1);

  // Customize states
  const [pinpointPage, setPinpointPage] = useState("");
  const [customUrl, setCustomUrl] = useState("");
  const [addAnnotation, setAddAnnotation] = useState("");
  const [copied, setCopied] = useState(false);

  // Sync initial parameters when provided
  useEffect(() => {
    if (initialType) setItemType(initialType);
    if (initialItemId) {
      if (initialType === "case") setSelectedCaseId(initialItemId);
      if (initialType === "article") setSelectedArticleId(initialItemId);
      if (initialType === "debate") setSelectedDebateId(initialItemId);
    }
    if (initialSpeechIndex !== undefined) {
      setSpeechIndex(initialSpeechIndex);
    }
  }, [initialType, initialItemId, initialSpeechIndex]);

  // Reset fields on type change
  const handleTypeChange = (type: "case" | "article" | "debate") => {
    setItemType(type);
    setPinpointPage("");
    setCustomUrl("");
    setAddAnnotation("");
    setSpeechIndex(-1);
  };

  const getActiveItemLabel = () => {
    if (itemType === "case") {
      const c = landmarkCases.find(it => it.id === selectedCaseId);
      return c ? c.name : "Selected Case";
    } else if (itemType === "article") {
      const a = academicArticles.find(it => it.id === selectedArticleId);
      return a ? a.title : "Selected Article";
    } else {
      const d = debateDays.find(it => it.id === selectedDebateId);
      return d ? d.date.split("—")[0].trim() : "Selected Debate";
    }
  };

  // Generate citation text dynamically
  const citationText = (() => {
    const params = {
      style: selectedStyle,
      pinpointPage: pinpointPage || undefined,
      customUrl: customUrl || undefined,
      addAnnotation: addAnnotation || undefined
    };

    if (itemType === "case") {
      const c = landmarkCases.find(it => it.id === selectedCaseId);
      return c ? generateCaseCitation(c, params) : "";
    } else if (itemType === "article") {
      const a = academicArticles.find(it => it.id === selectedArticleId);
      return a ? generateArticleCitation(a, params) : "";
    } else {
      const d = debateDays.find(it => it.id === selectedDebateId);
      if (!d) return "";
      const speech = speechIndex >= 0 ? d.speeches[speechIndex] : null;
      return generateDebateCitation(d, speech, params);
    }
  })();

  const bibtexText = (() => {
    if (itemType === "case") {
      const c = landmarkCases.find(it => it.id === selectedCaseId);
      return c ? generateBibTeX("case", c as any) : "";
    } else if (itemType === "article") {
      const a = academicArticles.find(it => it.id === selectedArticleId);
      return a ? generateBibTeX("article", a as any) : "";
    } else {
      const d = debateDays.find(it => it.id === selectedDebateId);
      if (!d) return "";
      const speech = speechIndex >= 0 ? d.speeches[speechIndex] : null;
      return generateBibTeX("debate", d as any, speech);
    }
  })();

  const handleCopy = () => {
    navigator.clipboard.writeText(citationText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadBibTeX = () => {
    const element = document.createElement("a");
    const file = new Blob([bibtexText], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${itemType}_citation_${Date.now()}.bib`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleDownloadTxt = () => {
    const element = document.createElement("a");
    const formatted = `SIXTH SCHEDULE DIGITAL ARCHIVE\n==============================\nDate Generated: ${new Date().toLocaleDateString()}\nStyle: ${selectedStyle}\n\nCitation:\n${citationText}\n\nBibTeX:\n${bibtexText}`;
    const file = new Blob([formatted], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${itemType}_citation_${selectedStyle}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const selectedDebateDayObj = debateDays.find(it => it.id === selectedDebateId);

  return (
    <div id="citation-desk-tool" className={`w-full ${compact ? "" : "bg-[#F9F7F5] dark:bg-[#1A1A1A] p-6 sm:p-8 border-2 border-[#C5A059]/30 rounded-none shadow-md"}`}>
      
      {!compact && (
        <div className="mb-8 border-b border-[#C5A059]/20 pb-6">
          <div className="flex items-center gap-3 mb-2 text-xs font-mono tracking-widest text-[#631919] dark:text-[#C5A059] uppercase font-bold">
            <Quote className="w-5 h-5" />
            <span>Digital Scholarly Desk</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-black text-[#141414] dark:text-white leading-tight">
            Research Citation Generator
          </h2>
          <p className="text-xs sm:text-sm font-serif italic text-[#141414]/70 dark:text-[#F5F2ED]/70 mt-1 max-w-2xl">
            Generate publication-ready academic references for judicial precedents, academic literature, and verbatim assembly speeches in real-time.
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Selectors & Customizers (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Step 1: Select Broad Material Type */}
          <div>
            <label className="block text-[10px] font-mono uppercase tracking-[0.15em] text-[#141414]/65 dark:text-[#F5F2ED]/65 font-bold mb-2.5">
              1. Choose Material Type
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { type: "case", label: "Legal Jurisprudence", icon: Landmark },
                { type: "article", label: "Scholarly Review", icon: Book },
                { type: "debate", label: "Constituent Debate", icon: FileText }
              ].map((btn) => {
                const IconComp = btn.icon;
                const isSelected = itemType === btn.type;
                return (
                  <button
                    key={btn.type}
                    onClick={() => handleTypeChange(btn.type as any)}
                    className={`flex flex-col items-center justify-center p-3.5 border text-center transition-all cursor-pointer ${
                      isSelected 
                        ? "bg-[#631919] text-white border-[#631919] shadow-inner" 
                        : "bg-[#F5F2ED] dark:bg-[#141414] border-[#C5A059]/30 text-[#141414] dark:text-[#F5F2ED] hover:bg-[#631919]/5 dark:hover:bg-[#C5A059]/10"
                    }`}
                  >
                    <IconComp className={`w-5 h-5 mb-1.5 ${isSelected ? "text-[#C5A059]" : "text-[#631919] dark:text-[#C5A059]"}`} />
                    <span className="text-[10px] font-sans font-bold uppercase tracking-wider">{btn.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Select Specific Item in database */}
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-mono uppercase tracking-[0.15em] text-[#141414]/65 dark:text-[#F5F2ED]/65 font-bold mb-1.5">
                2. Select Specific Archival Record
              </label>
              
              {itemType === "case" && (
                <select
                  value={selectedCaseId}
                  onChange={(e) => setSelectedCaseId(e.target.value)}
                  className="w-full text-xs font-serif p-3 bg-[#F5F2ED] dark:bg-[#141414] border border-[#C5A059]/40 text-[#141414] dark:text-[#F5F2ED] focus:outline-none focus:border-[#631919]"
                >
                  {landmarkCases.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.year}) — {c.citation.split("·")[0].trim()}
                    </option>
                  ))}
                </select>
              )}

              {itemType === "article" && (
                <select
                  value={selectedArticleId}
                  onChange={(e) => setSelectedArticleId(e.target.value)}
                  className="w-full text-xs font-serif p-3 bg-[#F5F2ED] dark:bg-[#141414] border border-[#C5A059]/40 text-[#141414] dark:text-[#F5F2ED] focus:outline-none focus:border-[#631919]"
                >
                  {academicArticles.map((a) => (
                    <option key={a.id} value={a.id}>
                      "{a.title}" — {a.author} ({a.year})
                    </option>
                  ))}
                </select>
              )}

              {itemType === "debate" && (
                <div className="space-y-3">
                  <select
                    value={selectedDebateId}
                    onChange={(e) => {
                      setSelectedDebateId(e.target.value);
                      setSpeechIndex(-1); // Reset speech index
                    }}
                    className="w-full text-xs font-serif p-3 bg-[#F5F2ED] dark:bg-[#141414] border border-[#C5A059]/40 text-[#141414] dark:text-[#F5F2ED] focus:outline-none focus:border-[#631919]"
                  >
                    {debateDays.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.date.split("—")[0].trim()} — Vol. IX Discussions
                      </option>
                    ))}
                  </select>

                  {/* Sub-item selection: Spoken Speeches inside this debate day */}
                  {selectedDebateDayObj && (
                    <div>
                      <span className="block text-[8px] font-mono uppercase tracking-[0.15em] text-[#141414]/50 dark:text-[#F5F2ED]/50 font-bold mb-1">
                        Optional: Cite a Specific Speaker Speech
                      </span>
                      <select
                        value={speechIndex}
                        onChange={(e) => setSpeechIndex(Number(e.target.value))}
                        className="w-full text-xs font-serif p-2.5 bg-[#F5F2ED]/60 dark:bg-[#141414]/60 border border-[#C5A059]/30 text-[#141414] dark:text-[#F5F2ED]/90 focus:outline-none focus:border-[#631919]"
                      >
                        <option value={-1}>General Day Discussion (No single speaker limit)</option>
                        {selectedDebateDayObj.speeches.map((sp, idx) => (
                          <option key={idx} value={idx}>
                            {sp.speaker} ({sp.role.split("·")[0].trim()}) {sp.page ? `— p. ${sp.page.replace(/Vol\.\s+IX,\s+p\.\s+/, "")}` : ""}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Step 3: Optional Pinpoint Page / Parameters Customize */}
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Sliders className="w-3.5 h-3.5 text-[#631919] dark:text-[#C5A059]" />
              <label className="block text-[10px] font-mono uppercase tracking-[0.15em] text-[#141414]/65 dark:text-[#F5F2ED]/65 font-bold">
                3. Customize Citation Parameters (Optional)
              </label>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="block text-[8px] font-mono uppercase tracking-widest text-[#141414]/60 dark:text-[#F5F2ED]/60 mb-1">
                  Pinpoint Page / Section (e.g. 1004)
                </span>
                <input
                  type="text"
                  placeholder="e.g. 45-47"
                  value={pinpointPage}
                  onChange={(e) => setPinpointPage(e.target.value)}
                  className="w-full text-xs font-mono p-2.5 bg-[#F5F2ED] dark:bg-[#141414] border border-[#C5A059]/30 text-[#141414] dark:text-[#F5F2ED] focus:outline-none focus:border-[#631919]"
                />
              </div>

              <div>
                <span className="block text-[8px] font-mono uppercase tracking-widest text-[#141414]/60 dark:text-[#F5F2ED]/60 mb-1">
                  Source link URL (e.g. https://...)
                </span>
                <input
                  type="text"
                  placeholder="e.g. https://archives.india.gov"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  className="w-full text-xs font-mono p-2.5 bg-[#F5F2ED] dark:bg-[#141414] border border-[#C5A059]/30 text-[#141414] dark:text-[#F5F2ED] focus:outline-none focus:border-[#631919]"
                />
              </div>

              <div className="sm:col-span-2">
                <span className="block text-[8px] font-mono uppercase tracking-widest text-[#141414]/60 dark:text-[#F5F2ED]/60 mb-1">
                  Custom Explanatory Parenthetical / Annotation (e.g. "invalidating council tax on property")
                </span>
                <input
                  type="text"
                  placeholder="An explanatory parenthetical statement..."
                  value={addAnnotation}
                  onChange={(e) => setAddAnnotation(e.target.value)}
                  className="w-full text-xs font-serif p-2.5 bg-[#F5F2ED] dark:bg-[#141414] border border-[#C5A059]/30 text-[#141414] dark:text-[#F5F2ED] focus:outline-none focus:border-[#631919]"
                />
              </div>
            </div>
          </div>

        </div>

        {/* Right Side: Active Real-time Output Panel (5 cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          
          <div className="bg-[#F5F2ED]/60 dark:bg-[#141414]/40 border-2 border-[#631919] dark:border-[#C5A059] p-4 flex-1 flex flex-col justify-between">
            
            {/* Realtime Citation output section */}
            <div>
              <div className="flex justify-between items-center border-b border-[#C5A059]/20 pb-3 mb-4">
                <span className="text-[10px] font-mono uppercase font-bold tracking-[0.15em] text-[#631919] dark:text-[#C5A059] flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Output Preview</span>
                </span>

                <div className="flex bg-[#F5F2ED] dark:bg-[#0F0F0F] border border-[#C5A059]/20 p-0.5 rounded-none font-mono text-[9px]">
                  {(["Bluebook", "Chicago", "APA", "MLA"] as CitationStyle[]).map((style) => (
                    <button
                      key={style}
                      onClick={() => setSelectedStyle(style)}
                      className={`px-2 py-1 tracking-wider uppercase font-bold cursor-pointer transition-all ${
                        selectedStyle === style 
                          ? "bg-[#631919] text-white" 
                          : "text-[#141414]/70 dark:text-[#F5F2ED]/70 hover:bg-[#631919]/10"
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic citation rendering under fine-typography limits */}
              <div id="citation-result-block" className="space-y-4">
                <div className="bg-white dark:bg-black p-4 border border-[#C5A059]/30 font-serif leading-relaxed text-sm select-all select-text shadow-sm relative group">
                  <div className="text-[#141414] dark:text-gray-100 font-serif pr-4 leading-relaxed text-justify">
                    {/* Render style specific formatting with beautiful italics */}
                    {selectedStyle === "Bluebook" && (
                      <span>
                        {itemType === "case" && <span className="italic">{getActiveItemLabel()}</span>}
                        {itemType === "article" && <span>{formatAuthorName((academicArticles.find(it => it.id === selectedArticleId))?.author || "", "last-first")}, <span className="italic">{getActiveItemLabel()}</span></span>}
                        {itemType === "debate" && <span className="uppercase font-sans font-bold">Constituent Assembly Debates</span>}
                        {citationText.slice(citationText.indexOf(","), citationText.length)}
                      </span>
                    )}

                    {selectedStyle === "Chicago" && (
                      <span>
                        {itemType === "case" && <span className="italic">{getActiveItemLabel()}</span>}
                        {itemType === "article" && <span>{citationText.split('"')[0]}"{citationText.split('"')[1]}" <span className="italic">{getActiveItemLabel()}</span></span>}
                        {itemType === "debate" && <span>Constituent Assembly of India. Debates: Official Report.</span>}
                        {citationText.slice(citationText.indexOf(itemType === "case" ? "," : itemType === "article" ? "." : "."), citationText.length)}
                      </span>
                    )}

                    {selectedStyle === "APA" && (
                      <span>
                        {itemType === "case" && <span className="italic">{getActiveItemLabel()}</span>}
                        {itemType === "article" && <span>{citationText.split(".")[0]}. ({academicArticles.find(it => it.id === selectedArticleId)?.year}). {academicArticles.find(it => it.id === selectedArticleId)?.title}. <span className="italic">{getActiveItemLabel()}</span></span>}
                        {itemType === "debate" && <span>{citationText}</span>}
                        {itemType !== "debate" && citationText.slice(citationText.indexOf(itemType === "case" ? "," : "."), citationText.length)}
                      </span>
                    )}

                    {selectedStyle === "MLA" && (
                      <span>
                        {citationText}
                      </span>
                    )}
                  </div>
                  
                  <span className="absolute bottom-2 right-2 text-[8px] font-mono text-[#C5A059] uppercase opacity-40 group-hover:opacity-100 transition-opacity">
                    Selected Theme Style: {selectedStyle}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions panel */}
            <div className="space-y-2 mt-6">
              <button
                onClick={handleCopy}
                className="w-full py-3.5 bg-[#631919] hover:bg-[#8B1A1A] text-white flex items-center justify-center gap-2 text-[10px] font-mono uppercase tracking-[0.2em] font-bold cursor-pointer shadow-sm transition-all rounded-none"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-[#C5A059]" />
                    <span className="text-[#C5A059]">Citation Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Scholar Reference</span>
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownloadTxt}
                  className="py-2.5 bg-transparent border border-[#631919] hover:bg-[#631919]/5 text-[#631919] dark:text-[#F5F2ED] flex items-center justify-center gap-1.5 text-[9px] font-mono uppercase tracking-widest font-bold cursor-pointer transition-all rounded-none"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .TXT</span>
                </button>
                <button
                  onClick={handleDownloadBibTeX}
                  className="py-2.5 bg-[#141414] dark:bg-[#202020] border border-[#C5A059]/40 hover:opacity-90 text-white flex items-center justify-center gap-1.5 text-[9px] font-mono uppercase tracking-widest font-bold cursor-pointer transition-all rounded-none"
                >
                  <Download className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Export BibTeX</span>
                </button>
              </div>
            </div>

          </div>

          {/* BibTeX Raw Preview */}
          <div className="bg-[#141414] border border-[#C5A059]/30 p-3 flex flex-col justify-between">
            <span className="block text-[8px] font-mono uppercase tracking-widest text-[#C5A059] font-bold mb-1.5 flex items-center gap-1">
              <FileText className="w-3 h-3" />
              <span>BibTeX Bibliographical Entry</span>
            </span>
            <pre className="text-[10px] font-mono text-gray-300 leading-normal p-2.5 bg-black/40 overflow-x-auto text-left whitespace-pre-wrap select-all select-text max-h-[110px]">
              {bibtexText}
            </pre>
          </div>

        </div>

      </div>

    </div>
  );
}
