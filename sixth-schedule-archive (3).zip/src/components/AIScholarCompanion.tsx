/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, X, Send, Trash2, BookOpen, Scale, FileText, 
  Map, HelpCircle, ChevronRight, RefreshCw, MessageSquare, AlertCircle
} from "lucide-react";

interface Message {
  role: "user" | "model";
  content: string;
}

export interface CompanionContext {
  type: "case" | "debate" | "article" | "map" | "general";
  title: string;
  subtitle?: string;
  summaryText: string; // The core text we send to Gemini under the hood to ground the query
  itemData: any; // Raw object for reference
}

interface AIScholarCompanionProps {
  isOpen: boolean;
  onClose: () => void;
  activeContext: CompanionContext | null;
  onClearContext: () => void;
}

export function AIScholarCompanion({
  isOpen,
  onClose,
  activeContext,
  onClearContext
}: AIScholarCompanionProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize companion with welcome message when opened
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          role: "model",
          content: "Greetings. I am the **Constitutional AI Scholar**, a specialized counselor powered by the archive's Gemini engine. As you explore the Sixth Schedule repository, feel free to analyze any case, debate speech, or academic paper by clicking its **Scholarly Analysis** action.\n\nType any query or select the pre-loaded contextual briefs below to begin."
        }
      ]);
    }
  }, [messages]);

  // Handle auto-triggering whenever activeContext changes
  useEffect(() => {
    if (isOpen && activeContext) {
      autoTriggerContextAnalysis(activeContext);
    }
  }, [activeContext, isOpen]);

  // Scroll to bottom on updates
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading]);

  const autoTriggerContextAnalysis = (ctx: CompanionContext) => {
    // Prevent duplicate triggers if the last message is already about this title
    const formattedTitle = `**${ctx.title}**`;
    const isAlreadyTriggered = messages.some(
      m => m.role === "user" && m.content.includes(ctx.title)
    );
    if (isAlreadyTriggered) return;

    let systemPrompt = "";
    if (ctx.type === "case") {
      systemPrompt = `Perform a high-level scholarly constitutional analysis of the landmark case: **${ctx.title}** (${ctx.subtitle}).
Include historical significance within the asymmetric governance of Northeast India. Detail the balancing of custom vs statutory boundaries. Under the hood, here are the details of this legal record: ${ctx.summaryText}`;
    } else if (ctx.type === "debate") {
      systemPrompt = `Synthesize and analyze the floor perspective of original delegate **${ctx.title}** inside the 1949 debates:
- What faction of tribal autonomy or statutory oversight did they advocate?
- Explain the rhetorical force or tension regarding the Sixth Schedule's framing.
Here is the verbatim transcript block for reference: "${ctx.summaryText}"`;
    } else if (ctx.type === "article") {
      systemPrompt = `Provide a critical scholarly synthesis of the academic literature: **${ctx.title}** by ${ctx.subtitle}.
How does this paper's argument on "${ctx.summaryText}" intersect with modern public law, forest rights, or regional state reorganization records?`;
    } else if (ctx.type === "map") {
      systemPrompt = `Analyze the governance structure, history, and modern administrative challenges for the **${ctx.title}** (Constitutional paragraphs: ${ctx.subtitle || "Under the Sixth Schedule"}).
Detail local land tenure, customary judiciaries, and how they interact with State-level legislative mandates under Paragraph 3. Details: ${ctx.summaryText}`;
    } else {
      systemPrompt = `Analyze the current scholarly focus: **${ctx.title}**. ${ctx.summaryText}`;
    }

    handleSend(systemPrompt, true, ctx.title);
  };

  const handleSend = async (textToSend: string, isAutomated = false, overrideDisplayTitle?: string) => {
    if (!textToSend.trim() || isLoading) return;

    setError(null);

    // If automated, let's display a cleaner human-readable prompt in the chat box
    const displayMsg = isAutomated && overrideDisplayTitle
      ? `🔍 Analyze context: **${overrideDisplayTitle}**`
      : textToSend;

    const userMsg: Message = { role: "user", content: displayMsg };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setQuery("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/gemini/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: textToSend,
          history: messages.slice(1).map(msg => ({
            role: msg.role === "user" ? "user" : "model",
            content: msg.content
          }))
        }),
      });

      const data = await response.json();
      
      if (data.error) {
        setError(data.response || data.error);
        setMessages(prev => [
          ...prev, 
          { 
            role: "model", 
            content: `⚠️ **Analysis halted:** ${data.response || "No active secret key configured."}` 
          }
        ]);
      } else {
        setMessages(prev => [...prev, { role: "model", content: data.response }]);
      }
    } catch (err: any) {
      console.error(err);
      setError("Brief generation failed: Connection to backend server error.");
      setMessages(prev => [
        ...prev, 
        { 
          role: "model", 
          content: "⚠️ **Scholarly Proxy Offline:** The custom Node backend Server could not process this context. Double check server bindings." 
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearHistory = () => {
    setMessages([
      {
        role: "model",
        content: "Transcript database re-initialized. Ready for your next research focus."
      }
    ]);
    onClearContext();
    setError(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay mask */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-stone-950/80 z-[500] backdrop-blur-xs"
          />

          {/* Core Panel Container Slide */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-[460px] bg-[#F9F7F5] dark:bg-zinc-950 border-l border-[#C5A059]/30 shadow-2xl z-[510] flex flex-col h-full overflow-hidden"
          >
            {/* Header branding */}
            <div className="px-6 py-5 bg-stone-100 dark:bg-zinc-900 border-b border-stone-250 dark:border-zinc-850 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1 px-1.5 bg-[#631919] dark:bg-[#C5A059]/10 rounded flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-amber-500 dark:text-[#C5A059]" />
                </div>
                <div>
                  <h3 className="font-serif text-[15px] font-extrabold tracking-tight text-stone-900 dark:text-zinc-50">
                    Constitutional AI Scholar
                  </h3>
                  <span className="text-[8px] font-mono tracking-wider uppercase text-stone-400 dark:text-zinc-500 block mt-0.5">
                    Real-time Contextual Interpretations
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={clearHistory}
                  className="p-1.5 hover:bg-stone-200 dark:hover:bg-zinc-805 rounded text-stone-400 hover:text-[#631919] dark:hover:text-amber-500 transition-colors"
                  title="Clear study transcripts"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={onClose}
                  className="p-1.5 hover:bg-stone-200 dark:hover:bg-zinc-805 rounded text-stone-500 dark:text-zinc-400 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Context focus indicator */}
            {activeContext && (
              <div className="px-6 py-3.5 bg-amber-50 dark:bg-amber-950/20 border-b border-amber-200/50 dark:border-amber-900/30 flex items-center justify-between text-xs font-serif text-amber-900 dark:text-amber-300">
                <div className="flex items-center gap-2 mr-4 overflow-hidden">
                  {activeContext.type === "case" && <Scale className="w-4 h-4 text-amber-700 flex-shrink-0" />}
                  {activeContext.type === "debate" && <BookOpen className="w-4 h-4 text-amber-700 flex-shrink-0" />}
                  {activeContext.type === "article" && <FileText className="w-4 h-4 text-amber-700 flex-shrink-0" />}
                  {activeContext.type === "map" && <Map className="w-4 h-4 text-amber-700 flex-shrink-0" />}
                  
                  <div className="truncate">
                    <span className="font-semibold block text-[10px] font-mono uppercase text-amber-600 dark:text-amber-500 leading-none mb-0.5">Focusing context:</span>
                    <span className="font-bold truncate text-stone-950 dark:text-zinc-200">{activeContext.title}</span>
                  </div>
                </div>
                
                <button 
                  onClick={onClearContext}
                  className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 border border-amber-300 dark:border-amber-800/80 px-2 py-0.5 rounded hover:bg-amber-100 dark:hover:bg-amber-900/40 cursor-pointer flex-shrink-0"
                >
                  Reset Scope
                </button>
              </div>
            )}

            {/* Chat Messages scroll area */}
            <div className="flex-1 p-6 overflow-y-auto space-y-5 scrollbar-thin">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div className={`max-w-[88%] rounded-lg px-4.5 py-3.5 text-xs font-serif leading-relaxed ${
                    msg.role === "user"
                      ? "bg-[#631919] dark:bg-[#7D2222] text-white rounded-br-none font-sans font-medium"
                      : "bg-[#F3EFE9] dark:bg-zinc-900 text-stone-850 dark:text-zinc-100 border border-stone-200/80 dark:border-zinc-800/60 rounded-bl-none shadow-xs whitespace-pre-wrap select-text"
                  }`}>
                    {/* Render helper */}
                    {msg.role === "model" ? (
                      <div className="prose dark:prose-invert prose-xs max-w-none text-stone-800 dark:text-zinc-200">
                        {/* We output formatted markdown manually or parsed carefully */}
                        {msg.content}
                      </div>
                    ) : (
                      <span>{msg.content}</span>
                    )}
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-[#F3EFE9] dark:bg-zinc-900 border border-stone-200/80 dark:border-zinc-800/60 rounded-lg rounded-bl-none px-4 py-3 text-xs flex items-center gap-2.5 text-amber-700 dark:text-amber-500">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span className="font-mono tracking-wider uppercase text-[9px] font-bold">Scholar formulating brief...</span>
                  </div>
                </div>
              )}

              {error && (
                <div className="flex gap-2 p-3.5 bg-red-50 dark:bg-red-950/20 text-rose-800 dark:text-rose-450 border border-red-200/60 dark:border-red-900/40 text-[10px] font-mono rounded">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-600" />
                  <div>
                    <span className="font-bold uppercase tracking-wider block mb-0.5">Server Request Error</span>
                    <span>No Gemini secret key is currently set inside Settings &gt; Secrets. Create `GEMINI_API_KEY` to unlock full intelligence.</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!query.trim()) return;
                handleSend(query);
              }}
              className="p-4 bg-stone-100 dark:bg-zinc-900/60 border-t border-stone-200 dark:border-zinc-850"
            >
              <div className="flex gap-2 relative items-center">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={
                    activeContext 
                      ? `Inquire further about this focused document...`
                      : `Ask any Sixth Schedule constitutional question...`
                  }
                  className="flex-1 text-xs px-4 py-3 bg-white dark:bg-zinc-950 border border-stone-250 dark:border-zinc-800 focus:outline-none focus:border-[#631919] dark:focus:border-[#C5A059] rounded text-stone-900 dark:text-white placeholder:text-stone-400 dark:placeholder:text-zinc-500 font-serif"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading || !query.trim()}
                  className="p-3 bg-[#631919] dark:bg-[#C5A059] text-white dark:text-stone-950 hover:bg-amber-800 hover:text-white rounded flex items-center justify-center transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
