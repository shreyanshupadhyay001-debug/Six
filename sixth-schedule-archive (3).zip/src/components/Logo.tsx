/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";

export function Logo({ className = "w-9 h-9", darkThemeOnly = false }: { className?: string; darkThemeOnly?: boolean }) {
  // A meticulously styled responsive circular seal design representing the digital archive
  return (
    <svg
      viewBox="0 0 512 512"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Golden Outer Seal Circle */}
      <circle
        cx="256"
        cy="256"
        r="240"
        stroke="#C5A059"
        strokeWidth="10"
        fill="transparent"
      />
      <circle
        cx="256"
        cy="256"
        r="228"
        stroke="#C5A059"
        strokeWidth="2.5"
        fill="transparent"
        strokeDasharray="12 6"
      />

      {/* Styled Curved Path Labels can be done using native SVG nested text in paths if needed,
          but rendering it as crisp stylized lines or vectors ensures total cross-browser consistency without missing custom font files.
          Let's draw a beautiful center graphic of an open book, geographic core of NE India, and Roman numeral VI */}
          
      {/* Inner Shield Circle */}
      <circle
        cx="220"
        cy="256"
        r="132"
        fill="transparent"
      />

      {/* 1. Open Book / Manuscript (The Living Constitutional Record) */}
      <path
        d="M 160,340 C 190,320 220,320 256,340 C 292,320 322,320 352,340 L 352,180 C 322,160 292,160 256,180 C 220,160 190,160 160,180 Z"
        fill={darkThemeOnly ? "#1c1917" : "var(--surface)"}
        stroke="#121212"
        strokeWidth="6.5"
        className="dark:stroke-zinc-100 transition-colors"
      />

      <path
        d="M 256,180 L 256,340"
        stroke="#121212"
        strokeWidth="3.2"
        className="dark:stroke-zinc-100 transition-colors"
      />

      {/* Stylised Page Scripture Lines inside manuscript */}
      <path d="M 180,210 Q 210,200 240,210" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />
      <path d="M 180,240 Q 210,230 240,240" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />
      <path d="M 180,270 Q 210,260 240,270" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />
      <path d="M 180,300 Q 210,290 240,300" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />

      <path d="M 272,210 Q 302,200 332,210" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />
      <path d="M 272,240 Q 302,230 332,240" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />
      <path d="M 272,270 Q 302,260 332,270" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />
      <path d="M 272,300 Q 302,290 332,300" stroke="#8C8479" strokeWidth="2.5" strokeOpacity="0.4" />

      {/* 2. Northeastern Frontier Map Outline in Burgundy (superimposed in front) */}
      <path
        d="M 195,200 Q 215,190 230,175 Q 260,180 270,140 Q 310,135 340,165 L 330,220 L 290,215 Q 275,255 285,280 L 255,275 Q 240,250 215,245 Z"
        fill="#8B1A1A"
        fillOpacity="0.18"
        stroke="#8B1A1A"
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* 3. Golden Roman Numeral VI in the absolute Center (Authority Pillar) */}
      <g transform="translate(0, 0)">
        {/* V */}
        <path
          d="M 233,212 L 243,268 L 253,212"
          stroke="#C5A059"
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* I */}
        <path
          d="M 268,212 L 268,268 M 260,212 L 276,212 M 260,268 L 276,268"
          stroke="#C5A059"
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>

      {/* Circular Text labels */}
      <defs>
        <path
          id="textCurveTop"
          d="M 50,256 A 206,206 0 0,1 462,256"
          fill="none"
        />
        <path
          id="textCurveBottom"
          d="M 462,256 A 206,206 0 0,1 50,256"
          fill="none"
        />
      </defs>

      <text
        fontFamily="Georgia, serif"
        fontSize="30.5"
        fontWeight="800"
        letterSpacing="0.08em"
        fill="#1C1917"
        className="dark:fill-stone-100 transition-colors"
      >
        <textPath href="#textCurveTop" startOffset="50%" textAnchor="middle">
          SIXTH SCHEDULE ARCHIVE
        </textPath>
      </text>

      <text
        fontFamily="Georgia, serif"
        fontSize="24"
        fontWeight="bold"
        letterSpacing="0.1em"
        fill="#8C8479"
        className="dark:fill-stone-400 transition-colors"
      >
        <textPath href="#textCurveBottom" startOffset="50%" textAnchor="middle">
          LIVING CONSTITUTIONAL RECORD
        </textPath>
      </text>
    </svg>
  );
}
