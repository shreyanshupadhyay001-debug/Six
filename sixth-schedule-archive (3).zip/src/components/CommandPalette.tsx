/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, Book, FileText, Clipboard, Bookmark, HelpCircle } from "lucide-react";
import { landmarkCases } from "../data/cases";
import { academicArticles } from "../data/articles";
import { glossary, debateDays } from "../data/debates";

interface SearchResult {
  id: string;
  type: "case" | "article" | "glossary" | "shortcut";
  title: string;
  subtitle: string;
  url: string;
}

export function CommandPalette({ 
  isOpen, 
  onClose, 
  onNavigate,
  onToggleTheme
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onNavigate: (page: string) => void;
  onToggleTheme?: () => void;
}) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  useEffect(() => {
    if (!query) {
      // Default shortcuts suggestion list matching scholastic architecture
      setResults([
        { id: "s-home", type: "shortcut", title: "Go to Home / Central Gallery", subtitle: "Jump back to the main museum dashboard", url: "home" },
        { id: "s-cases", type: "shortcut", title: "Go to Supreme Court Cases Index", subtitle: "Inspect core Paragraph jurisprudence", url: "cases" },
        { id: "s-debates", type: "shortcut", title: "Go to Constituent Assembly Transcripts", subtitle: "Read verbatim 1949 floor negotiations", url: "debates" },
        { id: "s-evolution", type: "shortcut", title: "Go to Historical Timeline & Milestones", subtitle: "Trace historical modifications and boundary changes", url: "evolution" },
        { id: "s-articles", type: "shortcut", title: "Go to Academic Scholarship Portfolio", subtitle: "Curated legal reviews, EPW trials, and policy drafts", url: "articles" },
        { id: "s-citations", type: "shortcut", title: "Launch Advanced Research Citation Desk", subtitle: "Generate Chicago, MLA, APA, or Bluebook references", url: "citations" },
        { id: "s-theme", type: "shortcut", title: "Toggle Visual Mode Setup", subtitle: "Switch between Scholarly Cream and Deep Dark mode", url: "theme" },
        { id: "s-about", type: "shortcut", title: "View Charter & Editorial Information", subtitle: "Read VCPRF editorial manifesto and transparency disclosure", url: "about" }
      ]);
      return;
    }

    const q = query.toLowerCase();
    const matches: SearchResult[] = [];

    // Search cases
    landmarkCases.forEach((val) => {
      if (val.name.toLowerCase().includes(q) || val.citation.toLowerCase().includes(q) || val.issue.toLowerCase().includes(q)) {
        matches.push({
          id: val.id,
          type: "case",
          title: val.name,
          subtitle: `Jurisprudence • ${val.citation}`,
          url: "cases"
        });
      }
    });

    // Search articles
    academicArticles.forEach((val) => {
      if (val.title.toLowerCase().includes(q) || val.author.toLowerCase().includes(q) || val.abstract.toLowerCase().includes(q)) {
        matches.push({
          id: val.id,
          type: "article",
          title: val.title,
          subtitle: `Scholarship • By ${val.author}`,
          url: "articles"
        });
      }
    });

    // Search glossary
    glossary.forEach((val) => {
      if (val.term.toLowerCase().includes(q) || val.definition.toLowerCase().includes(q)) {
        matches.push({
          id: `g-${val.term}`,
          type: "glossary",
          title: val.term,
          subtitle: `Glossary Term • ${val.definition.slice(0, 70)}...`,
          url: "debates"
        });
      }
    });

    // Search debates speeches verbatim records
    debateDays.forEach((day) => {
      day.speeches.forEach((speech, speechIdx) => {
        const plainText = speech.text.replace(/<[^>]*>/g, "");
        if (speech.speaker.toLowerCase().includes(q) || plainText.toLowerCase().includes(q) || (speech.role && speech.role.toLowerCase().includes(q))) {
          matches.push({
            id: `speech-${day.id}-${speechIdx}`,
            type: "glossary",
            title: `Speech by ${speech.speaker}`,
            subtitle: `Verbatim Debates (${day.date.split("—")[0].trim()}) • "${plainText.slice(0, 60)}..."`,
            url: "debates"
          });
        }
      });
    });

    setResults(matches.slice(0, 8)); // Cap results
  }, [query]);

  // Handle Ctrl+K globally
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        if (isOpen) onClose();
        else onClose(); // Toggle trigger handled outer
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  const copyCitation = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[500] flex items-start justify-center pt-[10vh] px-4">
          
          {/* Backdrop screen fade-blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-stone-900/60 backdrop-blur-[4px]"
          />

          {/* Palette container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            className="w-full max-w-xl bg-[#F5F2ED] dark:bg-[#141414] border-2 border-[#631919] dark:border-[#C5A059] shadow-2xl overflow-hidden relative z-10 font-serif"
          >
            {/* Input wrap */}
            <div className="flex items-center gap-3 border-b border-[#C5A059]/30 px-4 py-3.5 bg-[#F5F2ED]/80 dark:bg-[#1C1C1C]">
              <Search className="w-4 h-4 text-[#631919] dark:text-[#C5A059] flex-shrink-0" />
              <input
                type="text"
                autoFocus
                placeholder="Search cases, speeches, articles, or type command..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full bg-transparent outline-none border-none text-sm text-[#141414] dark:text-[#F5F2ED] placeholder-[#141414]/40 dark:placeholder-[#F5F2ED]/40 font-sans"
              />
              <button 
                onClick={onClose}
                className="text-xxs font-sans text-[#141414]/70 dark:text-[#F5F2ED]/70 border border-[#C5A059]/30 px-1.5 py-0.5 rounded uppercase hover:bg-[#631919] hover:text-white cursor-pointer transition-all"
              >
                Esc
              </button>
            </div>

            {/* Recommendations/Results panel */}
            <div className="max-h-[340px] overflow-y-auto px-2 py-3 space-y-1 select-none bg-[#F5F2ED] dark:bg-[#141414]">
              <span className="text-[9px] font-sans font-bold text-[#631919] dark:text-[#C5A059] uppercase tracking-widest px-3 block mb-2">
                {query ? `${results.length} results matching prompt` : "Quick Library Directories"}
              </span>

              {results.length > 0 ? (
                results.map((r) => (
                  <div
                    key={r.id}
                    onClick={() => {
                      if (r.url === "theme") {
                        if (onToggleTheme) onToggleTheme();
                      } else {
                        onNavigate(r.url);
                      }
                      onClose();
                    }}
                    className="flex justify-between items-center px-3 py-2 rounded-md hover:bg-[#631919]/10 dark:hover:bg-[#C5A059]/15 border border-transparent hover:border-[#C5A059]/40 group cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      {r.type === "case" && <Bookmark className="w-4 h-4 text-[#631919] dark:text-[#C5A059]" />}
                      {r.type === "article" && <Book className="w-4 h-4 text-[#631919] dark:text-[#C5A059]" />}
                      {r.type === "glossary" && <HelpCircle className="w-4 h-4 text-[#631919] dark:text-[#C5A059]" />}
                      {r.type === "shortcut" && <FileText className="w-4 h-4 text-[#141414]/60 dark:text-[#F5F2ED]/60" />}

                      <div>
                        <h4 className="text-sm font-bold text-[#141414] dark:text-[#F5F2ED] leading-tight group-hover:text-[#631919] dark:group-hover:text-white">
                          {r.title}
                        </h4>
                        <p className="text-xxs text-[#141414]/60 dark:text-[#F5F2ED]/60 mt-0.5 font-sans">
                          {r.subtitle}
                        </p>
                      </div>
                    </div>

                    <span className="text-xxs font-sans text-[#631919] dark:text-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity">
                      Enter ↵
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-[#141414]/60 dark:text-[#F5F2ED]/60 font-serif text-sm italic">
                  No matching constitutional annotations found. Try searching for 'Ambedkar' or 'Matajog'
                </div>
              )}
            </div>

            {/* Static Citation Drawer in bottom */}
            <div className="bg-[#141414] text-[#F5F2ED] px-4 py-3 border-t border-[#C5A059]/30 flex justify-between items-center text-xxs font-sans">
              <div className="flex items-center gap-1.5 font-serif text-[#F5F2ED]/90">
                <span>Standard Bluebook Citation:</span>
                <span className="italic font-bold text-[#C5A059]">Constituent Assembly Debates, Vol. IX, 5–7 Sept. 1949.</span>
              </div>
              <button
                onClick={() => copyCitation("Constituent Assembly Debates, Vol. IX, Sixth Schedule Discussions, 5–7 September 1949, Constitution Hall, New Delhi.")}
                className="text-[#C5A059] hover:text-[#F5F2ED] cursor-pointer font-bold flex items-center gap-1 uppercase tracking-widest text-[9px] transition-colors"
              >
                <Clipboard className="w-3 h-3" />
                {copiedText ? "Copied!" : "Copy Citation"}
              </button>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
