/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface ScheduleArea {
  id: string;
  name: string;
  state: string;
  established: string;
  paragraphs: string;
  population: string;
  description: string;
  pathData: string; // SVG path
  centerText: { x: number; y: number };
}

// Custom defined SVG coordinates representing the major autonomous districts in Northeast India styled as an elegant schematic museum map
const scheduleAreas: ScheduleArea[] = [
  {
    id: "bodoland",
    name: "Bodoland Territorial Council",
    state: "Assam",
    established: "2003 (BTC Accord)",
    paragraphs: "Para 3B (40 subjects)",
    population: "3.1 Million",
    description: "Covers western Assam, comprising four contiguous districts. It is the most advanced self-governance model under Paragraph 3B with forty legislative powers.",
    pathData: "M 50,140 Q 150,130 250,150 L 250,180 Q 150,170 50,180 Z",
    centerText: { x: 150, y: 155 }
  },
  {
    id: "karbi-anglong",
    name: "Karbi Anglong Autonomous Council",
    state: "Assam",
    established: "1952 (Expanded 1995)",
    paragraphs: "Para 3A (Additional powers)",
    population: "956,000",
    description: "Centrally located in Assam, governing mountainous tracts. Upgraded in 1995 under Paragraph 3A with 15 advanced legislative subjects.",
    pathData: "M 270,160 Q 320,130 370,165 L 350,210 Q 300,180 270,160 Z",
    centerText: { x: 320, y: 175 }
  },
  {
    id: "dima-hasao",
    name: "North Cachar Hills (Dima Hasao)",
    state: "Assam",
    established: "1952 (Expanded 1995)",
    paragraphs: "Para 3A (15 subjects)",
    population: "214,000",
    description: "Govern the mountainous North Cachar tracts. A beautiful tribal hill state with specialized jurisdiction over customary land patterns.",
    pathData: "M 290,215 Q 340,190 380,225 L 360,260 Q 310,230 290,215 Z",
    centerText: { x: 335, y: 230 }
  },
  {
    id: "khasi-hills",
    name: "Khasi Hills District Council",
    state: "Meghalaya",
    established: "1952 (Original ADC)",
    paragraphs: "Original Plan (Para 3, 4, 10)",
    population: "1.2 Million",
    description: "Governs the central Meghalaya plateau. Features the complex Mylliem State / Shillong municipality border compromises debated on 7 September 1949.",
    pathData: "M 160,195 Q 210,190 260,205 L 240,245 Q 190,235 160,195 Z",
    centerText: { x: 210, y: 215 }
  },
  {
    id: "garo-hills",
    name: "Garo Hills District Council",
    state: "Meghalaya",
    established: "1952 (Original ADC)",
    paragraphs: "Original Plan (Para 3, 4, 10)",
    population: "1.0 Million",
    description: "Governs western Meghalaya. Home to the Garo (A.chik) community with specialized matrilineal customary inheritance jurisprudence.",
    pathData: "M 70,190 Q 120,185 155,195 L 155,240 Q 110,230 70,240 Z",
    centerText: { x: 110, y: 210 }
  },
  {
    id: "jaintia-hills",
    name: "Jaintia Hills District Council",
    state: "Meghalaya",
    established: "1952 (Original ADC)",
    paragraphs: "Original Plan (Para 3, 4, 10)",
    population: "395,000",
    description: "Governs eastern Meghalaya, protecting the ancient synthesized institutions of Jaintia chieftainships and customary courts.",
    pathData: "M 265,205 Q 295,208 315,212 L 310,250 Q 280,245 260,245 Z",
    centerText: { x: 288, y: 225 }
  },
  {
    id: "tripura-ttaadc",
    name: "Tripura Tribal Areas Council (TTAADC)",
    state: "Tripura",
    established: "1984 (49th Amendment)",
    paragraphs: "Para 12AA & 20BB",
    population: "1.2 Million",
    description: "Covers two-thirds of Tripura's geographical area, established under the 49th Amendment to protect native Kokborok-speaking clans.",
    pathData: "M 250,265 Q 280,270 290,285 L 270,350 Q 240,320 250,265 Z",
    centerText: { x: 268, y: 300 }
  },
  {
    id: "mara-adc",
    name: "Mara Autonomous Council",
    state: "Mizoram",
    established: "1972",
    paragraphs: "Mizoram Plan (Para 12B & 20BB)",
    population: "94,000",
    description: "Governs the southernmost extremity of Mizoram. The epicentre of the landmark 2005 Supreme Court 'Pu Myllai Hlychho' executive pleasure dispute.",
    pathData: "M 320,380 Q 345,395 355,420 L 320,440 Z",
    centerText: { x: 332, y: 410 }
  },
  {
    id: "lai-adc",
    name: "Lai Autonomous Council",
    state: "Mizoram",
    established: "1972",
    paragraphs: "Mizoram Plan (Para 12B & 20BB)",
    population: "83,000",
    description: "Governs southeastern Mizoram. Protects the distinctive Lai-dialect communities with highly developed local customary panels.",
    pathData: "M 330,340 L 360,350 L 350,390 L 320,378 Z",
    centerText: { x: 340, y: 365 }
  },
  {
    id: "chakma-adc",
    name: "Chakma Autonomous Council",
    state: "Mizoram",
    established: "1972",
    paragraphs: "Mizoram Plan (Para 12B & 20BB)",
    population: "97,000",
    description: "Covers southwestern Mizoram bordering Bangladesh, protecting the Theravada Buddhist Chakma tribal minority within a Christian-majority state.",
    pathData: "M 295,345 L 325,340 L 318,375 L 290,370 Z",
    centerText: { x: 308, y: 355 }
  }
];

export function ConstitutionalMap({ 
  onSelectState,
  onAnalyzeArea
}: { 
  onSelectState?: (state: string) => void;
  onAnalyzeArea?: (area: any) => void;
}) {
  const [selectedArea, setSelectedArea] = useState<ScheduleArea | null>(scheduleAreas[3]); // Default to Khasi Hills as center
  const [hoveredArea, setHoveredArea] = useState<ScheduleArea | null>(null);

  const activeArea = hoveredArea || selectedArea;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-zinc-50 dark:bg-zinc-950 p-6 rounded-xl border border-zinc-200 dark:border-zinc-800 transition-colors">
      
      {/* SVG Map Section */}
      <div className="lg:col-span-7 flex flex-col justify-between h-[520px] bg-zinc-100 dark:bg-zinc-900 rounded-lg p-4 border border-zinc-200 dark:border-zinc-800 relative overflow-hidden">
        
        {/* Background Grid Pattern Decors */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#e4e4e7_1px,transparent_1px),linear-gradient(to_bottom,#e4e4e7_1px,transparent_1px)] dark:bg-[linear-gradient(to_right,#27272a_1px,transparent_1px),linear-gradient(to_bottom,#27272a_1px,transparent_1px)] bg-[size:30px_30px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-60 pointer-events-none" />
        
        <div className="relative z-10 flex justify-between items-start">
          <div>
            <div className="text-[10px] font-mono tracking-widest text-amber-600 dark:text-amber-500 uppercase font-medium">Cartographic Exhibit</div>
            <h3 className="font-serif text-lg font-bold text-zinc-900 dark:text-zinc-50">Sixth Schedule Territories</h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Interactive schematic mapping of real Autonomous District Areas</p>
          </div>
          <span className="text-[9px] font-mono bg-zinc-200 dark:bg-zinc-800 px-2 py-1 rounded text-zinc-600 dark:text-zinc-400">Scale: Non-Geographical Schematic</span>
        </div>

        {/* SVG Container */}
        <div className="flex-1 flex items-center justify-center relative z-10">
          <svg
            viewBox="30 100 370 360"
            className="w-full max-w-[440px] h-auto drop-shadow-sm select-none"
            style={{ width: "100%", maxHeight: "380px" }}
          >
            {/* Outline of general borders */}
            <path
              d="M 40,110 L 390,115 L 395,320 L 370,450 Q 280,470 250,400 Z"
              fill="none"
              stroke="var(--border)"
              strokeWidth="1.5"
              strokeDasharray="4 4"
              className="opacity-50"
            />
            
            {/* SIKHIM/TIBET Label indicator */}
            <text x="50" y="125" className="text-[9px] font-mono text-zinc-400 dark:text-zinc-600 font-semibold uppercase" fill="currentColor">TIBET / CHINA</text>
            <text x="350" y="290" className="text-[9px] font-mono text-zinc-400 dark:text-zinc-600 font-semibold uppercase" fill="currentColor">MYANMAR</text>
            <text x="45" y="270" className="text-[9px] font-mono text-zinc-400 dark:text-zinc-600 font-semibold uppercase" fill="currentColor">BANGLADESH</text>

            {/* SVG Path rendering */}
            {scheduleAreas.map((area) => {
              const isActive = activeArea?.id === area.id;
              const isSelected = selectedArea?.id === area.id;
              
              let fillOpacity = "0.15";
              if (isActive) fillOpacity = "0.75";
              else if (isSelected) fillOpacity = "0.45";

              let strokeColor = "#8C8479"; // Library grey
              let fillColor = "#8B1A1A"; // Burgundy/Archival Gold

              if (area.state === "Assam") {
                fillColor = "#8B1A1A"; // Constitutional Burgundy
              } else if (area.state === "Meghalaya") {
                fillColor = "#2A5C8B"; // Judicial Blue
              } else if (area.state === "Tripura") {
                fillColor = "#B8860B"; // Archival Gold
              } else if (area.state === "Mizoram") {
                fillColor = "#2A6B4A"; // Forest Green
              }

              return (
                <g key={area.id} className="cursor-pointer">
                  {/* Outer glow aura for hover/active */}
                  <motion.path
                    d={area.pathData}
                    fill={fillColor}
                    stroke={strokeColor}
                    strokeWidth={isActive ? "2.5" : "1.2"}
                    fillOpacity={fillOpacity}
                    onClick={() => {
                      setSelectedArea(area);
                      if (onSelectState) onSelectState(area.state);
                    }}
                    onMouseEnter={() => setHoveredArea(area)}
                    onMouseLeave={() => setHoveredArea(null)}
                    initial={false}
                    animate={{ fillOpacity: parseFloat(fillOpacity) }}
                    transition={{ duration: 0.2 }}
                  />
                </g>
              );
            })}

            {/* Area point nodes to draw labels */}
            {scheduleAreas.map((area) => {
              const isActive = activeArea?.id === area.id;
              return (
                <g key={`text-${area.id}`} className="pointer-events-none">
                  <circle
                    cx={area.centerText.x}
                    cy={area.centerText.y}
                    r={isActive ? "3.5" : "1.5"}
                    fill={area.state === "Assam" ? "#8B1A1A" : area.state === "Meghalaya" ? "#2A5C8B" : area.state === "Tripura" ? "#B8860B" : "#2A6B4A"}
                    className="transition-all"
                  />
                  {isActive && (
                    <text
                      x={area.centerText.x}
                      y={area.centerText.y - 8}
                      className="font-mono text-[7px] fill-zinc-800 dark:fill-zinc-200 uppercase font-semibold text-center"
                      textAnchor="middle"
                    >
                      {area.state}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Legend */}
        <div className="flex gap-4 justify-center items-center text-[10px] font-mono relative z-10 pt-2 border-t border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full inline-block bg-[#8B1A1A]" /> <span>Assam</span></div>
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full inline-block bg-[#2A5C8B]" /> <span>Meghalaya</span></div>
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full inline-block bg-[#B8860B]" /> <span>Tripura</span></div>
          <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full inline-block bg-[#2A6B4A]" /> <span>Mizoram</span></div>
        </div>
      </div>

      {/* Metadata Detail Panel */}
      <div className="lg:col-span-5 flex flex-col justify-between bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg p-6 h-[520px] transition-colors">
        <AnimatePresence mode="wait">
          {activeArea && (
            <motion.div
              key={activeArea.id}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.2 }}
              className="flex-1 flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-medium">District Catalog</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-semibold">{activeArea.state}</span>
                </div>
                <h4 className="font-serif text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50 mb-3">{activeArea.name}</h4>
                
                {/* Meta details list */}
                <div className="space-y-2.5 text-xs font-mono my-4 pb-4 border-b border-zinc-200 dark:border-zinc-800">
                  <div className="flex justify-between"><span className="text-zinc-500">Established:</span> <span className="text-zinc-900 dark:text-zinc-100 font-medium">{activeArea.established}</span></div>
                  <div className="flex justify-between"><span className="text-zinc-500">Constitutional Basis:</span> <span className="text-zinc-900 dark:text-zinc-100 font-medium">{activeArea.paragraphs}</span></div>
                  <div className="flex justify-between"><span className="text-zinc-500">Administered Pop.:</span> <span className="text-zinc-900 dark:text-zinc-100 font-medium">{activeArea.population}</span></div>
                </div>

                <div className="space-y-4">
                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-widest text-zinc-400 dark:text-zinc-500 block mb-1">Scope of Governance</span>
                    <p className="font-serif text-sm italic text-zinc-700 dark:text-zinc-300 leading-relaxed">
                      "{activeArea.description}"
                    </p>
                  </div>

                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-widest text-zinc-400 dark:text-zinc-500 block mb-1">Constituent Assembly Context</span>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed font-serif">
                      {activeArea.state === "Assam" && "Subject of intense debates on plains trading (Paragraph 10) and boundary splits. Eventually granted expanded Paragraph 3A/3B powers to resolve sub-state identity issues."}
                      {activeArea.state === "Meghalaya" && "Debated extensively on 7 September 1949 regarding the integration of Shillong State pockets (Mylliem). Co-authored by premier Rev. J.J.M. Nichols Roy."}
                      {activeArea.state === "Tripura" && "Incorporated during the 1980s via the 49th Amendment following regional accords, bringing plains-adjacent minority territories under tribal-majority control."}
                      {activeArea.state === "Mizoram" && "Established to govern minority Mara, Lai, and Chakma tribes under Part III, settling southern border safety and religious minority protections."}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-2 mt-6">
                {onSelectState && (
                  <button
                    onClick={() => onSelectState(activeArea.state)}
                    className="w-full py-2 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-50 rounded text-xs font-mono tracking-widest uppercase transition-all border border-zinc-700 hover:border-zinc-600 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Explore {activeArea.state} Records</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                  </button>
                )}
                {onAnalyzeArea && (
                  <button
                    onClick={() => onAnalyzeArea(activeArea)}
                    className="w-full py-2 bg-[#631919] hover:bg-[#8B1A1A] dark:bg-amber-600/10 dark:hover:bg-amber-600/20 text-white dark:text-[#C5A059] border border-transparent dark:border-[#C5A059]/30 rounded text-xs font-mono tracking-widest uppercase transition-all flex items-center justify-center gap-2 cursor-pointer font-bold"
                  >
                    <span>Analyze with AI Scholar</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v18"/><path d="M3 12h18"/></svg>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
