/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";

interface Node {
  id: string;
  label: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  desc: string;
}

interface Link {
  source: string;
  target: string;
}

const graphNodes: Node[] = [
  { id: "1", label: "Sixth Schedule", x: 150, y: 150, vx: 0, vy: 0, radius: 24, color: "#8B1A1A", desc: "The foundational asymmetric constitutional framework governing scheduled hill districts under Articles 244(2) and 275(1)." },
  { id: "2", label: "Autonomy", x: 190, y: 100, vx: 0, vy: 0, radius: 18, color: "#B8860B", desc: "Inherent legislative, executive, and judicial powers vested in elected tribal authorities to regulate internal affairs." },
  { id: "3", label: "District Councils", x: 230, y: 180, vx: 0, vy: 0, radius: 18, color: "#2B4C7E", desc: "Elected corporate administrative bodies (ADCs) governing primary and secondary local issues within scheduled districts." },
  { id: "4", label: "Regional Councils", x: 100, y: 220, vx: 0, vy: 0, radius: 14, color: "#2A6B4A", desc: "Elected local bodies focused on smaller, specific tribal subgroups within a multi-ethnic autonomous district." },
  { id: "5", label: "Customary Law", x: 80, y: 120, vx: 0, vy: 0, radius: 16, color: "#B8860B", desc: "Uncodified tribal codes on marriage, inheritance, and social customs guaranteed under Paragraph 3." },
  { id: "6", label: "Land Rights", x: 240, y: 80, vx: 0, vy: 0, radius: 16, color: "#8B1A1A", desc: "Constitutional protections against land alienation, granting councils sole powers of allotment and cesses." },
  { id: "7", label: "Governor", x: 300, y: 130, vx: 0, vy: 0, radius: 18, color: "#6A1B9A", desc: "The executive supervisory head, acting on Cabinet advice for inner tracts and in discretionary agency for frontier tracts." },
  { id: "8", label: "Federalism", x: 160, y: 260, vx: 0, vy: 0, radius: 18, color: "#2B4C7E", desc: "Asymmetric federal model accommodating regional identity, bringing hill tracts under state ties without assimilation." },
  { id: "9", label: "Judicial Review", x: 50, y: 180, vx: 0, vy: 0, radius: 16, color: "#8B1A1A", desc: "The jurisdiction of the High Court and Supreme Court to test council laws and actions for constitutional boundaries." },
  { id: "10", label: "Parliament", x: 330, y: 200, vx: 0, vy: 0, radius: 18, color: "#2E7D32", desc: "The sovereign national legislature with sole powers to amend the Schedule under Paragraph 21." },
  { id: "11", label: "Supreme Court", x: 50, y: 280, vx: 0, vy: 0, radius: 18, color: "#8B1A1A", desc: "The highest appellate forum responsible for interpreting discretionary powers and fundamental rights limit boundaries." },
  { id: "12", label: "State Governments", x: 360, y: 100, vx: 0, vy: 0, radius: 16, color: "#37474F", desc: "State cabinets with coordinate executive authority and legislative supremacy on concurrent topics (Para 12A/12B)." }
];

const graphLinks: Link[] = [
  { source: "1", target: "2" },
  { source: "1", target: "3" },
  { source: "1", target: "4" },
  { source: "1", target: "8" },
  { source: "3", target: "2" },
  { source: "3", target: "5" },
  { source: "3", target: "6" },
  { source: "4", target: "5" },
  { source: "1", target: "7" },
  { source: "7", target: "1" },
  { source: "10", target: "1" },
  { source: "9", target: "1" },
  { source: "11", target: "9" },
  { source: "7", target: "12" },
  { source: "12", target: "3" },
  { source: "5", target: "9" },
  { source: "6", target: "2" }
];

export function KnowledgeGraph() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  
  const [selectedNode, setSelectedNode] = useState<Node>(graphNodes[0]);
  const [hoveredNode, setHoveredNode] = useState<Node | null>(null);
  const nodesRef = useRef<Node[]>(
    graphNodes.map((n) => ({ ...n, x: Math.random() * 400 + 100, y: Math.random() * 250 + 100 }))
  );
  const [draggedNode, setDraggedNode] = useState<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;

    const resizeCanvas = () => {
      if (containerRef.current && canvasRef.current) {
        const dpr = window.devicePixelRatio || 1;
        const rect = containerRef.current.getBoundingClientRect();
        canvasRef.current.width = rect.width * dpr;
        canvasRef.current.height = 420 * dpr;
        canvasRef.current.style.width = `${rect.width}px`;
        canvasRef.current.style.height = `420px`;
        ctx.scale(dpr, dpr);
      }
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Forces Simulation
    const updatePhysics = () => {
      const nodes = nodesRef.current;
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = 420;

      // 1. Central attraction
      const cx = width / 2;
      const cy = height / 2;

      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        if (i === draggedNode) continue; // Skip forces on currently dragged node

        // Constant gravity pull to center
        node.vx += (cx - node.x) * 0.001;
        node.vy += (cy - node.y) * 0.001;

        // 2. Node-node electrostatic repulsion
        for (let j = 0; j < nodes.length; j++) {
          if (i === j) continue;
          const other = nodes[j];
          const dx = node.x - other.x;
          const dy = node.y - other.y;
          const distSq = dx * dx + dy * dy || 1;
          const dist = Math.sqrt(distSq);

          if (dist < 180) {
            const force = (180 - dist) * 0.035;
            node.vx += (dx / dist) * force * 0.035;
            node.vy += (dy / dist) * force * 0.035;
          }
        }
      }

      // 3. Link spring tension
      for (const link of graphLinks) {
        const sIdx = nodes.findIndex((n) => n.id === link.source);
        const tIdx = nodes.findIndex((n) => n.id === link.target);
        if (sIdx === -1 || tIdx === -1) continue;

        const source = nodes[sIdx];
        const target = nodes[tIdx];

        const dx = target.x - source.x;
        const dy = target.y - source.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const targetDist = 90; // Preferred link length
        const stretch = dist - targetDist;
        const springForce = stretch * 0.0035;

        const fx = (dx / dist) * springForce;
        const fy = (dy / dist) * springForce;

        if (sIdx !== draggedNode) {
          source.vx += fx;
          source.vy += fy;
        }
        if (tIdx !== draggedNode) {
          target.vx -= fx;
          target.vy -= fy;
        }
      }

      // 4. Update coordinates & boundaries
      for (const node of nodes) {
        node.vx *= 0.88; // Friction damping
        node.vy *= 0.88;

        node.x += node.vx;
        node.y += node.vy;

        // Keep inside canvas borders
        const padding = 30;
        if (node.x < padding) { node.x = padding; node.vx = 0; }
        if (node.x > width - padding) { node.x = width - padding; node.vx = 0; }
        if (node.y < padding) { node.y = padding; node.vy = 0; }
        if (node.y > height - padding) { node.y = height - padding; node.vy = 0; }
      }
    };

    const draw = () => {
      updatePhysics();
      const nodes = nodesRef.current;
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = 420;

      ctx.clearRect(0, 0, width, height);

      // Support theme values dynamically
      const isDark = document.documentElement.getAttribute("data-theme") === "dark";
      const edgeColor = isDark ? "rgba(224, 224, 232, 0.12)" : "rgba(26, 22, 20, 0.1)";
      const highlightedEdgeColor = isDark ? "rgba(212, 175, 55, 0.55)" : "rgba(139, 26, 26, 0.4)";
      const labelColor = isDark ? "#c0c0b8" : "#5d5c58";

      // 1. Draw Links
      ctx.lineWidth = 1;
      for (const link of graphLinks) {
        const source = nodes.find((n) => n.id === link.source);
        const target = nodes.find((n) => n.id === link.target);
        if (!source || !target) continue;

        const isHighlighted = (hoveredNode && (hoveredNode.id === source.id || hoveredNode.id === target.id)) ||
                            (selectedNode && (selectedNode.id === source.id || selectedNode.id === target.id));

        ctx.strokeStyle = isHighlighted ? highlightedEdgeColor : edgeColor;
        ctx.lineWidth = isHighlighted ? 2.2 : 1;
        ctx.beginPath();
        ctx.moveTo(source.x, source.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
      }

      // 2. Draw Nodes
      for (const node of nodes) {
        const isHovered = hoveredNode?.id === node.id;
        const isSelected = selectedNode?.id === node.id;

        // Aura glow
        if (isHovered || isSelected) {
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.radius + (isHovered ? 8 : 4), 0, Math.PI * 2);
          ctx.fillStyle = node.color + "1a"; // 10% opacity
          ctx.fill();
        }

        // Main sphere
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
        ctx.fillStyle = node.color;
        ctx.fill();

        ctx.strokeStyle = isSelected ? "#FFFFFF" : isHovered ? "#B8860B" : "rgba(255,255,255,0.4)";
        ctx.lineWidth = isSelected ? 2.5 : 1.2;
        ctx.stroke();

        // Node Label
        ctx.font = "bold 9px 'JetBrains Mono', monospace";
        ctx.fillStyle = isHovered || isSelected ? (isDark ? "#ffffff" : "#1a1614") : labelColor;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(node.label, node.x, node.y + node.radius + 12);
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", resizeCanvas);
    };
  }, [draggedNode, hoveredNode, selectedNode]);

  // Native mouse drag / hover handlers
  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const m = getMousePos(e);
    const nodes = nodesRef.current;

    if (draggedNode !== null) {
      nodes[draggedNode].x = m.x;
      nodes[draggedNode].y = m.y;
      return;
    }

    let found: Node | null = null;
    for (const node of nodes) {
      const dx = node.x - m.x;
      const dy = node.y - m.y;
      if (dx * dx + dy * dy < (node.radius + 10) * (node.radius + 10)) {
        found = node;
        break;
      }
    }
    setHoveredNode(found);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const m = getMousePos(e);
    const nodes = nodesRef.current;

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      const dx = node.x - m.x;
      const dy = node.y - m.y;
      if (dx * dx + dy * dy < node.radius * node.radius) {
        setDraggedNode(i);
        setSelectedNode(node);
        break;
      }
    }
  };

  const handleMouseUp = () => {
    setDraggedNode(null);
  };

  const currentlyActive = hoveredNode || selectedNode;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-zinc-50 dark:bg-zinc-950 p-6 rounded-xl border border-zinc-200 dark:border-zinc-800 transition-colors">
      
      {/* Node simulation view */}
      <div 
        ref={containerRef}
        className="lg:col-span-8 h-[420px] bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg relative overflow-hidden flex items-center justify-center cursor-grab active:cursor-grabbing"
      >
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="block"
        />
        <div className="absolute top-4 left-4 pointer-events-none">
          <div className="text-[10px] font-mono tracking-widest text-amber-600 dark:text-amber-500 uppercase font-medium">Physics Graph</div>
          <h3 className="font-serif text-base font-bold text-zinc-900 dark:text-zinc-50">Interactive Constitutional Synapses</h3>
        </div>
        <div className="absolute bottom-4 right-4 pointer-events-none text-[8px] font-mono text-zinc-400 dark:text-zinc-600">
          Drag nodes to explore forces • Click node to read annotation
        </div>
      </div>

      {/* Narrative Side Detail Panel */}
      <div className="lg:col-span-4 flex flex-col justify-between bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg p-6 h-[420px] transition-colors">
        {currentlyActive ? (
          <div className="flex-1 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-2">
                <span className="text-[9px] font-mono tracking-widest text-zinc-400 dark:text-zinc-500 uppercase font-semibold">Thematic Synapse</span>
                <span 
                  className="w-2.5 h-2.5 rounded-full inline-block"
                  style={{ backgroundColor: currentlyActive.color }}
                />
              </div>
              <h4 className="font-serif text-xl font-bold text-zinc-900 dark:text-zinc-50 tracking-tight leading-tight mb-3">
                {currentlyActive.label}
              </h4>
              <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed font-serif italic mb-4">
                "{currentlyActive.desc}"
              </p>
            </div>
            
            <div className="space-y-3 pt-4 border-t border-zinc-200 dark:border-zinc-800 text-[10px] font-mono text-zinc-500">
              <span className="uppercase tracking-widest text-[8px] text-zinc-400 font-semibold block">Cross Connections</span>
              <div className="flex flex-wrap gap-1.5">
                {graphLinks
                  .filter((l) => l.source === currentlyActive.id || l.target === currentlyActive.id)
                  .map((l) => {
                    const connId = l.source === currentlyActive.id ? l.target : l.source;
                    const connNode = graphNodes.find((n) => n.id === connId);
                    return connNode ? (
                      <span 
                        key={l.source + l.target} 
                        className="px-2 py-1 rounded bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 pointer-events-none"
                      >
                        ↔ {connNode.label}
                      </span>
                    ) : null;
                  })}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center text-zinc-400 dark:text-zinc-600 font-serif">
            <svg className="w-8 h-8 opacity-40 mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94-3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
            </svg>
            <p className="text-sm italic">Click on any node in the graph synapse to illuminate its constitutional correlation</p>
          </div>
        )}
      </div>

    </div>
  );
}
