/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Building, BookOpen, Compass, Scale, History, MapPin, 
  Search, Sun, Moon, Sparkles, Terminal, Copy, Check, 
  HelpCircle, ChevronRight, FileText, Landmark, Clock, ArrowRight,
  TrendingUp, Award, Newspaper, Shield, FileCheck
} from "lucide-react";

import { Logo } from "./components/Logo";
import { ConstitutionalMap } from "./components/ConstitutionalMap";
import { KnowledgeGraph } from "./components/KnowledgeGraph";
import { CommandPalette } from "./components/CommandPalette";
import { CitationDesk } from "./components/CitationDesk";
import { AIScholarDesk } from "./components/AIScholarDesk";
import { AIScholarCompanion, CompanionContext } from "./components/AIScholarCompanion";

// Import structured dataset
import { landmarkCases } from "./data/cases";
import { evolutionMilestones } from "./data/evolution";
import { academicArticles } from "./data/articles";
import { newsUpdates } from "./data/news";
import { debateDays, originalParagraphs, originalAmendments, speakerProfiles, glossary } from "./data/debates";

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("home");
  const [theme, setTheme] = useState<"light" | "dark">("light");
  
  // Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTopic, setActiveTopic] = useState("all");
  const [activeEra, setActiveEra] = useState("all");
  const [activeState, setActiveState] = useState("all");

  // Interaction features states
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>("case-4"); // default open Sangma
  const [selectedSpeakerId, setSelectedSpeakerId] = useState<string | null>("spk-ambedkar");
  const [activeDebateDay, setActiveDebateDay] = useState("day-1");
  const [activeParaNum, setActiveParaNum] = useState("1");
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Citation generator state
  const [citationFormat, setCitationFormat] = useState<"Bluebook" | "APA" | "Chicago">("Bluebook");
  const [citationType, setCitationType] = useState<"case" | "article" | "debate">("case");
  const [citationId, setCitationId] = useState<string>("");
  const [citationSpeechIdx, setCitationSpeechIdx] = useState<number>(-1);

  // Companion States
  const [isCompanionOpen, setIsCompanionOpen] = useState(false);
  const [companionContext, setCompanionContext] = useState<CompanionContext | null>(null);

  const openCompanionWithContext = (context: CompanionContext) => {
    setCompanionContext(context);
    setIsCompanionOpen(true);
  };

  // Loading screen trigger
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 900);
    return () => clearTimeout(timer);
  }, []);

  // Theme Sync
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
      root.setAttribute("data-theme", "dark");
    } else {
      root.classList.remove("dark");
      root.setAttribute("data-theme", "light");
    }
  }, [theme]);

  // Reading progress scroll tracker
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setReadingProgress((window.scrollY / totalScroll) * 100);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Keyboard shortcut Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        setIsCommandOpen(prev => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const toggleTheme = () => setTheme(prev => (prev === "light" ? "dark" : "light"));

  const copyToClipboard = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(identifier);
    setTimeout(() => setCopiedText(null), 1500);
  };

  const getCitationText = () => {
    if (citationFormat === "Bluebook") {
      return "CONSTITUENT ASSEMBLY DEBATES, Vol. IX, Sixth Schedule discussions, 5–7 September 1949, reprinted by Lok Sabha Secretariat, New Delhi (2014) [6th Reprint].";
    } else if (citationFormat === "APA") {
      return "Constituent Assembly of India. (1949). Constituent Assembly Debates (Vol. IX, pp. 1003-1099). New Delhi: Lok Sabha Secretariat.";
    } else {
      return "Constituent Assembly of India, Constituent Assembly Debates, vol. IX (New Delhi: Lok Sabha Secretariat, 1949), 1003-1099.";
    }
  };

  // Navigations routing trigger helper
  const navigateTo = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const navigateToCitation = (type: "case" | "article" | "debate", id: string, speechIndex: number = -1) => {
    setCitationType(type);
    setCitationId(id);
    setCitationSpeechIdx(speechIndex);
    setCurrentPage("citations");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-stone-100 dark:bg-zinc-950 flex flex-col items-center justify-center z-50 transition-colors">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center"
        >
          <Logo className="w-24 h-24 text-amber-700 mb-6 drop-shadow-md animate-pulse" />
          <h2 className="font-serif text-xl font-bold tracking-tight text-stone-900 dark:text-zinc-50">SIXTH SCHEDULE ARCHIVE</h2>
          <div className="w-16 h-[2.5px] bg-amber-700/60 mt-3 rounded-full overflow-hidden relative">
            <motion.div 
              initial={{ left: "-100%" }}
              animate={{ left: "100%" }}
              transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
              className="absolute top-0 bottom-0 w-8 bg-amber-600"
            />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase tracking-widest mt-3">Pluralism • Autonomy • Legitimate Record</span>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F2ED] dark:bg-[#141414] text-[#141414] dark:text-[#F5F2ED] border-[12px] border-[#631919] transition-all flex flex-col font-sans select-text pb-0">
      
      {/* Scroll progress loading bar */}
      <div 
        className="fixed top-0 left-0 h-1 bg-amber-700 dark:bg-amber-500 z-[600] transition-all"
        style={{ width: `${readingProgress}%` }}
      />

      {/* COMMAND PALETTE CONTAINER */}
      <CommandPalette 
        isOpen={isCommandOpen} 
        onClose={() => setIsCommandOpen(false)} 
        onNavigate={navigateTo} 
        onToggleTheme={toggleTheme}
      />

      {/* INSTITUTIONAL HEADER & NAVIGATION */}
      <nav className="sticky top-0 z-[400] bg-[#F5F2ED]/95 dark:bg-[#141414]/95 border-b border-[#C5A059]/30 backdrop-blur-md px-8 flex items-center justify-between h-16 transition-colors shadow-sm">
        
        {/* BRAND */}
        <button onClick={() => navigateTo("home")} className="flex items-center gap-3 text-left focus:outline-none cursor-pointer">
          <Logo className="w-9 h-9 text-[#631919] dark:text-[#C5A059] drop-shadow-sm transition-colors" />
          <div className="leading-none">
            <h1 className="font-serif text-[15px] sm:text-[16px] font-black tracking-widest text-[#141414] dark:text-white">SIXTH SCHEDULE ARCHIVE</h1>
            <span className="text-[8px] font-mono text-[#631919] dark:text-[#C5A059] uppercase tracking-[0.2em] font-bold mt-1 block">Living Constitutional Record</span>
          </div>
        </button>

        {/* MID NAVIGATION ROW */}
        <div className="hidden lg:flex items-center gap-1">
          {[
            { id: "home", label: "Home" },
            { id: "cases", label: "Cases" },
            { id: "debates", label: "Debates" },
            { id: "evolution", label: "Evolution" },
            { id: "articles", label: "Articles" },
            { id: "citations", label: "Citation Desk" },
            { id: "news", label: "News" },
            { id: "ai-scholar", label: "AI Scholar" },
            { id: "about", label: "About" }
          ].map((link) => (
            <button
              key={link.id}
              onClick={() => navigateTo(link.id)}
              className={`text-[10px] font-mono uppercase tracking-[0.2em] px-3.5 py-1.5 transition-all cursor-pointer border-b-2 ${
                currentPage === link.id 
                  ? "border-[#631919] dark:border-[#C5A059] text-[#631919] dark:text-[#C5A059] font-black" 
                  : "border-transparent text-[#141414]/70 dark:text-[#F5F2ED]/70 hover:text-[#631919] dark:hover:text-[#C5A059]"
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* UTILS SIDE ROW */}
        <div className="flex items-center gap-3">
          
          {/* Quick Find Control */}
          <button 
            onClick={() => setIsCommandOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 bg-[#141414] dark:bg-[#F5F2ED] border border-[#631919] dark:border-[#C5A059] text-[#F5F2ED] dark:text-[#141414] hover:opacity-95 transition-all font-mono text-[9px] uppercase tracking-widest select-none cursor-pointer hidden md:flex"
          >
            <Search className="w-3.5 h-3.5 text-[#C5A059] dark:text-[#631919]" />
            <span>Search</span>
            <kbd className="opacity-50 text-[8px] font-sans border-l border-white/20 dark:border-black/20 pl-1.5 font-bold">CTRL+K</kbd>
          </button>

          {/* Theme Switch */}
          <button 
            onClick={toggleTheme}
            className="p-2 border border-[#C5A059]/30 hover:border-[#631919] dark:hover:border-[#C5A059] rounded-full text-[#141414]/70 dark:text-[#F5F2ED]/70 hover:text-[#631919] dark:hover:text-white transition-all cursor-pointer"
            aria-label="Toggle Theme Schema"
          >
            {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-[#C5A059]" />}
          </button>

        </div>
      </nav>

      {/* CORE VIEW SHELL SWITCH */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.3, cubicBezier: [0.16, 1, 0.3, 1] }}
          className="flex-1"
        >
          
          {/* ==================================== */}
          {/* 1. HOMEPAGE REDESIGN (CENTRAL MUSEUM) */}
          {/* ==================================== */}
          {currentPage === "home" && (
            <div>
              
              {/* SECTION 1: IMMERSIVE HERO WITH SUBTLE GRID */}
              <header className="relative bg-[#F9F7F5] dark:bg-[#1A1A1A] border-b border-[#C5A059]/30 pt-20 pb-20 px-6 overflow-hidden">
                {/* Micro particle coordinate grid decors */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#e4e4e7_1px,transparent_1px),linear-gradient(to_bottom,#e4e4e7_1px,transparent_1px)] dark:bg-[linear-gradient(to_right,#27272a_1px,transparent_1px),linear-gradient(to_bottom,#27272a_1px,transparent_1px)] bg-[size:40px_40px] opacity-20 [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />
                
                <div className="max-w-4xl mx-auto text-center relative z-10">
                  
                  {/* Decorative Header Badge */}
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="inline-flex items-center gap-2 text-[10px] font-mono tracking-widest text-[#631919] dark:text-[#C5A059] bg-[#631919]/5 dark:bg-[#C5A059]/10 border border-[#C5A059]/40 px-4 py-1.5 rounded-full uppercase mb-6 font-bold"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>The Constitution's Most Distinct Experiment in Self-Governance</span>
                  </motion.div>

                  <h1 className="font-serif text-4xl sm:text-6xl font-black tracking-tight text-[#141414] dark:text-white mb-6 leading-tight">
                    Sixth Schedule Archive
                  </h1>

                  <p className="font-serif italic text-lg sm:text-xl text-[#141414]/70 dark:text-[#F5F2ED]/70 max-w-2xl mx-auto leading-relaxed font-light mb-12">
                    A Living Constitutional Record of Indigenous Governance, Autonomous Institutions, Constitutional Design and Judicial Interpretation.
                  </p>

                  {/* Actions Drawer */}
                  <div className="flex flex-col sm:flex-row gap-4 justify-center items-center font-mono text-[11px] tracking-widest uppercase">
                    
                    <button 
                      onClick={() => navigateTo("debates")}
                      className="px-8 py-3.5 bg-[#631919] hover:bg-[#8B1A1A] text-white border border-[#C5A059]/40 hover:border-[#C5A059] transition-all font-bold cursor-pointer shadow-md select-none flex items-center gap-2 group rounded-none"
                    >
                      Enter Central Transcripts
                      <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                    </button>

                    <button 
                      onClick={() => setIsCommandOpen(true)}
                      className="px-8 py-3.5 bg-transparent border border-[#631919] dark:border-[#C5A059] text-[#141414] dark:text-[#F5F2ED] hover:bg-[#631919]/5 dark:hover:bg-[#C5A059]/5 transition-all cursor-pointer font-bold select-none rounded-none"
                    >
                      Key Command Index (Ctrl+K)
                    </button>

                  </div>

                </div>
              </header>

              {/* SECTION 2: ARCHIVE AT A GLANCE (STATISTICS) */}
              <section className="bg-stone-50 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-5xl mx-auto">
                  <div className="text-center mb-10">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500">Museum Census</span>
                    <h2 className="font-serif text-2xl font-bold tracking-tight text-stone-900 dark:text-zinc-100">The Archive by the Numbers</h2>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
                    {[
                      { num: "21", label: "Constitutional Paras" },
                      { num: "4", label: "States Covered" },
                      { num: "3", label: "Assembly Sessions" },
                      { num: "7", label: "Major Amendments" },
                      { num: "74+", label: "Landmark Cases" },
                      { num: "10", label: "Autonomous Districts" }
                    ].map((st, i) => (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.05 }}
                        key={st.label}
                        className="bg-stone-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800/80 rounded p-4 text-center"
                      >
                        <div className="font-serif text-3xl font-extrabold text-amber-700 dark:text-amber-500 tracking-tight leading-none mb-1.5">{st.num}</div>
                        <div className="text-[9px] font-mono uppercase tracking-widest text-stone-500 dark:text-zinc-400 font-medium leading-tight">{st.label}</div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </section>

              {/* SECTION 3: CONSTITUTIONAL MAP */}
              <section className="bg-stone-100 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-5xl mx-auto">
                  <div className="text-center mb-10">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500">Cartographic Study</span>
                    <h2 className="font-serif text-3xl font-bold tracking-tight text-stone-900 dark:text-zinc-100">Geography of Asymmetry</h2>
                    <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-lg mx-auto">Interact with the schematic map below to read specialized constitutional basis, history, and population records for real council territories.</p>
                  </div>

                  <ConstitutionalMap 
                    onSelectState={(st) => {
                      setActiveState(st);
                      setCurrentPage("articles");
                    }}
                    onAnalyzeArea={(area) => {
                      openCompanionWithContext({
                        type: "map",
                        title: area.name,
                        subtitle: `${area.paragraphs} (${area.state})`,
                        summaryText: `Autonomous District Council: ${area.name}. State: ${area.state}. Established: ${area.established}. Constitutional basis/paragraphs: ${area.paragraphs}. Population: ${area.population}. Historical and legal info: ${area.description}`,
                        itemData: area
                      });
                    }}
                  />
                </div>
              </section>

              {/* SECTION 4: KNOWLEDGE EXPLORER (SIX ARCHIVE CARDS) */}
              <section className="bg-stone-50 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-5xl mx-auto">
                  <div className="text-center mb-12">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500 font-semibold text-center">Comprehensive Exhibits</span>
                    <h2 className="font-serif text-3xl font-bold text-stone-900 dark:text-zinc-100 tracking-tight text-center mt-1">Knowledge Explorer</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[
                      { 
                        id: "cases", 
                        icon: <Scale className="w-5 h-5 text-amber-700" />, 
                        title: "Supreme Court Jurisprudence", 
                        summary: "Seven decades of landmark court decisions from both Supreme and High forums.", 
                        scope: "Judges, citations, holding summaries,, and legal boundaries of Paragraph powers.",
                        materials: "Matajog Dobey, Sangma, Pu Myllai Hlychho"
                      },
                      { 
                        id: "debates", 
                        icon: <FileText className="w-5 h-5 text-amber-700" />, 
                        title: "Constituent Assembly Debates", 
                        summary: "Verbatim debates across 5–7 September 1949 with full speaker catalogs and profiles.", 
                        scope: "Red Indian reservation trilemmas, trading safeguards, and regional border tensions.",
                        materials: "Ambedkar, Chaliha, Gopinath Bordoloi"
                      },
                      { 
                        id: "evolution", 
                        icon: <History className="w-5 h-5 text-amber-700" />, 
                        title: "Historical Timeline", 
                        summary: "From 1935 excluded area acts to Bodoland innovations and Ladakh negotiations.", 
                        scope: "A clean chronological timeline mapping the transformation of asymmetric federal design.",
                        materials: "1935 Act, 1972 Meghalaya creation, 2003 BTC Accord"
                      },
                      { 
                        id: "articles", 
                        icon: <BookOpen className="w-5 h-5 text-amber-700" />, 
                        title: "Academic Scholarship", 
                        summary: "Curated collection of legal treatises, law review papers, and policy reviews.", 
                        scope: "Dailies, EPW, Oxford Journals, and comparative law of indigenous autonomies.",
                        materials: "Prof. Nandini Sundar, S. Baruah, T. Woolman Articles"
                      },
                      { 
                        id: "news", 
                        icon: <Newspaper className="w-5 h-5 text-amber-700" />, 
                        title: "Current Affairs & Updates", 
                        summary: "Live news indices, committee submissions, and recent administrative updates.", 
                        scope: "Tracking the frontier Ladakh negotiations and environmental green bans in Jaintia hills.",
                        materials: "Standing Committee No. 247, NGT rulings index"
                      },
                      { 
                        id: "about", 
                        icon: <Shield className="w-5 h-5 text-amber-700" />, 
                        title: "Editorial Standards & Sources", 
                        summary: "Transparency declaration, Bluebook systems, and data source framework.", 
                        scope: "Veritas Policy Foundation's methodology guidelines for scholarly accuracy.",
                        materials: "VCPRF citation manuals, archival records index"
                      }
                    ].map((ex) => (
                      <button 
                        key={ex.id}
                        onClick={() => navigateTo(ex.id)}
                        className="text-left bg-stone-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg p-6 focus:outline-none hover:border-amber-700 dark:hover:border-amber-500 hover:shadow-lg transition-all flex flex-col justify-between group cursor-pointer"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-4">
                            <div className="p-2 bg-stone-200 dark:bg-zinc-800 rounded">{ex.icon}</div>
                            <span className="text-[10px] font-mono uppercase tracking-widest text-stone-400 dark:text-zinc-500 font-semibold">Exhibit</span>
                          </div>

                          <h3 className="font-serif text-lg font-bold text-stone-900 dark:text-zinc-50 mb-2 leading-tight group-hover:text-amber-800 dark:group-hover:text-amber-400">{ex.title}</h3>
                          <p className="text-xs text-stone-500 dark:text-zinc-400 mb-4 leading-relaxed font-serif italic">"{ex.summary}"</p>
                          
                          <div className="space-y-2 mt-4 pt-4 border-t border-stone-200 dark:border-zinc-800 font-mono text-[9px] text-stone-400 dark:text-zinc-500">
                            <div><span className="uppercase font-bold block text-stone-500">Scope of Research:</span> {ex.scope}</div>
                            <div><span className="uppercase font-bold block text-stone-500">Principal Materials:</span> {ex.materials}</div>
                          </div>
                        </div>

                        <span className="text-[10px] font-mono tracking-widest text-amber-700 dark:text-amber-500 group-hover:translate-x-1.5 transition-transform flex items-center gap-1 mt-6 font-semibold uppercase">
                          Examine Repository
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </section>

              {/* SECTION 5: CONSTITUTIONAL TIMELINE PREVIEW */}
              <section className="bg-stone-100 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-4xl mx-auto">
                  <div className="text-center mb-12">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500">Historical Footprint</span>
                    <h2 className="font-serif text-3xl font-bold tracking-tight text-stone-900 dark:text-zinc-100">Evolution Chronology</h2>
                  </div>

                  <div className="space-y-8 relative pl-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[1.5px] before:bg-stone-300 dark:before:bg-zinc-800">
                    {[
                      { year: "1935", title: "Excluded Areas Act", d: "GoI Act establishing direct colonial governorship of the northeastern frontier hill districts." },
                      { year: "1947", title: "Assam Hills Sub-Committee", d: "Premier Gopinath Bordoloi maps custom council safeguards, writing the seed code of the ADCs." },
                      { year: "1949", title: "Constituent Assembly Floor adoption", d: "Verbatim debate on Red Indian reservation templates, placing the schedule to vote on 5–7 September." },
                      { year: "2003", title: "The Bodoland Accords (BTC)", d: "Paragraph 3B addition, granting advanced self-governing subjects to western Assam's Bodoland." }
                    ].map((mi) => (
                      <div key={mi.year} className="relative group">
                        <span className="absolute -left-[30px] top-1.5 w-3 h-3 rounded-full bg-stone-100 dark:bg-zinc-950 border-2 border-amber-700 group-hover:bg-amber-750 transition-colors" />
                        <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-500 block mb-0.5">{mi.year}</span>
                        <h4 className="font-serif text-base font-bold text-stone-900 dark:text-zinc-100">{mi.title}</h4>
                        <p className="text-xs text-stone-500 dark:text-zinc-400 font-serif leading-relaxed mt-1 max-w-xl">{mi.d}</p>
                      </div>
                    ))}
                  </div>

                  <div className="text-center mt-12">
                    <button 
                      onClick={() => navigateTo("evolution")}
                      className="px-6 py-2.5 bg-stone-200 hover:bg-stone-250 dark:bg-zinc-900 dark:hover:bg-zinc-850 border border-stone-300 dark:border-zinc-800 rounded font-mono text-[10px] tracking-widest uppercase text-stone-700 dark:text-zinc-300 flex items-center gap-2 mx-auto cursor-pointer"
                    >
                      Examine Complete Evolution Timeline
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </section>

              {/* SECTION 6: KNOWLEDGE GRAPH */}
              <section className="bg-stone-50 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-5xl mx-auto">
                  <div className="text-center mb-10">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500">Logical Network map</span>
                    <h2 className="font-serif text-3xl font-bold tracking-tight text-stone-900 dark:text-zinc-100">Thematic Synapse Graph</h2>
                    <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-lg mx-auto">A live force-directed network simulation connecting concepts from Customary Law to State Cabinets and Judicial Review.</p>
                  </div>

                  <KnowledgeGraph />
                </div>
              </section>

              {/* SECTION 7: WHY IT MATTERS (PURE SCHOLARSHIP) */}
              <section className="bg-stone-100 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-4xl mx-auto text-center">
                  <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500">Scholarly Significance</span>
                  <h2 className="font-serif text-3xl font-bold tracking-tight text-stone-900 dark:text-zinc-100 mt-1 mb-6">Asymmetry and Pluralism</h2>
                  
                  <div className="space-y-6 text-sm sm:text-base text-stone-650 dark:text-zinc-300 font-serif leading-relaxed text-justify max-w-3xl mx-auto">
                    <p>
                      The Sixth Schedule of the Indian Constitution is not merely an administrative apparatus; it is a profound monument of asymmetric federalist architecture. Unlike traditional reservations that establish defensive borders around indigenous communities, the Schedule seeks to manage integration dynamically through custom-tailored self-governing District Councils.
                    </p>
                    <p>
                      By vesting elected councils with coordinates of inherent legislative, judicial, and fiscal autonomy on local matters, the Constitution provides a model that accommodates distinct ethnic aspirations without compromising the sovereignty of the national union. In a world of increasing centralisation, the record of the Sixth Schedule serves as an instructive laboratory of constitutional pluralism.
                    </p>
                  </div>
                </div>
              </section>

              {/* SECTION 8: ABOUT THE ARCHIVE (VC-PRF METADATA) */}
              <section className="bg-stone-50 dark:bg-zinc-950 py-16 px-6 border-b border-stone-200 dark:border-zinc-900 transition-colors">
                <div className="max-w-4xl mx-auto">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div>
                      <h4 className="text-[10px] font-mono tracking-widest uppercase text-stone-405 dark:text-zinc-500 font-bold mb-4">Archive Editorial Model</h4>
                      <ul className="space-y-4 font-serif text-xs text-stone-600 dark:text-zinc-400 leading-relaxed">
                        <li>
                          <strong className="text-stone-900 dark:text-zinc-200">Objective:</strong> To maintain a robust, world-class reference library that registers the exact legal, debate, and news footprints of the Sixth Schedule purely for scholastic evaluation.
                        </li>
                        <li>
                          <strong className="text-stone-900 dark:text-zinc-200">Transparency:</strong> Every verbatim transcript and legal citation is cross-referenced using standard historical archives and Lok Sabha reprints.
                        </li>
                        <li>
                          <strong className="text-stone-900 dark:text-zinc-200">Version Indexing:</strong> Incorporating all historical amendments from the 1969 reorganisation acts to 2003 Bodoland protocols.
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-mono tracking-widest uppercase text-stone-405 dark:text-zinc-500 font-bold mb-4">Veritas Centre for Policy Research</h4>
                      <p className="font-serif text-xs text-stone-600 dark:text-zinc-400 leading-relaxed mb-4">
                        The Sixth Schedule Archive is curated and maintained by the research fellows at the Veritas Centre for Policy Research Foundation (VCPRF). We are an independent, non-partisan constitutional policy group dedicated to the research of tribal rights, asymmetric federal systems, and mountain state public policies.
                      </p>
                      <button 
                        onClick={() => navigateTo("about")}
                        className="text-[10px] font-mono text-amber-700 dark:text-amber-500 font-bold uppercase tracking-wider hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        Read Curatorial Charter
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </section>

            </div>
          )}

          {/* ==================================== */}
          {/* 2. CASE REPOSITORY VIEW */}
          {/* ==================================== */}
          {currentPage === "cases" && (
            <div className="page-full">
              <div className="mb-10 text-center md:text-left">
                <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400 dark:text-zinc-500">Legal Jurisprudence</span>
                <h1 className="font-serif text-4xl font-extrabold tracking-tight text-stone-900 dark:text-zinc-50 mt-1">Landmark Court Rulings</h1>
                <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-xl">A paragraph-by-paragraph catalogue of critical Supreme Court and High Court judgments interpreting council limits and customary law controls.</p>
              </div>

              {/* Legal filtration bar */}
              <div className="flex flex-wrap gap-2 mb-8 bg-stone-100 dark:bg-zinc-900 p-3 rounded-lg border border-stone-250 dark:border-zinc-800">
                <button 
                  onClick={() => setActiveTopic("all")}
                  className={`text-[9px] font-mono px-3 py-1.5 rounded uppercase tracking-wider ${activeTopic === "all" ? "bg-amber-700 text-white font-bold" : "text-stone-500 hover:bg-stone-200/50"}`}
                >
                  All Paras
                </button>
                {["Para 1", "Para 3", "Para 5", "Para 9", "Para 12", "Constitution Bench"].map((t) => (
                  <button
                    key={t}
                    onClick={() => setActiveTopic(t)}
                    className={`text-[9px] font-mono px-3 py-1.5 rounded uppercase tracking-wider ${activeTopic === t ? "bg-amber-700 text-white font-semibold" : "text-stone-500 hover:bg-stone-200/50"}`}
                  >
                    {t}
                  </button>
                ))}
              </div>

              {/* Core catalog listings split-screen */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Left side: Case indexes list */}
                <div className="lg:col-span-5 space-y-3">
                  {landmarkCases
                    .filter((c) => activeTopic === "all" || c.tags.includes(activeTopic))
                    .map((c) => (
                      <button
                        key={c.id}
                        onClick={() => setSelectedCaseId(c.id)}
                        className={`w-full text-left p-4 rounded-lg border flex flex-col justify-between transition-all focus:outline-none cursor-pointer ${
                          selectedCaseId === c.id 
                            ? "bg-zinc-100 dark:bg-zinc-900 border-amber-700 shadow-md" 
                            : "bg-surface border-stone-250 dark:border-zinc-850 hover:bg-stone-150/40"
                        }`}
                      >
                        <div>
                          <div className="flex justify-between items-start gap-2 mb-2">
                            <span className="text-[10px] font-mono text-stone-500 dark:text-zinc-500 font-bold">{c.citation}</span>
                            <span className="text-[9px] font-mono bg-zinc-200 dark:bg-zinc-800 px-1.5 py-0.5 rounded font-bold">{c.year}</span>
                          </div>
                          <h3 className="font-serif text-md font-bold text-stone-900 dark:text-zinc-50 leading-snug group-hover:text-amber-800">{c.name}</h3>
                          
                          <div className="flex flex-wrap gap-1 mt-3">
                            {c.tags.slice(0, 3).map(t => (
                              <span key={t} className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-amber-600/10 text-amber-700 dark:text-amber-500/90 font-medium uppercase">{t}</span>
                            ))}
                          </div>
                        </div>
                      </button>
                    ))}
                </div>

                {/* Right side: Selected Case Detail Viewer */}
                <div className="lg:col-span-7 bg-zinc-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg p-6 min-h-[460px] flex flex-col justify-between shadow-sm">
                  {selectedCaseId ? (() => {
                    const c = landmarkCases.find(it => it.id === selectedCaseId);
                    if (!c) return <div className="text-center italic text-stone-400">Select a case index to view record</div>;
                    return (
                      <div className="flex flex-col justify-between h-full">
                        <div>
                          <div className="flex justify-between items-center pb-4 mb-4 border-b border-stone-250 dark:border-zinc-800 text-[10px] font-mono">
                            <span className="uppercase text-stone-400 dark:text-zinc-500 font-bold">Case Record Detail</span>
                            <div className="flex gap-4">
                              <button 
                                onClick={() => copyToClipboard(`${c.name}, ${c.citation}.`, c.id)}
                                className="text-stone-605 dark:text-zinc-350 hover:underline flex items-center gap-1 cursor-pointer font-bold"
                              >
                                <Copy className="w-3.5 h-3.5" />
                                {copiedText === c.id ? "Copied!" : "Quick Copy"}
                              </button>
                              <button 
                                onClick={() => navigateToCitation("case", c.id)}
                                className="text-amber-700 dark:text-amber-500 hover:underline flex items-center gap-1 cursor-pointer font-semibold uppercase tracking-wider text-[9px]"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                                <span>Export Citation</span>
                              </button>
                              <button 
                                onClick={() => openCompanionWithContext({
                                  type: "case",
                                  title: c.name,
                                  subtitle: c.citation,
                                  summaryText: `Citation: ${c.citation}. Court: ${c.metadata.court}. State: ${c.metadata.state}. Legal Issue: ${c.issue}. holding: ${c.holding}. excerpt: ${c.excerpt || ""}`,
                                  itemData: c
                                })}
                                className="text-[#631919] dark:text-[#C5A059] hover:underline flex items-center gap-1 cursor-pointer font-bold uppercase tracking-wider text-[9px]"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-[#C5A059] animate-pulse" />
                                <span>AI Precedent Analysis</span>
                              </button>
                            </div>
                          </div>

                          <h2 className="font-serif text-3xl font-extrabold text-stone-900 dark:text-zinc-50 leading-tight mb-2 tracking-tight">
                            {c.name}
                          </h2>
                          <div className="text-sm font-mono text-amber-750 dark:text-amber-500 font-semibold mb-6">
                            {c.citation}
                          </div>

                          {/* Meta specifications */}
                          <div className="grid grid-cols-2 gap-4 bg-stone-200/50 dark:bg-zinc-950/40 p-4 rounded border border-stone-300/40 dark:border-zinc-800 text-xs font-mono mb-6">
                            <div><span className="text-stone-400 block uppercase text-[8px] tracking-wider mb-0.5">Court Forum:</span> <span className="text-stone-900 dark:text-zinc-200 font-bold">{c.metadata.court}</span></div>
                            <div><span className="text-stone-400 block uppercase text-[8px] tracking-wider mb-0.5">Jurisdiction Scope:</span> <span className="text-stone-900 dark:text-zinc-200 font-bold">{c.metadata.state}</span></div>
                            {c.metadata.bench && <div><span className="text-stone-400 block uppercase text-[8px] tracking-wider mb-0.5">Bench:</span> <span className="text-stone-900 dark:text-zinc-200 font-bold">{c.metadata.bench}</span></div>}
                            {c.metadata.region && <div><span className="text-stone-400 block uppercase text-[8px] tracking-wider mb-0.5">Pre-Constitution Region:</span> <span className="text-stone-900 dark:text-zinc-200 font-bold">{c.metadata.region}</span></div>}
                          </div>

                          {/* Issue & Holding */}
                          <div className="space-y-5">
                            <div>
                              <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest font-black block mb-1">Legal Issue Debated</span>
                              <p className="font-serif text-sm leading-relaxed text-stone-750 dark:text-zinc-300">
                                {c.issue}
                              </p>
                            </div>

                            <div>
                              <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest font-black block mb-1">Judicial holding</span>
                              <p className="font-serif text-sm leading-relaxed text-stone-850 dark:text-zinc-200 italic font-medium">
                                "{c.holding}"
                              </p>
                            </div>

                            {c.excerpt && (
                              <div>
                                <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest font-black block mb-1">Verbatim excerpt from Judgment</span>
                                <div className="p-4 bg-stone-200/40 dark:bg-zinc-950/30 border-l-4 border-amber-700 rounded-r text-sm font-serif italic leading-relaxed text-stone-700 dark:text-zinc-300">
                                  "{c.excerpt}"
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="mt-8 pt-4 border-t border-stone-250 dark:border-zinc-800 text-[9px] font-mono text-stone-400 flex items-center gap-1.5 uppercase tracking-widest justify-center">
                          <Shield className="w-3.5 h-3.5" />
                          <span>Officially indexed Veritas Policy Database Record</span>
                        </div>
                      </div>
                    );
                  })() : (
                    <div className="flex-1 flex items-center justify-center text-center italic text-stone-400">
                      Select a landmark case on the left to read its complete legal blueprint
                    </div>
                  )}
                </div>

              </div>
            </div>
          )}

          {/* ==================================== */}
          {/* 3. CONSTITUENT ASSEMBLY SPEECHES */}
          {/* ==================================== */}
          {currentPage === "debates" && (
            <div className="page-full">
              
              <div className="text-center max-w-2xl mx-auto mb-12">
                <span className="text-[10px] font-mono tracking-widest uppercase text-stone-404">Primary Transcripts</span>
                <h1 className="font-serif text-4xl font-black text-stone-900 dark:text-zinc-50 leading-tight">CA Debates Sub-Platform</h1>
                <p className="text-sm font-serif italic text-stone-500 mt-2">The complete floor negotiations on asymmetric tribal governance from 5 to 7 September 1949, reprinted in high definition.</p>
              </div>

              {/* Sub-navigation tabs block inside CA view */}
              <div className="flex justify-center border-b border-stone-300 dark:border-zinc-800 mb-10 overflow-x-auto select-none gap-2 pb-0">
                {[
                  { id: "day-1", label: "Day 1 (5 Sept 1949)" },
                  { id: "day-2", label: "Day 2 (6 Sept 1949)" },
                  { id: "day-3", label: "Day 3 (7 Sept 1949)" },
                  { id: "all-paras", label: "Paras 1–21 (Annotated)" },
                  { id: "amendments", label: "Amendment Tracker" },
                  { id: "speakers", label: "Speaker Catalog" }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      if (t.id === "all-paras" || t.id === "amendments" || t.id === "speakers") {
                        // redirect internally
                        setActiveDebateDay(t.id);
                      } else {
                        setActiveDebateDay(t.id);
                      }
                    }}
                    className={`text-[9px] font-mono uppercase tracking-widest px-4 py-2 border-b-2 font-bold cursor-pointer transition-all ${
                      activeDebateDay === t.id 
                        ? "border-amber-700 text-amber-700 font-black" 
                        : "border-transparent text-stone-450 hover:text-stone-700 hover:border-stone-300"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* SUB TABLE 1: DAY SPEECHES */}
              {(activeDebateDay === "day-1" || activeDebateDay === "day-2" || activeDebateDay === "day-3") && (() => {
                const day = debateDays.find(d => d.id === activeDebateDay);
                if (!day) return null;
                return (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                    
                    {/* Left: General summary */}
                    <div className="lg:col-span-4 bg-zinc-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg p-6 relative overflow-hidden transition-colors">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-amber-600/5 rotate-45 transform translate-x-8 -translate-y-8" />
                      <span className="text-[10px] font-mono uppercase tracking-wider text-amber-500 block mb-1">Debate Summary</span>
                      <h3 className="font-serif text-xl font-bold tracking-tight text-stone-900 dark:text-zinc-50 mb-3">{day.date}</h3>
                      <p className="text-xs font-serif leading-relaxed text-stone-600 dark:text-zinc-400 mb-4">{day.meta}</p>
                      
                      <div className="p-4 bg-stone-200/50 dark:bg-zinc-950/40 border-l border-amber-600 font-serif text-xs leading-relaxed text-zinc-700 dark:text-zinc-300">
                        "{day.summary}"
                      </div>
                    </div>

                    {/* Right: Verbatim Speeches List */}
                    <div className="lg:col-span-8 space-y-6">
                      {day.speeches.map((sp, idx) => (
                        <div 
                          key={idx}
                          className="bg-surface border border-stone-250 dark:border-zinc-850 rounded-lg overflow-hidden group hover:border-amber-700/40 transition-colors"
                        >
                          <div className="bg-stone-100 dark:bg-zinc-900 px-6 py-4 border-b border-stone-250 dark:border-zinc-805 flex flex-col sm:flex-row justify-between sm:items-center gap-3 transition-colors">
                            <div>
                              <h4 className="font-serif text-[15px] font-bold text-stone-950 dark:text-zinc-50">{sp.speaker}</h4>
                              <span className="text-[10px] font-mono text-amber-700 dark:text-amber-500 font-semibold uppercase block mt-0.5">{sp.role}</span>
                            </div>
                            <span className="text-[10px] font-mono bg-zinc-200 dark:bg-zinc-800 px-2 py-0.5 rounded text-zinc-500">{sp.page}</span>
                          </div>

                          <div className="p-6">
                            <div 
                              className="font-serif text-sm leading-relaxed text-stone-800 dark:text-zinc-300 space-y-3 prose"
                              dangerouslySetInnerHTML={{ __html: sp.text }}
                            />
                          </div>

                          <div className="px-6 pb-4 pt-3 bg-stone-50 dark:bg-zinc-950/20 border-t border-stone-150 dark:border-zinc-850/60 flex flex-wrap justify-between items-center text-xxs font-sans text-stone-500">
                            <div>
                              {sp.outcome ? (
                                <span className="font-semibold text-rose-800 dark:text-amber-500 tracking-wide uppercase">Outcome: {sp.outcome}</span>
                              ) : (
                                <span className="text-stone-400 font-mono tracking-wider">VERBATIM RECORD</span>
                              )}
                            </div>
                            <div className="flex gap-4">
                              <button 
                                onClick={() => copyToClipboard(sp.text.replace(/<[^>]*>/g, ""), `${sp.speaker}-${idx}`)}
                                className="text-zinc-650 dark:text-zinc-350 hover:text-amber-700 flex items-center gap-1 cursor-pointer font-semibold"
                              >
                                <Copy className="w-3.5 h-3.5" />
                                {copiedText === `${sp.speaker}-${idx}` ? "Copied!" : "Copy Text"}
                              </button>
                              <button 
                                onClick={() => navigateToCitation("debate", day.id, idx)}
                                className="text-amber-700 dark:text-amber-500 hover:underline flex items-center gap-1 cursor-pointer font-semibold uppercase tracking-wider text-[9px]"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                                <span>Export Citation</span>
                              </button>
                              <button 
                                onClick={() => openCompanionWithContext({
                                  type: "debate",
                                  title: sp.speaker,
                                  subtitle: `${day.date} - ${sp.role}`,
                                  summaryText: sp.text.replace(/<[^>]*>/g, ""),
                                  itemData: sp
                                })}
                                className="text-[#631919] dark:text-[#C5A059] hover:underline flex items-center gap-1 cursor-pointer font-bold uppercase tracking-wider text-[9px]"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-[#C5A059] animate-pulse" />
                                <span>AI Perspective</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>
                );
              })()}

              {/* SUB TABLE 2: ALL PARAS ANNOTATED */}
              {activeDebateDay === "all-paras" && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Left: Interactive list of Paras */}
                  <div className="lg:col-span-4 space-y-2">
                    <span className="text-[9px] font-mono uppercase tracking-widest text-stone-400 text-center block mb-3">Paragraph Chronology</span>
                    {originalParagraphs.map((p) => (
                      <button
                        key={p.num}
                        onClick={() => setActiveParaNum(p.num)}
                        className={`w-full text-left p-4 focus:outline-none rounded-lg border font-serif tracking-tight flex items-center justify-between cursor-pointer transition-all ${
                          activeParaNum === p.num 
                            ? "bg-zinc-100 dark:bg-zinc-900 border-amber-700 shadow-md font-bold" 
                            : "bg-surface border-stone-250 dark:border-zinc-850 hover:bg-stone-150/40"
                        }`}
                      >
                        <div>
                          <span className="text-[10px] font-mono text-amber-700 dark:text-amber-500 font-semibold block mb-0.5">Paragraph {p.num}</span>
                          <span className="text-zinc-800 dark:text-zinc-100 text-sm leading-snug">{p.title}</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-stone-400 flex-shrink-0" />
                      </button>
                    ))}
                  </div>

                  {/* Right: Verbatim current text and historical note splits */}
                  <div className="lg:col-span-8 bg-zinc-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg p-6 min-h-[460px] relative transition-colors shadow-sm">
                    {activeParaNum ? (() => {
                      const p = originalParagraphs.find(it => it.num === activeParaNum);
                      if (!p) return null;
                      return (
                        <div className="flex flex-col justify-between h-full">
                          <div>
                            <div className="flex justify-between items-center pb-4 mb-4 border-b border-stone-250 dark:border-zinc-800 text-[10px] font-mono">
                              <span className="uppercase text-stone-400 dark:text-zinc-500 font-bold">Verbatim Annotated Constitution</span>
                              <button 
                                onClick={() => copyToClipboard(p.text, p.num)}
                                className="text-amber-700 hover:underline flex items-center gap-1 cursor-pointer font-bold"
                              >
                                <Copy className="w-3.5 h-3.5" />
                                {copiedText === p.num ? "Copied text!" : "Copy Verbatim Code"}
                              </button>
                            </div>

                            <span className="text-xs font-mono text-amber-750 dark:text-amber-500 uppercase tracking-widest font-black block mb-1">Paragraph {p.num}</span>
                            <h2 className="font-serif text-2xl font-bold tracking-tight text-stone-900 dark:text-zinc-50 leading-tight mb-6">
                              {p.title}
                            </h2>

                            {/* Verbatim container */}
                            <div className="p-5 bg-stone-200/50 dark:bg-zinc-950/40 rounded border border-stone-300/40 dark:border-zinc-800/80 font-serif text-[13px] leading-relaxed text-stone-800 dark:text-zinc-350 whitespace-pre-line select-text">
                              {p.text}
                            </div>

                            {/* Evolution footnotes */}
                            <div className="mt-6">
                              <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest font-black block mb-2">Historical Footnotes & Adjustments</span>
                              <ul className="space-y-2 list-none pl-0">
                                {p.notes.map((n, i) => (
                                  <li key={i} className="text-xxs font-sans text-stone-500 dark:text-zinc-400 pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:rounded-full before:bg-rose-900">
                                    {n}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          <div className="mt-8 pt-4 border-t border-stone-250 dark:border-zinc-800 flex justify-between items-center text-xxs font-mono text-stone-400">
                            <span>Paragraph {p.num} status: Active </span>
                            <button 
                              onClick={() => {
                                navigateTo("evolution");
                              }}
                              className="text-amber-600 hover:underline cursor-pointer"
                            >
                              Explore custom State Rulings →
                            </button>
                          </div>
                        </div>
                      );
                    })() : (
                      <div className="flex-1 flex items-center justify-center font-serif text-center italic text-stone-400">
                        Select a Paragraph to view its verified legal and evolution footprint
                      </div>
                    )}
                  </div>

                </div>
              )}

              {/* SUB TABLE 3: AMENDMENT TRACKER */}
              {activeDebateDay === "amendments" && (
                <div className="bg-zinc-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 p-6 rounded-lg transition-colors">
                  <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-stone-900 dark:text-zinc-50 leading-tight">Assembly Floor Amendments</h3>
                      <p className="text-xs text-stone-500 font-serif mt-1">Verifiable tracker indexing both Dr. Ambedkar and plain opposition amendments moved across 5–7 September 1949.</p>
                    </div>
                    
                    {/* search block inside amendments */}
                    <div className="flex gap-2 w-full sm:w-auto">
                      <input 
                        type="text" 
                        placeholder="Search amendments by mover..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-stone-50 dark:bg-zinc-950 border border-stone-300/60 dark:border-zinc-800 px-3 py-1 text-xs outline-none rounded font-sans placeholder-stone-400 dark:placeholder-zinc-500 text-zinc-900 dark:text-zinc-50"
                      />
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left font-serif text-xs leading-normal">
                      <thead>
                        <tr className="border-b border-stone-300 dark:border-zinc-800 text-[10px] font-mono text-stone-400 uppercase tracking-widest bg-stone-200/50 dark:bg-zinc-950/40">
                          <th className="p-3">No.</th>
                          <th className="p-3">Para</th>
                          <th className="p-3">Mover</th>
                          <th className="p-3">Substance Description</th>
                          <th className="p-3 text-center">Outcome</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-250 dark:divide-zinc-850">
                        {originalAmendments
                          .filter((am) => !searchQuery || am.mover.toLowerCase().includes(searchQuery.toLowerCase()) || am.substance.toLowerCase().includes(searchQuery.toLowerCase()))
                          .map((am) => (
                            <tr key={am.id} className="hover:bg-stone-300/20 dark:hover:bg-zinc-950/30">
                              <td className="p-3 font-mono font-bold text-amber-700">{am.id.replace("am-", "")}</td>
                              <td className="p-3 font-mono text-stone-500">{am.para}</td>
                              <td className="p-3 font-serif font-semibold text-stone-900 dark:text-zinc-100">{am.mover}</td>
                              <td className="p-3 text-stone-650 dark:text-zinc-400 leading-relaxed max-w-sm italic">"{am.substance}"</td>
                              <td className="p-3 text-center">
                                <span className={`text-[8px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                                  am.result === "adopted" 
                                    ? "bg-emerald-600/10 text-emerald-700 dark:text-emerald-500/90" 
                                    : am.result === "negatived" 
                                      ? "bg-rose-600/10 text-rose-700 dark:text-rose-400" 
                                      : "bg-amber-600/10 text-amber-700 dark:text-amber-500/90"
                                }`}>
                                  {am.result}
                                </span>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* SUB TABLE 4: SPEAKER SPECIAL CATALOG */}
              {activeDebateDay === "speakers" && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Left: Speaker index list */}
                  <div className="lg:col-span-4 space-y-2 select-none">
                    <span className="text-[9px] font-mono uppercase tracking-widest text-stone-400 text-center block mb-3">Dramatis Personae</span>
                    {speakerProfiles.map((sp) => (
                      <button
                        key={sp.id}
                        onClick={() => setSelectedSpeakerId(sp.id)}
                        className={`w-full text-left p-4 focus:outline-none rounded-lg border flex items-center gap-3 transition-all cursor-pointer ${
                          selectedSpeakerId === sp.id 
                            ? "bg-zinc-100 dark:bg-zinc-900 border-amber-700 shadow-md" 
                            : "bg-surface border-stone-250 dark:border-zinc-850 hover:bg-stone-150/40"
                        }`}
                      >
                        <div 
                          className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-center text-zinc-50 font-serif text-xs flex-shrink-0"
                          style={{ backgroundColor: sp.color }}
                        >
                          {sp.avatarInitials}
                        </div>
                        <div>
                          <h4 className="font-serif text-sm font-bold text-stone-900 dark:text-zinc-50 leading-tight">{sp.name}</h4>
                          <span className="text-[9px] font-mono text-stone-400">{sp.role.slice(0, 35)}...</span>
                        </div>
                      </button>
                    ))}
                  </div>

                  {/* Right: Speaker Expanded Bio card */}
                  <div className="lg:col-span-8 bg-zinc-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg p-6 min-h-[460px] flex flex-col justify-between transition-colors shadow-sm">
                    {selectedSpeakerId ? (() => {
                      const sp = speakerProfiles.find(it => it.id === selectedSpeakerId);
                      if (!sp) return null;
                      return (
                        <div className="flex flex-col justify-between h-full">
                          <div>
                            <div className="flex justify-between items-center pb-4 mb-4 border-b border-stone-250 dark:border-zinc-800 text-[10px] font-mono">
                              <span className="uppercase text-stone-400 dark:text-zinc-500 font-bold">Historical Profile Index</span>
                              <span className="text-zinc-400 hover:text-amber-750 font-bold">Veritas Policy Catalog</span>
                            </div>

                            <div className="flex items-center gap-4 mb-6">
                              <div 
                                className="w-14 h-14 rounded-full flex items-center justify-center font-bold text-xl text-zinc-50 font-serif shadow-sm flex-shrink-0"
                                style={{ backgroundColor: sp.color }}
                              >
                                {sp.avatarInitials}
                              </div>
                              <div>
                                <h2 className="font-serif text-2xl font-bold tracking-tight text-stone-900 dark:text-zinc-100">{sp.name}</h2>
                                <span className="text-xs font-mono text-amber-700 dark:text-amber-500 block">{sp.role}</span>
                                <span className="text-[10px] font-mono text-stone-400 block mt-0.5">{sp.meta}</span>
                              </div>
                            </div>

                            {/* Bio details */}
                            <div className="space-y-5 leading-relaxed text-sm font-serif">
                              <div>
                                <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest block mb-1">Archival Description</span>
                                <p className="text-stone-700 dark:text-zinc-300 font-light mb-3">{sp.bio}</p>
                                <button
                                  onClick={() => openCompanionWithContext({
                                    type: "debate",
                                    title: sp.name,
                                    subtitle: sp.role,
                                    summaryText: `Speaker: ${sp.name}. Role: ${sp.role}. Bio: ${sp.bio}. Primary quote: "${sp.mainQuote}". Debate contributions: ${sp.contributions.join(" | ")}`,
                                    itemData: sp
                                  })}
                                  className="py-1.5 px-3 bg-[#631919]/5 dark:bg-[#C5A059]/10 border border-[#631919]/25 dark:border-[#C5A059]/30 rounded text-[#631919] dark:text-[#C5A059] font-mono text-[9px] font-bold uppercase tracking-widest flex items-center gap-1.5 transition-colors hover:bg-[#631919]/10 cursor-pointer"
                                >
                                  <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                                  <span>Analyze Floor Stance with AI Scholar</span>
                                </button>
                              </div>

                              <div>
                                <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest block mb-2">Principal Floor Contributions</span>
                                <ul className="space-y-2 list-none pl-0 text-xs">
                                  {sp.contributions.map((c, i) => (
                                    <li key={i} className="text-stone-605 dark:text-zinc-450 pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:rounded-full before:bg-rose-900">
                                      {c}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              <div>
                                <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest block mb-1">Canonical Floor Quote</span>
                                <div className="p-4 bg-stone-200/50 dark:bg-zinc-950/40 rounded border-l-4 border-amber-700 font-serif italic text-stone-700 dark:text-zinc-300 leading-relaxed leading-medium text-xs">
                                  "{sp.mainQuote}"
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="mt-8 pt-4 border-t border-stone-250 dark:border-zinc-800 text-[9px] font-mono text-stone-400 flex items-center justify-between">
                            <span>Profile verified by curatorial scholars</span>
                            <button 
                              onClick={() => {
                                navigateTo("home");
                              }}
                              className="text-amber-600 hover:underline cursor-pointer"
                            >
                              Explore Knowledge Synapses →
                            </button>
                          </div>
                        </div>
                      );
                    })() : (
                      <div className="flex-1 flex items-center justify-center font-serif text-center italic text-stone-400 select-none">
                        Select a historical speaker profile on the left to read their verbatim legal record
                      </div>
                    )}
                  </div>

                </div>
              )}

            </div>
          )}

          {/* ==================================== */}
          {/* 4. HISTORICAL EVOLUTION */}
          {/* ==================================== */}
          {currentPage === "evolution" && (
            <div className="page-full">
              
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400">Institutional Timeline</span>
                <h1 className="font-serif text-4xl font-extrabold tracking-tight text-stone-900 dark:text-zinc-50 mt-1 leading-tight">Seven Decades of Design</h1>
                <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-xl mx-auto">From the 1935 excluded area acts to the 2003 Bodoland Territorial accords and contemporary negotiations in Ladakh.</p>
              </div>

              {/* Era Filtration Bar */}
              <div className="flex justify-center flex-wrap gap-2 mb-12 bg-stone-100 dark:bg-zinc-900 p-3 rounded-lg border border-stone-250 dark:border-zinc-800 h-auto select-none">
                {[
                  { id: "all", label: "All Eras" },
                  { id: "drafting", label: "01. Drafting (1935–50)" },
                  { id: "early", label: "02. Early Operatives (1950–72)" },
                  { id: "expansion", label: "03. State Reorganisations (1972-2000)" },
                  { id: "modern", label: "04. Modern Bodoland & Ladakh (2000+)" }
                ].map((er) => (
                  <button
                    key={er.id}
                    onClick={() => setActiveEra(er.id)}
                    className={`text-[9px] font-mono px-3.5 py-1.5 rounded uppercase tracking-wider font-semibold cursor-pointer ${
                      activeEra === er.id 
                        ? "bg-amber-700 text-white font-bold" 
                        : "text-stone-500 hover:bg-stone-200/50"
                    }`}
                  >
                    {er.label}
                  </button>
                ))}
              </div>

              {/* Central Chronological timeline layout */}
              <div className="max-w-3xl mx-auto space-y-12 relative pl-8 before:absolute before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-300 dark:before:bg-zinc-800">
                {evolutionMilestones
                  .filter((m) => activeEra === "all" || m.era === activeEra)
                  .map((m, idx) => (
                    <motion.div 
                      key={m.id}
                      initial={{ opacity: 0, x: -15 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.05 }}
                      className="relative group p-6 bg-stone-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-805 rounded-lg hover:border-amber-750/30 transition-all shadow-sm"
                    >
                      {/* Central node circle mark */}
                      <span className="absolute -left-[45px] top-[26px] w-[18px] h-[18px] rounded-full bg-stone-50 dark:bg-zinc-950 border-4 border-amber-700 dark:border-amber-500 group-hover:bg-amber-750 transition-colors shadow-sm" />
                      
                      <div className="flex justify-between items-baseline gap-2 mb-2 flex-wrap sm:flex-nowrap">
                        <span className="text-sm font-mono font-bold text-amber-700 dark:text-amber-500">{m.year}</span>
                        <span className="text-[8px] font-mono px-2 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 font-semibold uppercase">{m.era}</span>
                      </div>

                      <h3 className="font-serif text-lg font-bold text-stone-900 dark:text-zinc-100 leading-tight mb-3 group-hover:text-amber-800">{m.title}</h3>
                      <p className="text-xs text-stone-605 dark:text-zinc-350 font-serif leading-relaxed text-justify">{m.desc}</p>
                      
                      {/* Tags */}
                      <div className="flex flex-wrap gap-1 mt-4 pt-4 border-t border-stone-200/50 dark:border-zinc-800/50">
                        {m.tags.map((t) => (
                          <span key={t} className="text-[8px] font-mono bg-amber-600/10 text-amber-700 dark:text-amber-500/80 px-1.5 py-0.5 rounded uppercase font-medium">{t}</span>
                        ))}
                      </div>
                    </motion.div>
                  ))}
              </div>

            </div>
          )}

          {/* ==================================== */}
          {/* 5. ACADEMIC ARTICLES FILTER HUB */}
          {/* ==================================== */}
          {currentPage === "articles" && (
            <div className="page-full">
              
              <div className="text-center max-w-2xl mx-auto mb-12">
                <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400">Library Collections</span>
                <h1 className="font-serif text-4xl font-extrabold tracking-tight text-stone-900 dark:text-zinc-50 mt-1 leading-tight">Academic Scholarship</h1>
                <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-xl mx-auto">Selected law reviews, comparative monographs, and policy analyses exploring our legal and self-governance experiment.</p>
              </div>

              {/* State layout filters */}
              <div className="flex justify-center flex-wrap gap-2 mb-10 bg-stone-100 dark:bg-zinc-900 p-3 rounded-lg border border-stone-200 dark:border-zinc-850 h-auto select-none">
                {[
                  { id: "all", label: "All Literature" },
                  { id: "Autonomy", label: "Autonomy & Power structure" },
                  { id: "Land Rights", label: "Land & Local customary laws" },
                  { id: "Judicial", label: "Judicial interpretations" },
                  { id: "Comparative", label: "International & Comparative" }
                ].map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setActiveState(st.id)}
                    className={`text-[9px] font-mono px-3.5 py-1.5 rounded uppercase tracking-wider font-semibold cursor-pointer ${
                      activeState === st.id 
                        ? "bg-amber-700 text-white font-bold" 
                        : "text-stone-500 hover:bg-stone-200/50"
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>

              {/* Core articles index listings */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {academicArticles
                  .filter((ar) => activeState === "all" || ar.tags.includes(activeState) || (activeState === "Judicial" && ar.tags.includes("Judicial Interpretation")))
                  .map((ar) => (
                    <div 
                      key={ar.id}
                      className="bg-stone-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800/80 rounded-lg p-6 flex flex-col justify-between hover:border-amber-700 transition-all hover:shadow-lg shadow-sm"
                    >
                      <div>
                        {/* Header details */}
                        <div className="flex justify-between items-baseline gap-2 mb-3">
                          <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest">{ar.journal}</span>
                          <span className="text-[10px] font-mono font-bold text-amber-700">{ar.year}</span>
                        </div>

                        <h3 className="font-serif text-base font-bold text-stone-900 dark:text-zinc-50 leading-tight mb-2 tracking-tight">{ar.title}</h3>
                        <span className="text-xxs font-mono text-zinc-500 block mb-4">By {ar.author} • {ar.pages}</span>
                        <p className="text-xs text-stone-605 dark:text-zinc-400 font-serif leading-relaxed text-justify mb-4">"{ar.abstract}"</p>
                      </div>

                      <div className="space-y-4 pt-4 border-t border-stone-200 dark:border-zinc-800">
                        <div className="flex flex-wrap gap-1">
                          {ar.tags.map((t) => (
                            <span key={t} className="text-[8px] font-mono bg-amber-600/10 text-amber-700 dark:text-amber-500/80 px-1.5 py-0.5 rounded uppercase font-medium">{t}</span>
                          ))}
                        </div>
                        
                        <div className="flex flex-col gap-2.5">
                          <div className="flex justify-between items-center w-full">
                            <button
                              onClick={() => copyToClipboard(`Sundar, N. (${ar.year}). ${ar.title}. ${ar.journal}, ${ar.pages || ""}.`, ar.id)}
                              className="text-[9px] font-mono text-zinc-650 dark:text-zinc-350 font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer hover:underline"
                            >
                              <Copy className="w-3.5 h-3.5" />
                              {copiedText === ar.id ? "Copied!" : "Quick Copy"}
                            </button>
                            
                            <button
                              onClick={() => navigateToCitation("article", ar.id)}
                              className="text-[9px] font-mono text-amber-700 dark:text-amber-500 font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer hover:underline"
                            >
                              <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                              <span>Export Citation</span>
                            </button>
                          </div>
                          
                          <button
                            onClick={() => openCompanionWithContext({
                              type: "article",
                              title: ar.title,
                              subtitle: ar.author,
                              summaryText: `By: ${ar.author}. Journal: ${ar.journal}. Year: ${ar.year}. Abstract: ${ar.abstract}. Pages: ${ar.pages}`,
                              itemData: ar
                            })}
                            className="w-full py-1.5 bg-[#631919]/5 dark:bg-[#C5A059]/10 hover:bg-[#631919]/10 border border-[#631919]/25 dark:border-[#C5A059]/30 rounded text-[#631919] dark:text-[#C55050] hover:text-[#8B1A1A] font-mono text-[9px] font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 animate-pulse text-[#C5A059]" />
                            <span>Scholarly AI Analysis</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>

            </div>
          )}

          {/* ==================================== */}
          {/* 6. CURRENT AFFAIRS & COMMITTEE UPDATE */}
          {/* ==================================== */}
          {currentPage === "news" && (
            <div className="page-full">
              
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400">Current Affairs Log</span>
                <h1 className="font-serif text-4xl font-extrabold tracking-tight text-stone-900 dark:text-zinc-50 mt-1 leading-tight">News & Administrative Alerts</h1>
                <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-xl mx-auto">Tracking modern adjustments, Ladakh standing committee reports, environmental mine bans, and district council general elections.</p>
              </div>

              {/* Feed mapping */}
              <div className="max-w-3xl mx-auto space-y-6">
                {newsUpdates.map((n) => (
                  <div 
                    key={n.id}
                    className={`bg-zinc-100 dark:bg-zinc-905 border rounded-lg p-6 relative transition-colors ${
                      n.pinned 
                        ? "border-rose-900/40 bg-rose-900/5 h-auto dark:border-amber-500/40" 
                        : "border-stone-250 dark:border-zinc-800"
                    }`}
                  >
                    {n.pinned && (
                      <span className="absolute top-4 right-4 bg-amber-700 dark:bg-amber-600 text-stone-50 px-2 py-0.5 rounded font-mono text-[8px] uppercase tracking-widest font-semibold flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Pinned Update
                      </span>
                    )}

                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-500">{n.date}</span>
                      <span className="text-[8px] font-mono px-2 py-0.5 rounded bg-zinc-200 dark:bg-zinc-850 text-zinc-500 uppercase font-bold">{n.type}</span>
                    </div>

                    <h3 className="font-serif text-xl font-bold tracking-tight text-stone-900 dark:text-zinc-100 leading-snug mb-4">{n.title}</h3>
                    
                    <div className="space-y-3 font-serif text-sm leading-relaxed text-stone-705 dark:text-zinc-350 text-justify">
                      {n.body.map((p, i) => (
                        <p key={i}>"{p}"</p>
                      ))}
                    </div>

                    <div className="flex justify-between items-center mt-6 pt-4 border-t border-stone-200/50 dark:border-zinc-800/50">
                      <span className="text-[10px] font-mono text-stone-400 dark:text-zinc-500">{n.source}</span>
                      <button 
                        onClick={() => copyToClipboard(`Veritas News: ${n.title} (${n.date}).`, n.id)}
                        className="text-[9px] font-mono text-amber-700 dark:text-amber-500 uppercase tracking-widest font-bold flex items-center gap-1.5 hover:underline cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copiedText === n.id ? "Copied!" : "Cite"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* ==================================== */}
          {/* 6.5 ADVANCED SCHOLARLY CITATION DESK */}
          {/* ==================================== */}
          {currentPage === "citations" && (
            <div className="page-full max-w-5xl mx-auto">
              <CitationDesk 
                initialType={citationType} 
                initialItemId={citationId} 
                initialSpeechIndex={citationSpeechIdx}
              />
            </div>
          )}

          {/* ==================================== */}
          {/* 6.8 DEDICATED AI CONSTITUTION SCHOLAR */}
          {/* ==================================== */}
          {currentPage === "ai-scholar" && (
            <div className="page-full max-w-5xl mx-auto">
              <AIScholarDesk />
            </div>
          )}

          {/* ==================================== */}
          {/* 7. ABOUT THE REPOSITORY & RESEARCH TOOLS */}
          {/* ==================================== */}
          {currentPage === "about" && (
            <div className="page-full max-w-4xl">
              
              <div className="text-center mb-16">
                <span className="text-[10px] font-mono tracking-widest uppercase text-stone-400">Institutional Protocol</span>
                <h1 className="font-serif text-4xl font-extrabold tracking-tight text-stone-900 dark:text-zinc-50 mt-1 leading-tight">Archival Charter & Research Tools</h1>
                <p className="text-sm font-serif italic text-stone-500 mt-2 max-w-xl mx-auto">VCPRF methodology declaration, editorial frameworks, and digital accessibility compliance logs.</p>
              </div>

              {/* Dual box layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start mb-16">
                
                {/* 1. Academic Blueprint */}
                <div className="space-y-6">
                  <h2 className="font-serif text-2xl font-bold tracking-tight text-stone-900 dark:text-zinc-50 leading-tight">Editorial Standards</h2>
                  <div className="font-serif text-sm leading-relaxed text-stone-605 dark:text-zinc-350 text-justify space-y-4">
                    <p>
                      The Sixth Schedule Archive operates as a dedicated database managed by the fellows of the Veritas Centre for Policy Research Foundation (VCPRF). Our priority represents the precise transcription and cataloguing of constitutional documents specifically concerning indigenous minority autonomy in South Asia.
                    </p>
                    <p>
                      Each case log and Constituent Assembly transcript listed within the archive has been extracted from primary source archives inclusive of Lok Sabha Secretariat reprints (2014) and Supreme Court Reports. In line with bluebook rules, the citation codes can be directly integrated into papers without modifications.
                    </p>
                  </div>
                </div>

                {/* 2. Advanced Tools / Citation Generator */}
                <div className="bg-stone-150/40 dark:bg-zinc-910 p-6 rounded-lg border border-stone-250 dark:border-zinc-800 text-stone-700 dark:text-zinc-300">
                  <div className="flex items-center gap-2 mb-4 text-xs font-mono tracking-wider font-semibold uppercase text-amber-700">
                    <Landmark className="w-4 h-4" />
                    <span>Research Citation Tool</span>
                  </div>

                  <p className="text-xs font-serif leading-relaxed mb-6 italic text-stone-500">
                    Generate formatted bibliographical records for papers, briefs, or articles referencing the 1949 discussions.
                  </p>

                  <div className="flex gap-2 mb-4 font-mono text-[9px] uppercase tracking-wider">
                    {["Bluebook", "APA", "Chicago"].map((f) => (
                      <button
                        key={f}
                        onClick={() => setCitationFormat(f as any)}
                        className={`px-3 py-1.5 rounded transition-all cursor-pointer ${
                          citationFormat === f 
                            ? "bg-amber-700 text-white font-bold" 
                            : "bg-surface hover:bg-stone-200 border border-stone-300 dark:border-zinc-800"
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>

                  {/* Render copy Citation */}
                  <div className="p-4 bg-stone-200/50 dark:bg-zinc-950/40 rounded border border-stone-300 dark:border-zinc-805 text-xs font-mono italic leading-relaxed select-all">
                    {getCitationText()}
                  </div>

                  <button
                    onClick={() => copyToClipboard(getCitationText(), "built-citation")}
                    className="w-full mt-4 py-2 bg-stone-900 hover:bg-stone-850 text-white rounded text-[10px] font-mono tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer font-semibold"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {copiedText === "built-citation" ? "Copied formatting!" : "Copy Bibliographical Record"}
                  </button>
                </div>

              </div>

              {/* Transparency statement */}
              <div className="p-8 bg-zinc-100 dark:bg-zinc-900 border border-stone-250 dark:border-zinc-800 rounded-lg text-center transition-colors">
                <Shield className="w-8 h-8 text-rose-800 dark:text-amber-500 mx-auto mb-4" />
                <h3 className="font-serif text-xl font-bold text-stone-900 dark:text-zinc-50 mb-3 tracking-tight">Institutional Transparency Statement</h3>
                <p className="font-serif text-sm italic text-stone-605 leading-relaxed max-w-2xl mx-auto mb-4">
                  "This archive is exclusively committed to pure legal scholarship and documentation. We are strictly independent of active political lobbies or ethnic movements. Every mapping coordinate, metadata census pop, and footnote has been verified strictly for research and policy education."
                </p>
                <span className="text-[10px] font-mono text-zinc-400 capitalize">Director of Fellows • VCPRF Archival Directorate</span>
              </div>

            </div>
          )}

        </motion.div>
      </AnimatePresence>

      {/* INSTITUTIONAL FOOTER */}
      <footer className="bg-[#141414] dark:bg-[#0D0D0D] border-t border-[#C5A059]/40 py-16 px-8 select-none mt-20 transition-colors text-[#F5F2ED]">
        <div className="max-w-5xl mx-auto">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
            
            {/* BRAND */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-3">
                <Logo className="w-11 h-11 text-[#C5A059] drop-shadow-sm transition-colors" />
                <div>
                  <h3 className="font-serif text-md font-black tracking-widest text-white leading-none">SIXTH SCHEDULE ARCHIVE</h3>
                  <span className="text-[8px] font-mono text-[#C5A059] uppercase tracking-[0.2em] mt-1 block">Living Constitutional Record</span>
                </div>
              </div>
              <p className="font-serif text-xs text-[#F5F2ED]/70 leading-relaxed text-justify max-w-sm">
                A world-class digital constitutional repository tracking Paragraph-wise evolution of indigenous self-governance under the Constitution of India.
              </p>
            </div>

            {/* QUICK LINK DIRECTORIES */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-mono uppercase tracking-widest text-[#C5A059] font-bold">Exhibit Registry</h4>
              <ul className="space-y-2 text-xs font-mono">
                <li><button onClick={() => navigateTo("cases")} className="text-[#F5F2ED]/75 hover:text-[#C5A059] hover:underline cursor-pointer">Supreme Court Cases</button></li>
                <li><button onClick={() => navigateTo("debates")} className="text-[#F5F2ED]/75 hover:text-[#C5A059] hover:underline cursor-pointer">Constituent Assembly</button></li>
                <li><button onClick={() => navigateTo("evolution")} className="text-[#F5F2ED]/75 hover:text-[#C5A059] hover:underline cursor-pointer">Historical Timeline</button></li>
                <li><button onClick={() => navigateTo("articles")} className="text-[#F5F2ED]/75 hover:text-[#C5A059] hover:underline cursor-pointer">Academic Articles</button></li>
              </ul>
            </div>

            {/* CURATOR LINK DIRECTORIES */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-mono uppercase tracking-widest text-[#C5A059] font-bold">Directorate Info</h4>
              <ul className="space-y-2 text-xs font-mono text-[#F5F2ED]/75">
                <li><button onClick={() => navigateTo("about")} className="hover:text-[#C5A059] hover:underline cursor-pointer">VCPRF Charter</button></li>
                <li><button onClick={() => navigateTo("about")} className="hover:text-[#C5A059] hover:underline cursor-pointer">Bluebook Citations</button></li>
                <li><span className="text-[#F5F2ED]/40">Database No. V-041</span></li>
                <li><span className="text-[#F5F2ED]/40">Contact: research@vcprf.in</span></li>
              </ul>
            </div>

          </div>

          {/* BOTTOM COPYRIGHT DRAWER */}
          <div className="pt-8 border-t border-[#C5A059]/20 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] font-mono text-[#F5F2ED]/50">
            <span>© 2026 Sixth Schedule Archive • Veritas Centre for Policy Research Foundation (VCPRF)</span>
            <div className="flex gap-4">
              <button onClick={() => navigateTo("about")} className="hover:underline cursor-pointer">Editorial Guidelines</button>
              <span>•</span>
              <button onClick={() => navigateTo("about")} className="hover:underline cursor-pointer">Transparency Charter</button>
            </div>
          </div>

        </div>
      </footer>

      {/* GLOBAL PERSISTENT COMPANION TRIGGER */}
      <div className="fixed bottom-6 right-6 z-[450]">
        <button
          onClick={() => setIsCompanionOpen(true)}
          className="flex items-center gap-2 px-4 py-3 bg-[#631919] hover:bg-[#8B1A1A] dark:bg-[#C5A059] dark:hover:bg-amber-500 text-white dark:text-zinc-950 font-mono text-xs uppercase tracking-widest font-semibold rounded-full shadow-2xl transition-all scale-100 hover:scale-105 border border-amber-500/20 active:scale-95 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-amber-500 dark:text-zinc-950" />
          <span>AI Scholar Contact</span>
        </button>
      </div>

      <AIScholarCompanion 
        isOpen={isCompanionOpen}
        onClose={() => setIsCompanionOpen(false)}
        activeContext={companionContext}
        onClearContext={() => setCompanionContext(null)}
      />

    </div>
  );
}
