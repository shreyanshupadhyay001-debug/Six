/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DebateDay, Amendment, SpeakerProfile, GlossaryEntry } from "../types";

export const debateDays: DebateDay[] = [
  {
    id: "day-1",
    date: "5 September 1949 — Monday",
    meta: "Constituent Assembly of India · Constitution Hall, New Delhi · Vol. IX, pp. 1003–1008 · Dr. Rajendra Prasad presiding",
    summary: "Ambedkar moved Amendments 98 and 99 (Para 1) and delivered the principal exposition of the Sixth Schedule. General debate on tribal policy framework: Brajeshwar Prasad's centralisation proposal, Chaliha's objections, Ambedkar's comprehensive reply. Discussion of the Red Indian reservation model vs. the autonomous district model. K.M. Munshi's philosophical defence. Thakkar Bapa's first-person account of the hill districts.",
    speeches: [
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister · Principal Drafter · Bombay: General",
        page: "Vol. IX, p. 1003",
        text: "<p>Sir, I move: 'That in paragraph 1 before the words \"The tribal areas\" the words \"Subject to the provisions of this paragraph\" be inserted.' And also: 'That for sub-paragraph (3) of paragraph 1, the following sub-paragraph be substituted:— \"(3) The Governor may, by public notification,—(a) include any area in any of the Parts of the said table; (b) exclude any area from any of the Parts of the said table; (c) create a new autonomous district; (d) increase the area of any autonomous district; (e) diminish the area of any autonomous district; (f) unite two or more autonomous districts or parts thereof so as to form one autonomous district; (g) define the boundaries of any autonomous district: Provided that no order shall be made by the Governor under clauses (b), (c), (d), (e) and (f) of this sub-paragraph except after consideration of the report of a Commission appointed under sub-paragraph (1) of paragraph 14 of this Schedule.\"'</p><p>I shall now explain briefly the provisions of the Sixth Schedule. The Sixth Schedule deals with the tribal areas of Assam. The Scheduled Tribes of Assam differ from the Scheduled Tribes in other parts of India in this respect that the Scheduled Tribes in Assam are largely a distinct people, with a distinct culture, a distinct language and a distinct territory. These tribal areas are at present known under the Government of India Act as 'excluded areas' and 'partially excluded areas.' The fundamental difference is this: that the tribal people in the rest of India live in areas which are predominantly occupied by the Hindus. The tribal people of Assam live in areas which are predominantly occupied by themselves. It is for this reason that Schedule VI is framed differently from Schedule V.</p><p>Now, what are the different methods of dealing with tribal people? One method is to leave them isolated as much as possible, treating them as specimens to be preserved in the museum, so to say. This is what the American Government has done with the Red Indians. This method seems to be most objectionable because it has not produced any good results for the people for whom it was intended. The other method is to place the tribal people in reservation. The third method is to integrate tribal people with the general population and to give them the same rights and privileges as other people. But the difficulty in that case is that the tribal people then become undefended from what may be called the 'predatory' process of the general population.</p><p>Now what the Sixth Schedule does is this. It does not take the first course. It does not leave the tribal people in isolation. It does not also take the second course of reservations, which has proved so disastrous to the Red Indian people. It takes the third course of integrating the tribal people with the general population, but it provides certain safeguards for the protection of the tribal people, so that the integration shall not lead to their exploitation.</p>",
        outcome: "Ambedkar's boundary modification amendments were adopted, establishing the flexible Paragraph 1(3) framework constrained by the requirement for an expert Commission report."
      },
      {
        speaker: "Shri Brajeshwar Prasad",
        role: "Centralisation Advocate · Bihar: General",
        page: "Vol. IX, p. 1005",
        text: "<p>Sir, I am opposed to handing over the administration of the tribal areas into the hands of the provincial government, because Assam is on the border of five or six foreign States. I am referring to China, Tibet, Burma and Pakistan. Sir, in Assam, the conflicts between the Ahoms and the Assamese, the Bengalees and the Muslims, and the Mongoloid races have assumed proportions of which probably we the members of the House are not fully aware. My amendment is for substituting the word 'President' for the word 'Governor' throughout. In the interest of national security and in the interest of the tribal people themselves, the tribal areas should come under the direct control of the Central Government.</p><p>The Governor acts on the advice of the Council of Ministers of the Province. The tribal areas of Assam are on the borders of Burma, Tibet, China and East Pakistan. If the tribal areas happen to be under the administration of the Provincial Government there is every possibility of external influences being brought to bear on them. There is a possibility of foreign nationals working through the medium of the various Christian Missions permeating tribal areas and working against the unity of India.</p>",
        outcome: "Negatived. The Assembly rejected general centralisation, preferring to vest executive authority inside the State of Assam subject to safeguards."
      },
      {
        speaker: "Shri Kuladhar Chaliha",
        role: "Most Active Challenger · Assam: General",
        page: "Vol. IX, p. 1004",
        text: "<p>Sir, I object to the proviso. I am moving an amendment for deleting the proviso which states that the Governor shall not act except after consideration of the report of a Commission. A Governor means of course the Cabinet. I do not want a Commission. The Governor would have the power in consultation with his Cabinet to discuss these things and if it is left to a Commission there will be obvious delay. The Commission will take years and years. Why create a Commission to do what the Cabinet can do immediately?</p><p>If you have a Commission you will bring representatives from all these districts to the Commission and it will become such a politicised body that nothing will come out of it. I am moving to delete the proviso and let the Governor act directly in boundary restructuring.</p>",
        outcome: "Negatived. The proviso requiring an expert Paragraph 14 Commission report before boundary alterations was preserved to prevent political manipulation."
      },
      {
        speaker: "Shri K.M. Munshi",
        role: "Philosophical Defender · Bombay: General",
        page: "Vol. IX, pp. 999-1001",
        text: "<p>We want that the Scheduled tribes in the whole country should be protected from the destructive compact of races possessing a higher and more aggressive culture and should be encouraged to develop their own autonomous life; at the same time we want them to take a larger part in the life of the country. They should not be isolated communities or little republics to be perpetuated for ever.</p>",
        outcome: "The philosophy of integration coupled with functional, time-bound legal safeguards became the guiding doctrine of the Schedule."
      },
      {
        speaker: "Shri A.V. Thakkar (Thakkar Bapa)",
        role: "Gandhi's tribal welfare worker · Saurashtra",
        page: "Vol. IX, pp. 989-991",
        text: "<p>I will give you only one instance. When I went with the Assam Tribal Committee to tour in the areas of Assam with the Chairman Mr. Gopinath Bardolai and the prominent Minister Rev. Nichols Roy all the members of the Committee, one and all, went for the first time to the Lushai Hills and Naga Hills in the year 1947. Even the Premier of Assam had never visited the Lushai Hills and Naga Hills, much less a man like me.</p>",
        outcome: "Empirical testimony emphasizing the extreme isolation of these areas under British rule, reinforcing the need for custom-tailored local bodies."
      },
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister - Reply to general debate",
        page: "Vol. IX, pp. 1006-1008",
        text: "<p>The first thing that we have done is this: That we have provided that the executive authority of the Government of Assam shall extend not merely to non-tribal areas in Assam but also to the tribal areas. This, as will be seen, is a great improvement over the provisions contained in the Government of India Act, 1935. Under that Act the executive authority of the Government of Assam did not extend to the excluded areas. Under the present provisions, the executive authority extends to these areas as well.</p><p>The second thing that we have provided is that the laws passed by the Legislature of Assam — I am not speaking of Acts of Parliament — shall also apply to the tribal areas, unless the District Councils in the exercise of their powers exclude them. The third thing is, instead of providing that the Governor shall administer these areas in his discretion as an agency, we have provided that the tribal people themselves through their own District Councils shall be the executive authority.</p><p>With regard to the amendment of my Friend Mr Brajeshwar Prasad, he says that the whole of the tribal area should be lifted from the Province of Assam and should be made a Centrally administered area. But he seems to have forgotten two things. Although we have constituted autonomous districts, we have nowhere provided that the autonomous districts shall not constitute part of the province of Assam. That being so, it is very difficult to leave part of the Province to be governed by the Governor of the province and part of the province to be administered as a Centrally administered area. The second point he has forgotten is that there are what are called certain \"frontier areas\", bordering on the autonomous districts. It has been provided that so far as the administration of these frontier areas is concerned, the Governor would be acting under the President. Consequently whatever strategic importance the frontier areas may have, the Centre would certainly have ample jurisdiction.</p><p>Sir, I was rather surprised at the attitude taken by my Friend, Mr Chaliha. I feel that they are not now a happy and united family. When these amendments were made, they were made with the consent of Mr Chaliha, with the consent of the Premier of Assam, and also with the consent of my Friend Mr Nichols Roy. I do not wish therefore to enter into what I regard is a purely domestic quarrel.</p>",
        outcome: "The three binding unifying factors (executive extension, legislative baseline applicability, and agency role abolition) established the core constitutional logic of the Schedule."
      }
    ]
  },
  {
    id: "day-2",
    date: "6 September 1949 — Tuesday",
    meta: "Constituent Assembly of India · Constitution Hall, New Delhi · Vol. IX, pp. 1009–1060",
    summary: "Paragraphs 2 through 14 considered. Council composition and size (Para 2), the inherent vs. delegated model for Council legislative power (Para 3), opening the High Court to tribal court appeals (Para 4), deletion of mineral provision (Para 9), and the money-lending/trading safeguards (Para 10). The Chaliha-Ambedkar 'domestic quarrel' exchange and the famous David Copperfield quip.",
    speeches: [
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister · Para 2 — Amendment No. 100",
        page: "Vol. IX, p. 1009",
        text: "<p>Sir, I move: 'That in sub-paragraph (1) of paragraph 2, for the words \"not more than forty members of whom not more than twelve\" the words \"not more than twenty-four members of whom not more than four\" be substituted.' The amendment is for reducing the membership of the District Councils from forty to twenty-four and the nominated members from twelve to four. It seemed to the Drafting Committee that forty members was too large a number for the purposes of a District Council.</p>",
        outcome: "Adopted. District Council membership cap was reduced from forty to twenty-four (later raised to thirty under 1969 state reorganisations)."
      },
      {
        speaker: "Shri Kuladhar Chaliha",
        role: "Assam: General · Amendment No. 113",
        page: "Vol. IX, p. 1013",
        text: "<p>Sir, I propose to substitute the whole of para 3 by the following: 'The Governor shall make laws and regulations and entrust the District Council and Regional Councils with such powers as the State Legislature may approve.' My view is that there should not be a rigid enumeration like the articles in the Constitution itself; there should be flexibility. Let the Governor frame regulations — which means the Cabinet — and entrust these powers to the District Council. What do we want in these hill districts? We want good administration. We want to bring them progress — educational, economic and general.</p>",
        outcome: "Negatived. The Assembly firmly rejected a delegated-powers model, preserving the inherent (constitutionally vested) legislative power of the District Councils on Paragraph 3 subjects."
      },
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Reply on Para 3 — Amendment 114 and \"Governor\" meaning",
        page: "Vol. IX, p. 1019",
        text: "<p>Sir, I move: 'That after sub-paragraph (2) of paragraph 3, the following sub-paragraph be added:— \"(3) All laws made under this paragraph shall be submitted forthwith to the Governor and, until assented to by him, shall have no effect.\"'</p><p>With regard to my amendment and the amendment moved by my honourable Friend Mr Rohini Kumar Chaudhuri, there is hardly any difference except a failure to understand on the part of my honourable Friend as to what the word 'Governor' means. He says that the laws shall be approved by the legislature of Assam. According to my amendment, the laws will be approved by the Governor as advised by the Ministry of Assam, because in all this scheme, we are dropping the words 'in his discretion'. Wherever the word Governor occurs, it means Governor acting on the advice of the Ministry. The intervention of the legislature is quite unnecessary.</p>",
        outcome: "Adopted. All council laws required Governor's assent, which was explicitly clarified as acting on Cabinet (Ministry) advice."
      },
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister · Para 4 — Amendments 115 and 119",
        page: "Vol. IX, p. 1022",
        text: "<p>Sir, I move that in sub-paragraph (2) of paragraph 4, for the words 'shall have appellate jurisdiction over such suits or cases and the decision of such Regional or District Council or Court shall be final' the words 'except the High Court and the Supreme Court shall have jurisdiction over such suits or cases' be substituted. I also move that after sub-paragraph (2) the following be added: '(3) The High Court of Assam shall have and exercise such jurisdiction over the suits and cases to which the provisions of sub-paragraph (2) apply as the Governor may from time to time by order specify.'</p><p>This amendment makes an important change. Originally under sub-para (2) of para 4 the decision of the District Court was final. Now we have provided that they shall be subject to appellate jurisdiction of the High Court and the Supreme Court which will eliminate any infraction of fundamental rights. If the parties are such that one is a tribal and the other a non-tribal, then the ordinary law will apply. The jurisdiction of the ordinary court is ousted only to the extent provided for in paragraph 4.</p>",
        outcome: "Adopted. Opening appeals to the High Court and Supreme Court was one of the most significant structural breakthroughs in the debates."
      },
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister · Para 9 — Deletion of sub-para (1)",
        page: "Vol. IX, p. 1032",
        text: "<p>I move that sub-paragraph (1) of paragraph 9 be deleted. That paragraph refers to licence or lease granted by the Government of Assam for the prospecting for or the extraction of minerals. That matter now is within the exclusive jurisdiction of the Union (Seventh Schedule). Consequently the provision in sub-para (1) is inconsistent with the Union List under which this matter falls and it is therefore necessary to delete it.</p>",
        outcome: "Adopted. Mineral extraction placed under the Union List; the royalty-sharing provisions of Para 9(2) were preserved."
      },
      {
        speaker: "Shri Kuladhar Chaliha",
        role: "Assam: General · Amendment No. 123 · Para 10",
        page: "Vol. IX, p. 1034",
        text: "<p>Is it possible for any Assamese, Marwari, Sindhi, Punjabi or Sikh from the plains or from Bombay to carry on business in the Naga Hills if we have a rule like licensing clause (d)? To say the least, this is an impossible provision. These provisions are so bad that the only way I can describe them is that they are worse than the provisions in the Government of India Act, 1935. A District Council can pass a regulation by a three-fourths majority and say that no Assamese shall trade in the Naga Hills. I think that is absolutely wrong and I am opposing it vigorously.</p>",
        outcome: "Negatived. The safeguard clause allowing councils to license and regulate non-tribal commerce with a three-fourths council majority was preserved."
      },
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Reply on Para 10 — The \"David Copperfield\" Quip",
        page: "Vol. IX, p. 1038",
        text: "<p>There are three things provided by way of safeguards which my friend has not taken into consideration in Paragraph 10 governing money-lending and trading by non-tribals. Firstly, any regulation made by the District Council must receive the assent of the Governor. Secondly, the Governor may refuse to give his assent. Thirdly, under paragraph 15, the Governor may annul any act of the District Council which in his opinion endangers public order or the safety of the State. Having regard to these three safeguards, I do not think there is anything to be afraid of. I wonder now whether my Friend Shri Rohini Kumar Chaudhuri is satisfied with the explanation I have given?</p><p>[Honourable Members: Not at all.]</p><p>I know you want something more than what I can give. You are like hungry David Copperfield asking for more gruel. That is all I can say.</p>",
        outcome: "Adopted. Amendments 124 and 125 added the Governor's assent mandate to Paragraph 10 regulations as a necessary buffer."
      }
    ]
  },
  {
    id: "day-3",
    date: "7 September 1949 — Wednesday",
    meta: "Constituent Assembly of India · Constitution Hall, New Delhi · Vol. IX, pp. 1061–1099",
    summary: "Final day. Paragraphs 15–19 (the Table of Tribal Areas) considered. Governor's explicit discretion removed from Para 15. The Chaliha-Bardoloi compromise on Para 16. Ambedkar adds new sub-para (3) to Para 17 for frontier areas. Para 16-A (now 17) inserted. The general debate centered on Paragraph 19 (the Table): the Shillong municipality state of Mylliem question, the Dimapur mouza dispute, and Kunzru's structural objections.",
    speeches: [
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister · Para 15 — Delete sub-para (3)",
        page: "Vol. IX, p. 1061",
        text: "<p>Sir, I move: 'That sub-paragraph (3) of paragraph 15 be omitted.' That is because it gives discretion to the Governor which it is not proposed now to leave with him. As I have said we are taking away the discretion from the Governor which we had originally laid with him and it is therefore necessary to delete this sub-para (3). Wherever the word Governor occurs in this Schedule, it means Governor acting on the advice of the Ministry — except in those provisions which deal with the frontier areas where he acts as agent of the President.</p>",
        outcome: "Adopted. Deleting Paragraph 15(3) cleanly aligned the Governor's general supervisory powers over councils with ministerial advice."
      },
      {
        speaker: "Shri Gopinath Bardoloi",
        role: "Premier of Assam · Para 16 — Compromise",
        page: "Vol. IX, p. 1066",
        text: "<p>Sir, with reference to the amendment moved by Srijut Chaliha for the deletion of the second proviso to para 16, all that I have to say is that in every case where action of this kind is taken the parties affected thereby are given an opportunity of being heard. I agree that in this proviso no machinery by which this could be done has been laid down. Therefore, if Srijut Chaliha would modify his amendment as follows, namely, that instead of the words 'opportunity of being heard by the legislature' the words 'an opportunity of placing the views of the Regional Council' may be substituted, then the purpose of his amendment would be served.</p><p>[Chaliha: I am prepared to do that. Ambedkar: I am prepared to accept the amendment of Mr Bardoloi to the amendment of Mr Chaliha, which he has accepted.]</p>",
        outcome: "Adopted via a historic compromise, requiring that councils be given an opportunity to represent their case to the Legislature prior to Paragraph 16(1)(b) assumptions of power."
      },
      {
        speaker: "Dr. B.R. Ambedkar",
        role: "Law Minister · Para 16-A (new) and Para 17 frontier",
        page: "Vol. IX, p. 1068",
        text: "<p>Sir, I beg to move that after paragraph 16, the following paragraph be inserted:— '16A. For the purpose of elections to the Legislative Assembly of Assam the Governor may by order declare that any area within an autonomous district shall not form part of any constituency to fill a seat reserved for any such district but shall form part of a constituency to fill a seat not so reserved.' The object of this is to give the people who are included in the autonomous districts but really who are not part and parcel of the people inhabiting the autonomous districts an opportunity to have a place in the Legislative Assembly by having their own constituencies marked out for them.</p><p>On Para 17, I move that after sub-paragraph (2) the following be added:— '(3) In the discharge of his functions under sub-paragraph (2) of this paragraph as the agent of the President, the Governor shall act in his discretion.' This is necessary because Para 17 deals with frontier areas. In these areas alone the Governor will act in his discretion. In all other areas, the Governor acts on the advice of the Cabinet of Assam.</p>",
        outcome: "Adopted. Paragraph 16-A (renumbered 17) solved the electoral representational dilemma of non-tribals trapped within Council administrative areas."
      },
      {
        speaker: "Shri Gopinath Bardoloi",
        role: "Premier of Assam · Para 19 — Shillong question",
        page: "Vol. IX, p. 1084",
        text: "<p>It is very necessary for us to understand the real position of the town of Shillong. It is there that more than half of its area is occupied not by non-tribal people but by tribal people. The bulk of the land belongs to Khasis. The Khasi people have built most of the shops there on their own lands. To exclude the entire municipality would be to exclude Khasi people from protection of the Schedule on their own land. That is why the provision retains the Mylliem State area within the district while excluding the rest of the municipality.</p>",
        outcome: "Negatived. Amendments to wholly exclude Shillong Municipality were defeated; the Mylliem State / Khasi Hills boundary compromise was preserved."
      },
      {
        speaker: "Shri Kuladhar Chaliha",
        role: "Assam: General · Dimapur Mouza Debate",
        page: "Vol. IX, p. 1075",
        text: "<p>Now, Sir, it is a prosperous state where you find Assamese, Bengalees, Sindhis, Punjabees, Sikhs, Marwaris doing business after having invested crores of rupees; but do you know their fate? They can be ejected in 24 hours bag and baggage. The Dimapur Mouza is in the plains! The people are not tribal. If this is not excluded from the Naga Hills Table, their property and trade rights are at the mercy of the Council.</p>",
        outcome: "Negatived. The Assembly refused to dissect the historical administrative boundaries of the Naga Hills, trusting the Paragraph 10 safeguards instead."
      },
      {
        speaker: "Pandit Hirday Nath Kunzru",
        role: "Structural Critic · United Provinces: General",
        page: "Vol. IX, p. 1080",
        text: "<p>However good the provisions of the Sixth Schedule might seem, they segregate people living in different districts and thus make unity much more difficult. We are treating the advanced Khasi, Garo, and Mikir Hills identically with the remote Naga and Lushai Hills under a single rigid directory. We should establish a separate Part IA for partially excluded areas with a lighter, more integrated administrative touch.</p>",
        outcome: "Negatived. Premier Bardoloi delivered a decisive rebuttal, proving that the Schedule's ultimate goal was to unify, not permanently isolate, and that the distinction between fully and partially excluded areas was obsolete."
      }
    ]
  }
];

export const originalParagraphs = [
  {
    num: "1",
    title: "Autonomous districts and autonomous regions",
    text: "1. Autonomous districts and autonomous regions.—(1) Subject to the provisions of this paragraph, the tribal areas in each item of [Parts I, II and IIA] and in Part III of the table appended to paragraph 20 of this Schedule shall be an autonomous district.\n\n(2) If there are different Scheduled Tribes in an autonomous district, the Governor may, by public notification, divide the area or areas inhabited by them into autonomous regions.\n\n(3) The Governor may, by public notification,—\n(a) include any area in any of the Parts of the said table;\n(b) exclude any area from any of the Parts of the said table;\n(c) create a new autonomous district;\n(d) increase the area of any autonomous district;\n(e) diminish the area of any autonomous district;\n(f) unite two or more autonomous districts or parts thereof so as to form one autonomous district;\n(ff) alter the name of any autonomous district;\n(g) define the boundaries of any autonomous district:\n\nProvided that no order shall be made by the Governor under clauses (c), (d), (e) and (f) of this sub-paragraph except after consideration of the report of a Commission appointed under sub-paragraph (1) of paragraph 14 of this Schedule:\n\nProvided further that any order made by the Governor under this sub-paragraph may contain such incidental and consequential provisions (including any amendment of paragraph 20 and of any item in any of the Parts of the said Table) as appear to the Governor to be necessary for giving effect to the provisions of the order.",
    notes: [
      "Subs. 'any of the Parts' for 'Part A' by the North-Eastern Areas (Reorganisation) Act, 1971 (w.e.f. 21-1-1972).",
      "Clause (ff) inserted by the Assam Reorganisation (Meghalaya) Act, 1969 (w.e.f. 2-4-1970).",
      "In its application to Assam, a proviso was added by the 2003 Amendment: 'Provided that nothing in this sub-paragraph shall apply to the Bodoland Territorial Areas District.'"
    ]
  },
  {
    num: "2",
    title: "Constitution of District Councils and Regional Councils",
    text: "2. Constitution of District Councils and Regional Councils.—(1) There shall be a District Council for each autonomous district consisting of not more than thirty members, of whom not more than four persons shall be nominated by the Governor and the rest shall be elected on the basis of adult suffrage.\n\n(2) There shall be a separate Regional Council for each area constituted an autonomous region under sub-paragraph (2) of paragraph 1 of this Schedule.\n\n(3) Each District Council and each Regional Council shall be a body corporate by the name respectively of 'the District Council of (name of district)' and 'the Regional Council of (name of region)', shall have perpetual succession and a common seal and shall by the said name sue and be sued.\n\n(4) Subject to the provisions of this Schedule, the administration of an autonomous district shall, in so far as it is not vested under this Schedule in any Regional Council within such district, be vested in the District Council for such district and the administration of an autonomous region shall be vested in the Regional Council for such region.\n\n(5) In an autonomous district with Regional Councils, the District Council shall have only such powers with respect to the areas under the authority of the Regional Council as may be delegated to it by the Regional Council in addition to the powers conferred on it by this Schedule with respect to such areas.\n\n(6) The Governor shall make rules for the first constitution of District Councils and Regional Councils in consultation with any existing tribal councils...\n\n(6A) The elected members of the District Council shall hold office for a term of five years from the date appointed...",
    notes: [
      "Original draft had up to 40 members, reduced to 24 by Ambedkar's Amendment 100 on 6 September 1949.",
      "The limit was raised to 30 members (26 elected, 4 nominated) by the Assam Reorganisation (Meghalaya) Act, 1969.",
      "Special BTC provisions added in 2003 expand the Gorkha/Bodo council to 46 members (40 elected, 6 nominated)."
    ]
  },
  {
    num: "3",
    title: "Powers of District Councils to make laws",
    text: "3. Powers of the District Councils and Regional Councils to make laws.—(1) The Regional Council for an autonomous region in respect of all areas within such region and the District Council for an autonomous district in respect of all areas within the district except those which are under the authority of Regional Councils, if any, within the district shall have power to make laws with respect to—\n(a) the allotment, occupation or use, or the setting apart, of land, other than reserved forest...\n(b) the management of any forest not being a reserved forest;\n(c) the use of any canal or water-course for the purpose of agriculture;\n(d) the regulation of the practice of jhum or other forms of shifting cultivation;\n(e) the establishment of village or town committees and their powers;\n(f) any other matter relating to village or town administration, including village or town police, public health and sanitation;\n(g) the appointment or succession of Chiefs or Headmen;\n(h) the inheritance of property;\n(i) marriage and divorce;\n(j) social customs.\n\n(2) 'reserved forest' means any area which is a reserved forest under the Assam Forest Regulation, 1891...\n\n(3) All laws made under this paragraph shall be submitted forthwith to the Governor and, until assented to by him, shall have no effect.",
    notes: [
      "Sub-paragraph (3) was inserted by Ambedkar's Amendment No. 114 to prevent conflicts between Council and Provincial laws.",
      "In Assam, Paragraphs 3A (Karbi Anglong & NC Hills, 1995) and 3B (BTC, 2003) add extensive advanced subjects (industries, roads, trade, primary/secondary education, theatre, etc.)."
    ]
  },
  {
    num: "4",
    title: "Administration of justice in autonomous districts and regions",
    text: "4. Administration of justice in autonomous districts and autonomous regions.—(1) The Regional Council for an autonomous region in respect of areas within such region and the District Council for an autonomous district... may constitute village councils or courts for the trial of suits and cases between the parties all of whom belong to Scheduled Tribes...\n\n(2) Notwithstanding anything in this Constitution, the Regional Council... or District Council... shall exercise the powers of a court of appeal... and no other court except the High Court and the Supreme Court shall have jurisdiction...\n\n(3) The High Court shall have and exercise such jurisdiction as the Governor may by order specify...",
    notes: [
      "Ambedkar's Amendment 119 introduced the High Court's coordinate jurisdiction, modifying the original draft which made Council supreme court decisions absolutely final.",
      "The ouster of ordinary civil court jurisdiction applies strictly to civil and minor criminal disputes where all parties are Scheduled Tribes."
    ]
  },
  {
    num: "10",
    title: "Regulations for control of money-lending and trading by non-tribals",
    text: "10. Power of District Council to make regulations for the control of money-lending and trading by non-tribals.—(1) The District Council of an autonomous district may make regulations for the regulation and control of money-lending or trading within the district by persons other than Scheduled Tribes resident in the district.\n\n(2) In particular... such regulations may—\n(a) prescribe licensed business requirements for money-lenders;\n(b) prescribe maximum interest rates;\n(c) provide for inspections of books of accounts;\n(d) prescribe retail/wholesale trade licenses for non-tribals:\n\nProvided that no regulations may be made under this paragraph unless they are passed by a majority of not less than three-fourths of the total membership of the District Council:\n\nProvided further that licenses cannot be refused to persons trading within the district prior to regulations.\n\n(3) All regulations made under this paragraph shall be submitted forthwith to the Governor and, until assented to by him, shall have no effect.",
    notes: [
      "This paragraph was heavily debated on 6 September 1949 on fears of non-tribal exclusion. Chaliha vehemently opposed the license provisions on behalf of plains traders.",
      "To prevent abuses, the three-fourths majority requirement and the grandfather clause (second proviso) were added. Amendment 125 added the Paragraph 10(3) Governor's assent requirement."
    ]
  },
  {
    num: "13",
    title: "Separation of District Estimates in Financial Statement",
    text: "13. Estimated receipts and expenditure pertaining to autonomous districts to be shown separately in the annual financial statement.—The estimated receipts and expenditure pertaining to an autonomous district which are to be credited to, or is to be made from, the Consolidated Fund of the State shall be first placed before the District Council for discussion and then after such discussion be shown separately in the annual financial statement...",
    notes: [
      "This was the only structural amendment moved by an Opposition member (Rohini Kumar Chaudhuri, Amendment 130) that was accepted by Dr. Ambedkar and incorporated verbatim.",
      "Requires state budgets to submit hill district estimates to Councils for debate first, ensuring fiscal consultation."
    ]
  },
  {
    num: "19",
    title: "Transitional provisions (Governance before first constitution)",
    text: "19. Transitional provisions.—(1) As soon as possible after the commencement of this Constitution the Governor shall take steps for the constitution of a District Council...\n\n(a) no Act of Parliament or of the Legislature of the State shall apply... unless the Governor by public notification so directs;\n(b) the Governor may make regulations for the peace and good government...\n\n(2) Any direction given by the Governor... may have retrospective effect.\n\n(3) All regulations made under clause (b) shall be submitted forthwith to the President and, until assented to by him, shall have no effect.",
    notes: [
      "Paragraph 19 acted as the temporary governance bridge between 1950 and the actual formation of elected councils in 1952.",
      "Gave the state cabinet (acting through the Governor) sweeping authority to adapt and block acts of Parliament and state legislatures during the transition."
    ]
  }
];

export const originalAmendments: Amendment[] = [
  { id: "am-98", para: "1(1)", mover: "Ambedkar", substance: "Add 'Subject to the provisions of this paragraph' before 'The tribal areas' to allow boundary modifications.", result: "adopted" },
  { id: "am-99", para: "1(3)", mover: "Ambedkar", substance: "Substitute simplified sub-para (3): seven consolidated boundary adjustment powers under a single expert Commission constraints proviso.", result: "adopted" },
  { id: "am-ch-1", para: "1(3)", mover: "Chaliha", substance: "Delete Commission report proviso to allow the Governor (Cabinet) to modify boundaries without expert delays.", result: "negatived" },
  { id: "am-bp-1", para: "1", mover: "Brajeshwar Prasad", substance: "Substitute 'President' for 'Governor' to enforce full Central administration of tribal tracts.", result: "negatived" },
  { id: "am-100", para: "2(1)", mover: "Ambedkar", substance: "Reduce maximum council membership from forty to twenty-four, and nominated members from twelve to four.", result: "adopted" },
  { id: "am-ch-2", para: "3", mover: "Chaliha", substance: "Substitute Paragraph 3: empower the Governor to delegate legislative subjects to councils instead of vesting them constitutionally.", result: "negatived" },
  { id: "am-114", para: "3(3)", mover: "Ambedkar", substance: "Insert Paragraph 3(3): require all council laws to receive the assent of the Governor after submission.", result: "adopted" },
  { id: "am-rc-1", para: "3(3)", mover: "Rohini Kumar Chaudhuri", substance: "In sub-paragraph 3(3), require council laws to be approved by the State Legislature, not just the Governor.", result: "negatived" },
  { id: "am-119", para: "4(2)+(3)", mover: "Ambedkar", substance: "Open coordinate appellate paths to the High Court of Assam and the Supreme Court over tribal village panels.", result: "adopted" },
  { id: "am-9-del", para: "9(1)", mover: "Ambedkar", substance: "Delete sub-paragraph (1) of Paragraph 9; mineral prospecting is a Union List subject under Seventh Schedule entry.", result: "adopted" },
  { id: "am-ch-4", para: "10", mover: "Chaliha", substance: "Substitute Paragraph 10: place money-lending/trading licensing rules directly in the hands of the Governor (Cabinet) rather than the councils.", result: "negatived" },
  { id: "am-125", para: "10(3)", mover: "Ambedkar", substance: "Insert Paragraph 10(3): requiring all trading is and money-lending rules to receive the assent of the Governor.", result: "adopted" },
  { id: "am-130", para: "13", mover: "Rohini Kumar Chaudhuri", substance: "Insert the requirement that district estimates first be placed before the District Council for debate prior to the State Financial Statement.", result: "adopted" },
  { id: "am-134", para: "14(1)", mover: "Ambedkar", substance: "Cross-reference Paragraphs 1(3)(b)–(e) directly inside the advisory terms of the Paragraph 14 Commission.", result: "adopted" },
  { id: "am-15-del", para: "15(3)", mover: "Ambedkar", substance: "Delete sub-paragraph 15(3) which explicitly listed the Governor's personal discretion, placing supervisory powers under cabinet advice.", result: "adopted" },
  { id: "am-ch-compromise", para: "16", mover: "Chaliha", substance: "Add second proviso to Paragraph 16(1): requiring that a council be given an opportunity to represent its case to the Legislature prior to dissolution.", result: "compromise" },
  { id: "am-16a", para: "16-A (new)", mover: "Ambedkar", substance: "Insert new Paragraph 16-A (renumbered 17), enabling the Governor to declare non-tribal pockets as separate legislative constituencies.", result: "adopted" },
  { id: "am-17-3", para: "17 (frontier)", mover: "Ambedkar", substance: "Add Paragraph 17(3): explicitly authorizing the Governor to act 'in his discretion' in the frontier tracts.", result: "adopted" },
  { id: "am-331", para: "19 / Table", mover: "Ambedkar", substance: "Substitute an entirely revised Table of Tribal Areas, divided into Part I (Autonomous Districts) and Part II (Frontier Areas), with a special Shillong/Mylliem State boundary proviso.", result: "adopted" },
  { id: "am-ch-dimapur", para: "19 (Table)", mover: "Chaliha", substance: "Exclude the plains-majority Dimapur Mouza from the Naga Hills scheduled tract.", result: "negatived" }
];

export const speakerProfiles: SpeakerProfile[] = [
  {
    id: "spk-ambedkar",
    name: "Dr. B.R. Ambedkar",
    role: "Law Minister · Principal Drafter · Drafting Committee Chairman",
    meta: "Representing Bombay: General · Moved 18+ key amendments on Schedule VI",
    avatarInitials: "BRA",
    color: "#2B4C7E",
    bio: "The chief architect of the Indian Constitution. Ambedkar approached the Scheduled territories with analytical rigor, designing a functional administrative model that balanced local autonomy with integration. He defended the councils' inherent legislative powers against assimilationist and regional forces, and systematically stripped independent gubernatorial discretion from the general chapters.",
    contributions: [
      "Formulated the famous 'Three-Model Comparison' (Isolation, Reservation, Integration).",
      "Defended the Paragraph 3 legislative autonomy of Councils from state cabinets.",
      "Introduced coordinates like High Court appellate jurisdiction in Paragraph 4.",
      "Co-created the Paragraph 10 licensing compromise to protect local markets with three structural safeguards."
    ],
    mainQuote: "We are dropping the words 'in his discretion'. Wherever the word Governor occurs in this Schedule, it means Governor acting on the advice of the Ministry."
  },
  {
    id: "spk-bardoloi",
    name: "Shri Gopinath Bardoloi",
    role: "Premier of Assam · Chairman of the Excluded Areas Sub-Committee",
    meta: "Representing Assam: General · Author of the pre-legislative reports",
    avatarInitials: "GB",
    color: "#2E7D32",
    bio: "A leading political consensus-builder and reformer. As Premier of Assam and Chairman of the special Sub-committee, Bardoloi performed the primary negotiations on the ground with tribal leaders in 1947–48. His authority gave the Schedule its political legitimacy in the eyes of the Assamese cabinet, and he successfully resisted Kunzru's attempts to subdivide the advanced districts into Part IA classes.",
    contributions: [
      "Guided the Advisory Sub-committee whose report laid the blueprint for ADCs.",
      "Brokered the Paragraph 16 compromise on council representations with Kuladhar Chaliha.",
      "Explained the historical boundary rationale behind the Mylliem State / Shillong municipality exclusion."
    ],
    mainQuote: "The arrangement made in the Sixth Schedule makes a departure from the old arrangement and practically does away with the distinction between fully excluded and partially excluded areas."
  },
  {
    id: "spk-chaliha",
    name: "Shri Kuladhar Chaliha",
    role: "Frequent Challenger · Assam Plain Nationalist",
    meta: "Representing Assam: General · Moved 6 highly contentious floor amendments",
    avatarInitials: "KC",
    color: "#E65100",
    bio: "A highly vocal representing lawyer from the Assam plains. Chaliha was skeptical of giving District Councils absolute legislative and licensing powers, warning that they could behave as 'little republics' that completely exclude plains traders, plains languages, and plains laws. While his amendment was negatived, he was a key figure whose constant challenges forced the Drafting Committee to implement vital regulatory checks.",
    contributions: [
      "Vigorously challenged the money-lending and trading licensing clauses of Paragraph 10.",
      "Moved the boundary exclusion of the Dimapur Mouza.",
      "Secured the Paragraph 16 representation compromise on council dissolutions."
    ],
    mainQuote: "A Governor means of course the Cabinet. I do not want a Commission. The Governor would have the power in consultation with his Cabinet to discuss these things and if it is left to a Commission there will be obvious delay."
  },
  {
    id: "spk-brajeshwar",
    name: "Shri Brajeshwar Prasad",
    role: "Unified Centralisation Advocate",
    meta: "Representing Bihar: General · Moved 15+ centralisation amendments across three days",
    avatarInitials: "BP",
    color: "#6A1B9A",
    bio: "A highly centralist nationalist representative from Bihar. Prasad argued consistently that because Assam shares highly sensitive borders with Burma, China, Tibet, and Pakistan, its strategic hill areas should be administered as direct Centrally Administered Areas of the President. Though his amendments were negatived, his concerns prompted Ambedkar to clarify the Paragraph 17 presidential agent model.",
    contributions: [
      "Consistently moved to replace 'Governor' with 'President' throughout.",
      "Advocated on humanitarian grounds for direct Central funding of tribal development.",
      "Moved a highly expanded Paragraph 14 Commission charter that was adopted in scope."
    ],
    mainQuote: "I am opposed to handing over the administration of the tribal areas into the hands of the provincial government, because Assam is on the border of five or six foreign States."
  },
  {
    id: "spk-chaudhuri",
    name: "Shri Rohini Kumar Chaudhuri",
    role: "Legal & Procedural Critic",
    meta: "Representing Assam: General · Secured the key Paragraph 13 budget amendment",
    avatarInitials: "RC",
    color: "#37474F",
    bio: "A technically-skilled Assamese lawyer and proceduralist. Chaudhuri supported Chaliha's general anxieties on non-tribal trade rights, famously accusing Ambedkar's boundary compromise of being 'camouflage.' He made highly useful contributions on tribal civil ousters and secured the key budget consult update in Paragraph 13.",
    contributions: [
      "Successfully moved Amendment No. 130, adding the Council debate mandate to Paragraph 13.",
      "Pushed for technical clarity on coordinate high court jurisdictions under Paragraph 4.",
      "Offered rigorous critiques of the Mylliem State pocket borders."
    ],
    mainQuote: "I stand corrected. If Dr Ambedkar does not practise camouflage, he would not be a good fighter. But, what I thought was that certain honourable Members may be misled as I was misled."
  }
];

export const glossary: GlossaryEntry[] = [
  { term: "Diku", definition: "A historical, politically-rich tribal term from the Chota Nagpur Plateau and northeastern hills used to denote non-tribal outsiders, plains merchants, and colonial administrators who were perceived as exploiters of the indigenous community.", context: "Invoked by Jaipal Singh in his explanation of tribal suspicion towards plains councils." },
  { term: "Jhum", definition: "A traditional method of shifting or slash-and-burn cultivation practiced extensively by tribal communities in the hills of Northeast India. Regulated constitutionally under Paragraph 3(1)(d).", context: "Evaluated in Paragraph 3 debates and subsequent environment litigations." },
  { term: "Camouflage", definition: "A term used dramatically on the floor by Rohini Kumar Chaudhuri to accuse Dr. Ambedkar of creating a false boundary compromise under the Mylliem State / Shillong municipality exclusion clauses.", context: "Ambedkar's reply: 'Camouflage for what?'" },
  { term: "Exclusion", definition: "The colonial administrative practice of keeping tribal hill areas outside the legislative, judicial, and fiscal jurisdiction of ordinary provincial legislatures, managed directly under the personal discretion of the Governor.", context: "Abolished by the Constituent Assembly in favor of elected ADCs." },
  { term: "Asymmetric Federalism", definition: "A constitutional arrangement whereby different states or regions within a federal union are granted distinct degrees of autonomy, legal protections, and administrative authority to accommodate cultural or historical uniqueness.", context: "The Sixth Schedule is the classic expression of asymmetric federalism in India." }
];
