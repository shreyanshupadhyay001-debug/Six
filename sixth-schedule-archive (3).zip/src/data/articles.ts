/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AcademicArticle } from "../types";

export const academicArticles: AcademicArticle[] = [
  {
    id: "art-featured",
    title: "The Sixth Schedule as a Model for Indigenous Autonomy: Comparative Perspectives",
    author: "Prof. Nandini Sundar",
    journal: "National Law School of India Review (NLSIR)",
    year: 2019,
    pages: "Vol. 31(2), pp. 45–98",
    abstract: "This article examines the Sixth Schedule as one of the world's earliest constitutional experiments in institutionalised indigenous self-governance. Drawing on comparative analysis of the ILO Convention 169 framework, New Zealand's Treaty of Waitangi settlements, and Canada's s.35 jurisprudence, it argues that the Schedule's combination of territorial autonomy, legislative power, and judicial independence represents a theoretically coherent — if under-implemented — model that deserves sustained international attention. The article evaluates seven decades of administrative practice and identifies systemic underfunding, political interference in Council elections, and the erosion of customary law institutions as the primary implementation deficits.",
    tags: ["Comparative", "Autonomy", "International Law"]
  },
  {
    id: "art-1",
    title: "District Councils under the Sixth Schedule: Power without Accountability?",
    author: "B.P. Singh",
    journal: "Journal of Constitutional Law in India (JCLI)",
    year: 1976,
    pages: "Vol. 4(1), pp. 12–34",
    abstract: "Examines the first two decades of District Council operations in Assam, documenting the gap between formal constitutional powers and actual administrative reality on the ground. The author argues that the absence of a robust centralized oversight mechanism in the early structural design created conditions for local elite capture and fiscal unaccountability.",
    tags: ["Autonomy", "Assam", "Governance"]
  },
  {
    id: "art-2",
    title: "Customary Land Rights and the Constitutional Promise: Sixth Schedule in Practice",
    author: "M. Fernandes",
    journal: "Economic & Political Weekly (EPW)",
    year: 1994,
    pages: "Vol. 29(14), pp. 743–756",
    abstract: "A field-based study of land administration in the Autonomous Districts of Meghalaya and Assam. The paper documents the practical challenges of applying Sixth Schedule land regulations in the context of rapid demographic shift, urbanization, and market economic pressures from neighboring plains areas.",
    tags: ["Land Rights", "Customary Law", "Assam", "Meghalaya"]
  },
  {
    id: "art-3",
    title: "Judicial Interpretation of Para 3: The Limits of District Council Legislation",
    author: "A. Hazarika",
    journal: "Indian Law Review (ILR)",
    year: 2005,
    pages: "Vol. 8(2), pp. 101–124",
    abstract: "Systematic analysis of the Supreme Court's jurisprudence on the legislative powers of District Councils under Paragraph 3 of the Sixth Schedule. The author identifies a steady pattern of restrictive judicial interpretation that has progressively narrowed local council autonomy in favor of state legislative supremacy.",
    tags: ["Judicial Interpretation", "State Powers", "Para 3"]
  },
  {
    id: "art-4",
    title: "From Autonomy to Insurgency: The Sixth Schedule’s Governance Deficit in Northeast India",
    author: "S. Baruah",
    journal: "Asian Survey",
    year: 2011,
    pages: "Vol. 51(6), pp. 1087–1110",
    abstract: "Explores the complex relationship between the perceived inadequacy of Sixth Schedule governance arrangements and the persistence of armed ethnic conflict in northeastern India. The author argues that leaving Councils without true financial independence creates structural incentives for insurgent alternatives.",
    tags: ["Political", "Autonomy", "Security"]
  },
  {
    id: "art-5",
    title: "Constitutional Accommodation of Indigenous Peoples: India’s Sixth Schedule in Global Perspective",
    author: "T. Woolman",
    journal: "Oxford Journal of Legal Studies (OJLS)",
    year: 2013,
    pages: "Vol. 33(3), pp. 589–612",
    abstract: "A comparative law analysis positioning the Sixth Schedule alongside the Canadian and Australian indigenous rights frameworks. The author argues that the Schedule represents a theoretically robust model of asymmetric federalism that has suffered extensively from institutional under-activation.",
    tags: ["Comparative", "International Law", "Federalism"]
  },
  {
    id: "art-6",
    title: "Customary Law Courts under the Sixth Schedule: Jurisdiction and Legitimacy",
    author: "R.K. Verma",
    journal: "Indian Journal of International Law (IJIL)",
    year: 1998,
    pages: "Vol. 38(4), pp. 411–432",
    abstract: "Analyses the judicial architecture created by Paragraph 5 of the Sixth Schedule — particularly the para-judicial courts of the District Councils. The article examines Gauhati High Court case law on the precise boundaries of customary law jurisdiction in disputes involving tribal and non-tribal parties.",
    tags: ["Customary Law", "Judicial Interpretation", "Para 5"]
  },
  {
    id: "art-7",
    title: "The Bodoland Territorial Council: Innovation or Precedent?",
    author: "P. Bhattacharya",
    journal: "Journal of Northeast India Studies",
    year: 2007,
    pages: "Vol. 1(1), pp. 55–76",
    abstract: "Assess the creation of the Bodoland Territorial Council (BTC) as a Sixth Schedule entity in 2003. It evaluates the innovative 40-subject legislative list of Paragraph 3B against older District Councils and assesses its potential to serve as a template for resolving other sub-state autonomy claims.",
    tags: ["BTC", "Assam", "Autonomy"]
  },
  {
    id: "art-8",
    title: "Election Integrity and Tribal Self-Governance: District Council Polls in Meghalaya",
    author: "D. Sohliya",
    journal: "South Asia Research",
    year: 2014,
    pages: "Vol. 34(2), pp. 115–136",
    abstract: "An empirical study of election administration in Meghalaya's three ADCs. The author highlights the historical absence of State Election Commission oversight, which led to high rates of voting irregularities and undermined the democratic legitimacy of the self-governance model.",
    tags: ["Meghalaya", "Democracy", "Elections"]
  },
  {
    id: "art-9",
    title: "Asymmetric Federalism and Tribal Territories: The Sixth Schedule’s Place in India’s Constitutional Architecture",
    author: "K. Krishnaswamy",
    journal: "Constitutional Law Review",
    year: 2017,
    pages: "Vol. 9(1), pp. 88–109",
    abstract: "Situates the Sixth Schedule within the literature of asymmetric federalism. It argues that the Schedule represents a constitutionally legitimate and sophisticated expression of differentiated citizenship and territorial autonomy that has successfully preserved the Union's integrity.",
    tags: ["Federalism", "Political", "Comparative"]
  },
  {
    id: "art-10",
    title: "Shifting Cultivation Regulation under the Sixth Schedule: History and Controversy",
    author: "J. Karlsson",
    journal: "Indian Economic & Social History Review (IESHR)",
    year: 2018,
    pages: "Vol. 55(3), pp. 312–338",
    abstract: "A historical analysis of Paragraph 3's provisions empowering District Councils to regulate shifting cultivation (jhum). Traces the colonial geneology of forest regulation and evaluates how District Council regulations have frequently conflicted with state ecological priorities.",
    tags: ["Land Rights", "Customary Law", "Forests"]
  },
  {
    id: "art-11",
    title: "Fundamental Rights in Autonomous Districts: Applying Part III to the Sixth Schedule",
    author: "C. Mallya",
    journal: "National Law School of India Review (NLSIR)",
    year: 2020,
    pages: "Vol. 32(1), pp. 147–170",
    abstract: "Examines the constitutional friction between the individual fundamental rights guaranteed in Part III and the collective customary protections of the Sixth Schedule. It reviews cases on non-tribals' property rights, mercantile freedoms, and access to tribal courts.",
    tags: ["Judicial Interpretation", "Part III", "Fundamental Rights"]
  },
  {
    id: "art-12",
    title: "Tribe, Territory and the Indian State: The Sixth Schedule at Seventy",
    author: "S. Wouters",
    journal: "Modern Asian Studies",
    year: 2021,
    pages: "Vol. 55(6), pp. 1824–1856",
    abstract: "A comprehensive assessment of the Schedule at seven decades, drawing on extensive archival research and fieldwork. Re-theorises the Schedule not as a transitional protective measure, but as a robust and persistent form of constitutional pluralism.",
    tags: ["Comprehensive", "Political", "Governance"]
  },
  {
    id: "art-13",
    title: "The Sixth Schedule and ILO Convention 169: Convergence and Divergence",
    author: "L. Rodriguez-Pizarro",
    journal: "International Journal on Minority & Group Rights",
    year: 2022,
    pages: "Vol. 29(2), pp. 245–268",
    abstract: "Compares the Sixth Schedule with the framework established by ILO Convention 169. It maps significant convergences on land rights and local courts while highlighting a critical structural divergence on the requirement of Free, Prior, and Informed Consent (FPIC).",
    tags: ["International Law", "Comparative"]
  },
  {
    id: "art-14",
    title: "Mining, Extraction, and the Sixth Schedule: Who Controls Subsoil Resources?",
    author: "A. Xaxa",
    journal: "Economic & Political Weekly (EPW)",
    year: 2023,
    pages: "Vol. 58(12), pp. 34–48",
    abstract: "Examines the contested question of mineral resource control in Autonomous District Areas in the wake of the Gauhati High Court and National Green Tribunal bans. Argues the Schedule's silence on subsoil resources has been heavily capitalized by state governments to circumvent tribal consent.",
    tags: ["Land Rights", "Forests", "State Powers"]
  }
];
