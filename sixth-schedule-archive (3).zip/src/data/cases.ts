/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LandmarkCase } from "../types";

export const landmarkCases: LandmarkCase[] = [
  {
    id: "case-1",
    name: "Matajog Dobey v. H.C. Bhari",
    citation: "AIR 1956 SC 44 · (1955) 2 SCR 925",
    year: 1955,
    tags: ["Sixth Schedule", "Para 1", "Constitution Bench"],
    issue: "Whether a public servant functioning under the Sixth Schedule administration could claim sanction under the Prevention of Corruption Act or Code of Criminal Procedure for prosecution.",
    holding: "The Court held that the requirement of obtaining prior sanction applies to all public servants, including those functioning within Sixth Schedule territories. The autonomous character of District Councils does not exempt their officers from general penal statutes.",
    excerpt: "The Sixth Schedule creates autonomous districts and councils with wide legislative, judicial and administrative powers, but these powers operate within the framework of the Constitution and do not create an impenetrable shield against the operation of general law.",
    metadata: {
      court: "Supreme Court of India",
      year: 1955,
      bench: "5 Judges",
      state: "Assam",
      judges: 5
    }
  },
  {
    id: "case-2",
    name: "Ryots of Garabandho v. Zamindar of Parlakimedi",
    citation: "AIR 1943 PC 164 · [Pre-constitutional precedent]",
    year: 1943,
    tags: ["Pre-Constitution", "Privy Council", "Land Rights"],
    issue: "Whether tribal customary rights in forest and agricultural land could be extinguished by zamindari settlements in Scheduled or excluded areas.",
    holding: "The Privy Council recognised the distinct and protected character of tribal land rights, reasoning that colonial regulations creating excluded areas were designed to preserve customary land tenure. This case heavily influenced the Constituent Assembly's subsequent protective approach in drafting the Sixth Schedule.",
    excerpt: "These areas were set apart precisely because the ordinary law of British India was regarded as unsuited to the conditions and customs of the aboriginal tribes who inhabited them.",
    metadata: {
      court: "Privy Council",
      year: 1943,
      region: "Scheduled Areas",
      state: "Orissa / Madras Presidency"
    }
  },
  {
    id: "case-3",
    name: "Khyerbari Tea Co. Ltd. v. State of Assam",
    citation: "AIR 1964 SC 925 · (1964) 5 SCR 975",
    year: 1964,
    tags: ["Para 9", "Taxation", "State Powers"],
    issue: "Validity of the Assam Taxation (on Specified Lands) Act imposing a surcharge on tea gardens located in the autonomous districts, and his collision with District Council power.",
    holding: "The Supreme Court upheld the state levy, distinguishing it from the District Council's power to levy taxes under Paragraph 9. The state legislature retains concurrent taxing power over commerce and industry within the Sixth Schedule area; Paragraph 9 grants additional powers to the councils, not exclusive ones.",
    excerpt: "Paragraph 9 of the Sixth Schedule does not strip the State Legislature of its ordinary taxing power over territories that happen to fall within autonomous districts — it supplements the fiscal arsenal available to the Councils for purposes of self-governance.",
    metadata: {
      court: "Supreme Court of India",
      year: 1964,
      state: "Assam"
    }
  },
  {
    id: "case-4",
    name: "All Party Hill Leaders' Conference v. Captain W.A. Sangma",
    citation: "AIR 1977 SC 2155 · (1977) 4 SCC 161",
    year: 1977,
    tags: ["Para 12", "Meghalaya", "Constitution Bench"],
    issue: "Whether the creation of Meghalaya as a full state in 1972 required a corresponding adaptation of the Sixth Schedule to ensure its continued application, or whether the Schedule automatically ceased to operate upon the state's bifurcation from Assam.",
    holding: "The five-judge bench unanimously held that the Sixth Schedule continued to apply to the Hill Districts of Meghalaya upon statehood. The Schedule is attached to the tribal character of the territory, not merely to Assam as the parent state. The court read the Constitution as a living document whose tribal protection provisions must be construed purposively.",
    excerpt: "The Sixth Schedule is a special protective mechanism embedded in the Constitution for the benefit of tribal peoples. Its application cannot be undermined by the formal mechanics of state reorganisation; the purpose and substance must prevail over any reading that would leave the tribes of the hill districts without constitutional protection.",
    metadata: {
      court: "Supreme Court of India",
      year: 1977,
      judges: 5,
      state: "Meghalaya"
    }
  },
  {
    id: "case-5",
    name: "Mizo District Council v. Dengkima",
    citation: "AIR 1966 SC 1658 · (1966) 2 SCR 80",
    year: 1966,
    tags: ["Para 5", "Customary Law", "Judicial Autonomy"],
    issue: "Jurisdiction of courts established by the District Council under Paragraph 5 over matters of customary inheritance and matrimonial disputes between members of the same scheduled tribe.",
    holding: "The Supreme Court upheld the exclusive jurisdiction of the District Council court in intra-tribal customary disputes. Paragraph 5 creates a parallel judicial structure that displaces ordinary civil court jurisdiction over matters enumerated therein when both parties belong to the same tribe.",
    excerpt: "Paragraph 5 is not merely an enabling provision permitting the creation of courts — it is a constitutional guarantee that tribal customary law will be adjudicated by institutions rooted in and accountable to the tribal community itself.",
    metadata: {
      court: "Supreme Court of India",
      year: 1966,
      state: "Assam (Mizo Hills)"
    }
  },
  {
    id: "case-6",
    name: "State of Tripura v. Tripura Bar Association",
    citation: "(1998) 6 SCC 275 · 1998 SCC(Cri) 1289",
    year: 1998,
    tags: ["Para 3", "Tripura", "Legislative Scope"],
    issue: "Whether the Tripura Tribal Areas Autonomous District Council had legislative competence to regulate legal practice within its autonomous district or to restrict advocates appearing before District Council courts.",
    holding: "The Supreme Court held that while the District Council has legislative powers over the subjects listed in Paragraph 3, these powers do not extend to regulating the legal profession, which falls under List I of the Seventh Schedule and the Advocates Act, 1961. The override mechanism did not apply since no specific notification had been issued.",
    excerpt: "The legislative autonomy conferred by Paragraph 3 of the Sixth Schedule is defined, circumscribed and enumerated. It does not create a residuary legislative competence nor does it authorise the Council to intrude upon fields covered by central legislation of general application.",
    metadata: {
      court: "Supreme Court of India",
      year: 1998,
      judges: 3,
      state: "Tripura"
    }
  },
  {
    id: "case-7",
    name: "Nongthombam Ibobi Singh v. Paokholal Haokip",
    citation: "(2021) 5 SCC 488",
    year: 2021,
    tags: ["Elections", "Manipur", "Hill Areas"],
    issue: "Eligibility criteria for candidates to the Hill Areas Committee — specifically whether the Sixth Schedule's underlying framework of tribal self-representation applies to the Hill Areas Committee established under Manipur state law.",
    holding: "The Court held that the Hill Areas Committee established under the Manipur (Hill Areas) District Councils Act draws constitutional legitimacy from the spiritual framework of the Sixth Schedule. Eligibility rules must be construed in harmony with the Schedule's intent to ensure genuine tribal self-governance and protection from plains-majority domination.",
    excerpt: "Constitutional provisions for tribal self-governance are to be construed broadly, keeping in view the historical marginalisation of tribal peoples and the constitutional commitment to protect their distinct ways of life and governance.",
    metadata: {
      court: "Supreme Court of India",
      year: 2021,
      state: "Manipur"
    }
  },
  {
    id: "case-8",
    name: "Shillong Club Ltd. v. State of Meghalaya",
    citation: "AIR 1986 Gau 56 (Meghalaya Bench)",
    year: 1986,
    tags: ["High Court", "Para 12", "Exclusions"],
    issue: "Whether state excise and commercial licensing laws applied to club establishments within the autonomous district despite no specific affirmative notification under Paragraph 12(b).",
    holding: "The High Court held that in the absence of an exclusionary notification by the Governor under Paragraph 12, all state laws apply with full force to the autonomous districts. Paragraph 12 operates as an exception-making mechanism; absent its active exercise, the ordinary territorial reach of state law is unaffected.",
    excerpt: "The Governor's power under Paragraph 12 is a discretionary safeguard, not a precondition. State laws do not require separate notification to become operative within autonomous districts — only to be excluded from operation do they require positive action.",
    metadata: {
      court: "Gauhati High Court",
      year: 1986,
      state: "Meghalaya"
    }
  },
  {
    id: "case-9",
    name: "Bodoland Territorial Council v. State of Assam",
    citation: "(2007) 13 SCC 636",
    year: 2007,
    tags: ["Para 1(3)", "BTC", "Boundary powers"],
    issue: "Whether the creation of the Bodoland Territorial Council under the Sixth Schedule by a 2003 amendment was constitutionally valid and whether the Governor's notification defining boundaries was subject to judicial review.",
    holding: "The Court upheld the constitutional amendment creating the BTC while holding that boundary notifications under Paragraph 1(3) are subject to constitutional limitations and must follow the procedural requirements, inclusive of the mandatory report of an expert Paragraph 14 Commission.",
    excerpt: "The Governor exercises a constitutional function when defining boundaries under Paragraph 1(3). This function, though executive in character, must be exercised in consonance with the recommendations of the Commission and the overriding purpose of the Sixth Schedule — which is to protect, not marginalise, the tribal communities.",
    metadata: {
      court: "Supreme Court of India",
      year: 2007,
      state: "Assam"
    }
  }
];
