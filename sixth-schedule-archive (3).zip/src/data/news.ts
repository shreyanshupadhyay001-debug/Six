/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NewsUpdate } from "../types";

export const newsUpdates: NewsUpdate[] = [
  {
    id: "news-1",
    date: "2025-03-15",
    type: "legislative",
    title: "Ladakh Sixth Schedule Demand: Parliamentary Committee Submits Milestone Report",
    body: [
      "The Parliamentary Standing Committee on Home Affairs has officially submitted its comprehensive report on the persistent demand for the extension of Sixth Schedule protections to the Union Territory of Ladakh.",
      "The report acknowledges the constitutional legitimacy of the demand, highlighting that Ladakh's high tribal demographic composition (over 90%), combined with its extremely sensitive border location, makes it a prime candidate for asymmetric constitutional accommodation.",
      "The committee recommends that the Ministry of Home Affairs fast-track the bilateral talks with the Leh Apex Body (LAB) and the Kargil Democratic Alliance (KDA) to establish a joint autonomous governance framework before formalising a draft Constitutional Amendment bill.",
      "Crucially, the report suggests structural provisions to safeguard the diverse priorities of both Buddhist-majority Leh and Shia Muslim-majority Kargil districts concurrently."
    ],
    source: "Rajya Sabha Secretariat · Standing Committee on Home Affairs · Report No. 247",
    tags: ["Ladakh", "MHA", "Union Territory", "2025"],
    pinned: true
  },
  {
    id: "news-2",
    date: "2025-01-22",
    type: "judicial",
    title: "Meghalaya High Court: Distict Councils Lack Authority to Bypass Mineral Laws",
    body: [
      "The High Court of Meghalaya delivered a milestone ruling, clarifying that Autonomous District Councils do not possess the legislative competence to exempt coal or limestone mining within their territories from national environmental statutes like the Environment (Protection) Act, 1986.",
      "The division bench ruled that environmental protection and major mineral cesses fall under central legislative entries on List I and List III of the Seventh Schedule, which remain superior to the councils' Paragraph 3 legislative powers.",
      "The ruling holds significant economic and environmental safety implications for ongoing public-interest litigations targeting illegal rat-hole mining in the Khasi and Jaintia Hills areas."
    ],
    source: "Meghalaya High Court · Writ Petition (C) No. 412 of 2024",
    tags: ["Meghalaya", "Mining", "Judiciary", "Para 3", "2025"]
  },
  {
    id: "news-3",
    date: "2024-12-10",
    type: "political",
    title: "Bodoland Territorial Council General Elections Concluded",
    body: [
      "Elections to the 40 constituencies of the Bodoland Territorial Council (BTC) in western Assam concluded with a voter turnout of over 78%. The elections, managed directly by the Assam State Election Commission, were held across the four Bodo-majority districts.",
      "The results showed a competitive landscape, with the ruling United People's Party Liberal (UPPL) and the Bodo People's Front (BPF) securing key constituencies. The BTC was established under a historic tripartite peace accord in 2003, with an expanded 46-member council to accommodate sub-state ethnic aspirations."
    ],
    source: "Assam State Election Commission · Official Gazette",
    tags: ["Assam", "BTC", "Elections", "2024"]
  },
  {
    id: "news-4",
    date: "2024-09-14",
    type: "political",
    title: "Manipur Hill ADCs Suspended Under Para 16 Oversight",
    body: [
      "In light of prolonged ethnic strife and administrative paralysis in the State of Manipur, the Governor, acting on the recommendation of the State Cabinet, has formally suspended two active Autonomous District Councils in the hill districts under Paragraph 16(1) of the Sixth Schedule.",
      "Under the suspension orders, the local administration of these tribal hills was assumed by the Governor. Civil society organizations in the outer Manipur districts protested, claiming the suspension severely undermines democratic tribal self-governance at a time of deep political instability.",
      "Elections to these hill councils have been repeatedly postponed due to hostilites, prompting demands for constitutional safeguards that decouple ADC elections from state cabinet interference."
    ],
    source: "Government of Manipur · Department of Tribal Affairs · Notification No. 12/2024",
    tags: ["Manipur", "Suspension", "Para 16", "2024"]
  },
  {
    id: "case-sc-forest",
    date: "2024-07-18",
    type: "judicial",
    title: "SC Rules Forest Rights Act Fully Operative in Autonomous Districts",
    body: [
      "A three-judge bench of the Supreme Court held that the Scheduled Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act, 2006 (FRA), applies with full force to all territories listed under the Sixth Schedule.",
      "Responding to arguments from certain District Councils that their exclusive Paragraph 3 powers over forest management displaced the central Act, the Court held that the FRA is a protective, rights-recognising statute that supplements, rather than overrides, the self-governance authority of the ADCs.",
      "The court emphasised that state governments must coordinate with both District Councils and local Gram Sabhas to process and settle community forest land claims cleanly."
    ],
    source: "Supreme Court of India · Civil Appeal No. 4452 of 2024",
    tags: ["Supreme Court", "Forest Rights", "Assam", "Meghalaya"]
  },
  {
    id: "news-manipur-2023",
    date: "2023-05-18",
    type: "political",
    title: "Manipur Crisis Sparked by Scheduled Tribe Status Dispute",
    body: [
      "Widespread ethnic conflicts in Manipur highlight the fragile constitutional design of the state. The crisis erupted following protests against a High Court directive to consider Scheduled Tribe (ST) status for the valley-dwelling Meitei community, which hill-dwelling Kuki-Zo tribes opposed.",
      "Hill tribal bodies argue that granting ST status would dilute their existing land protections under the Manipur Hill ADCs, leading to intense debates on whether extending the full Sixth Schedule (which Manipur's hill areas do not officially have under Part I) represents the only permanent solution."
    ],
    source: "National Media Bulletins · Parliamentary Debates",
    tags: ["Manipur", "ST Status", "Ethnic Conflict", "2023"]
  },
  {
    id: "news-garo-2023",
    date: "2023-02-05",
    type: "administrative",
    title: "Garo Hills ADC Approves First Major Tax Schedule Revision since 2005",
    body: [
      "The Garo Hills Autonomous District Council (GHADC) in Meghalaya has received executive assent from the Governor for its newly revised Paragraph 8 tax schedule, updating rates that had been frozen since 2005.",
      "The revision updates registration fees for commercial establishments, transit cesses on forest products, and cesses on market entries. The changes are projected to boost local revenue collections of the council by over 45%, helping to address chronic back-pay deficits for council employees."
    ],
    source: "Meghalaya Government Gazette · Finance Division No. 89/2023",
    tags: ["Meghalaya", "GHADC", "Para 8", "Administrative", "2023"]
  },
  {
    id: "news-darjeeling-2022",
    date: "2022-12-11",
    type: "legislative",
    title: "Darjeeling Sixth Schedule Bill Introduced as Private Member Action",
    body: [
      "A Private Member's Bill seeking to formally include the Gorkhaland Territorial Administration (GTA) areas of Darjeeling within the Sixth Schedule has been introduced in the Lok Sabha by the Member of Parliament from Darjeeling.",
      "The bill argues that the GTA, established under a 2011 tripartite pact, currently lacks constitutional core stability. Incorporating Darjeeling into Part I of the Schedule Table is proposed as the only viable mechanism to guarantee institutional autonomy without creating a separate state.",
      "The bill has been referred to the Parliamentary Standing Committee on Home Affairs for legislative feedback."
    ],
    source: "Lok Sabha Secretariat · Private Member Bills Portfolio No. 128 of 2022",
    tags: ["Gorkhaland", "Darjeeling", "Lok Sabha", "2022"]
  },
  {
    id: "news-tripura-2022",
    date: "2022-08-04",
    type: "judicial",
    title: "Tripura HC: Council Rules Subordinate to Constitutional Election Mandates",
    body: [
      "The High Court of Tripura held that the rules and dates for elections to the Tripura Tribal Areas Autonomous District Council (TTAADC) are ultimately governed by municipal democratic principles of the Constitution under Part IX-A, overriding any conflicting rules in the TTAADC's internal election manuals.",
      "The Court ruled that while the District Council possesses substantial autonomy, it cannot use its Paragraph 2 rule-making powers to indefinitely postpone general elections once the 5-year term is expired, except under formal Emergencies."
    ],
    source: "Tripura High Court · Writ Petition (C) No. 892 of 2021",
    tags: ["Tripura", "TTAADC", "Elections", "Judiciary", "2022"]
  }
];
