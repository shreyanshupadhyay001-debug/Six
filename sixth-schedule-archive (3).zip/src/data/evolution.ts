/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TimelineMilestone } from "../types";

export const evolutionMilestones: TimelineMilestone[] = [
  {
    id: "ev-1",
    year: "1935",
    title: "Government of India Act — Excluded Areas",
    desc: "Section 91 and the Fifth Schedule of the Government of India Act, 1935, divide territories into 'Excluded Areas' and 'Partially Excluded Areas'. The northeastern hill tracts are classified as Excluded Areas, placing them entirely under the Governor's personal discretion, excluding the territorial jurisdiction of the provincial legislature.",
    era: "drafting",
    tags: ["Colonial", "GoI Act 1935", "Precursor"]
  },
  {
    id: "ev-2",
    year: "1947",
    title: "Bordoloi Sub-Committee Report",
    desc: "The Constituent Assembly's Advisory Committee on Minorities and Fundamental Rights establishes the 'Sub-Committee on North-East Frontier (Assam) Tribal and Excluded Areas', chaired by Gopinath Bordoloi (Premier of Assam) with Rev. J.J.M. Nichols Roy as an active member. Their landmark report recommends the 'Autonomous District Council' structure, rejecting the old colonial exclusion paradigm.",
    era: "drafting",
    tags: ["Assam", "Bordoloi Committee", "Drafting"]
  },
  {
    id: "ev-3",
    year: "1949",
    title: "Cabinet negotiations & Assembly Adoption",
    desc: "During three days of intense debate (5–7 September 1949) in Constitution Hall, New Delhi, the Constituent Assembly debates and refines the draft Schedule. Dr. B.R. Ambedkar steers the provisions, successfully moving landmark amendments 98, 99 (revising boundary restructuring and adding expert Commission constraints), 119 (High Court appeals) and 125 (trading controls).",
    era: "drafting",
    tags: ["Ambedkar", "Constituent Assembly", "Adoption"]
  },
  {
    id: "ev-4",
    year: "1950",
    title: "Constitution Commences & ADCs Activated",
    desc: "The Constitution of India enters into force on 26 January 1950. The Sixth Schedule becomes active under Articles 244(2) and 275(1). Autonomous districts are mapped in Assam, including the Khasi-Jaintia Hills, Garo Hills, Naga Hills, Lushai Hills, North Cachar Hills, and Mikir Hills.",
    era: "early",
    tags: ["Commencement", "Assam", "ADCs"]
  },
  {
    id: "ev-5",
    year: "1952",
    title: "First Democratic ADC Elections",
    desc: "First ever democratic elections to the newly established Autonomous District Councils are held in the Khasi Hills, Garo Hills, and Jaintia Hills of Assam, shifting the administrative paradigm directly to elected tribal representatives.",
    era: "early",
    tags: ["Elections", "Democracy", "Self-Governance"]
  },
  {
    id: "ev-6",
    year: "1963",
    title: "Naga Hills Statehood (Abolition of ADC in favor of Art 371A)",
    desc: "Following intense political movement, the Naga Hills District exits the Sixth Schedule. Nagaland is established as India's 16th State under Article 371A, which grants direct customary protection over religious practices and land, setting an administrative precedent beyond the standard ADC model.",
    era: "early",
    tags: ["Nagaland", "Art. 371A", "Statehood"]
  },
  {
    id: "ev-7",
    year: "1972",
    title: "State Reorganisation & Creation of Meghalaya",
    desc: "Under the North-Eastern Areas (Reorganisation) Act, 1971, Meghalaya is established as a full-fledged State, carved out of the Khasi, Jaintia, and Garo Hills of Assam. The three existing ADCs are preserved. The Act inserts Paragraph 12A, adjusting state legislative precedence over council legislation on concurrent subjects.",
    era: "expansion",
    tags: ["Meghalaya", "Reorganisation", "Para 12A"]
  },
  {
    id: "ev-8",
    year: "1984",
    title: "Tripura Extension (49th Constitutional Amendment)",
    desc: "The Constitution (Forty-ninth Amendment) Act, 1984, formally extends the Sixth Schedule to the State of Tripura, creating the Tripura Tribal Areas Autonomous District Council (TTAADC) to govern and safeguard the tribal populations living in the Tripura plains and hills.",
    era: "expansion",
    tags: ["Tripura", "Amendment", "TTAADC"]
  },
  {
    id: "ev-9",
    year: "1987",
    title: "Mizoram Statehood & Mizo ADCs Established",
    desc: "Following the historic Mizo Peace Accord of 1986, Mizoram transitions from a Union Territory to a full State. Three distinct ADCs — the Chakma, Mara, and Lai Councils — are preserved under Part III of the Sixth Schedule Table. Paragraph 12B and Paragraph 20BB are subsequently added in 1988.",
    era: "expansion",
    tags: ["Mizoram", "CADC", "LADC", "MADC"]
  },
  {
    id: "ev-10",
    year: "1995",
    title: "Assam Special Powers & Name Changes",
    desc: "The Sixth Schedule to the Constitution (Amendment) Act, 1995, grants additional legislative subjects to the North Cachar Hills and Karbi Anglong District Councils in Assam under a new Paragraph 3A, expanding local authority to industries, primary/secondary education, and municipal bodies.",
    era: "expansion",
    tags: ["Assam", "KAAC", "DHADC", "Para 3A"]
  },
  {
    id: "ev-11",
    year: "2003",
    title: "Bodoland Territorial Council Integration",
    desc: "The Sixth Schedule to the Constitution (Amendment) Act, 2003, creates the Bodoland Territorial Council (BTC) in Assam for the Bodoland Territorial Areas District, adding Paragraph 3B which lists forty advanced legislative subjects to accommodate self-governance demands in non-homogenous areas.",
    era: "modern",
    tags: ["BTC", "Bodo Accord", "Para 3B", "Assam"]
  },
  {
    id: "ev-12",
    year: "2005",
    title: "The Pu Myllai Hlychho Ruling",
    desc: "The Supreme Court's five-judge Constitution Bench in Pu Myllai Hlychho v. State of Mizoram clarifies that the Governor must act on the aid and advice of the Council of Ministers in all matters except those explicitly listed as discretionary under Paragraph 20BB, directly translating Ambedkar's 1949 floor statements into binding constitutional case law.",
    era: "modern",
    tags: ["Judiciary", "Supreme Court", "Mizoram"]
  },
  {
    id: "ev-13",
    year: "2019",
    title: "Ladakh & Gorkhaland Demands Gain Momentum",
    desc: "Following the abrogation of Article 370 and creation of Ladakh as a Union Territory, Ladakhi leaders form the Leh Apex Body and Kargil Democratic Alliance to demand the extension of the Sixth Schedule to protect local land rights, environment, and culture. Similar demands persist in Darjeeling for the Gorkha population.",
    era: "modern",
    tags: ["Ladakh", "Darjeeling", "Current Demands"]
  },
  {
    id: "ev-14",
    year: "2024",
    title: "The contemporary Ladakh negotiations",
    desc: "Substantive negotiations between the Ministry of Home Affairs and Ladakh representatives explore specialized asymmetric federal models. The debates highlight the ongoing vitality and adaptiveness of the Sixth Schedule framework as a tool for constitutional accommodation in 21st-century India.",
    era: "modern",
    tags: ["Negotiations", "Union Territory", "Contemporary"]
  }
];
